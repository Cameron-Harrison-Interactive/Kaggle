# TRACE-03 utilization audit report

## 1. Labor audit

### Per-day worker-decision totals by operation

| day | PASS | moves(E/W/N/S) | PLANT | WATER | HARV | FERT | DIG | BUILD | PLACE | FEED | CARE | COLLECT | PICKUP | DROP | other |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 125 | 48 | 12 | 12 | 0 | 0 | 0 | 2 | 2 | 2 | 2 | 0 | 3 | 0 | 0 |
| 1 | 126 | 62 | 0 | 12 | 0 | 0 | 0 | 0 | 0 | 2 | 2 | 2 | 2 | 0 | 0 |
| 2 | 14 | 47 | 6 | 18 | 0 | 0 | 0 | 0 | 0 | 2 | 2 | 2 | 2 | 0 | 0 |
| 3 | 1 | 76 | 6 | 20 | 4 | 0 | 0 | 0 | 0 | 2 | 2 | 2 | 2 | 0 | 0 |
| 4 | 5 | 69 | 7 | 19 | 10 | 0 | 0 | 0 | 0 | 2 | 1 | 2 | 1 | 0 | 0 |
| 5 | 8 | 55 | 1 | 20 | 2 | 0 | 0 | 0 | 0 | 2 | 2 | 2 | 1 | 0 | 0 |
| 6 | 21 | 62 | 0 | 20 | 2 | 2 | 0 | 0 | 0 | 2 | 2 | 2 | 1 | 1 | 0 |
| 7 | 8 | 75 | 0 | 20 | 2 | 2 | 0 | 1 | 0 | 2 | 2 | 2 | 2 | 0 | 0 |
| 8 | 6 | 75 | 0 | 20 | 2 | 2 | 0 | 0 | 1 | 2 | 2 | 2 | 3 | 1 | 0 |
| 9 | 16 | 63 | 0 | 20 | 2 | 3 | 0 | 0 | 0 | 3 | 3 | 3 | 2 | 1 | 0 |
| 10 | 2 | 50 | 0 | 20 | 36 | 0 | 0 | 0 | 0 | 2 | 2 | 3 | 1 | 0 | 0 |
| 11 | 0 | 29 | 0 | 12 | 67 | 0 | 0 | 0 | 0 | 3 | 0 | 3 | 2 | 0 | 0 |
| 12 | 0 | 77 | 0 | 12 | 42 | 0 | 0 | 0 | 0 | 2 | 1 | 3 | 1 | 1 | 0 |
| 13 | 2 | 79 | 9 | 17 | 8 | 2 | 0 | 2 | 2 | 4 | 4 | 3 | 5 | 2 | 0 |
| 14 | 9 | 108 | 4 | 14 | 9 | 1 | 0 | 4 | 3 | 6 | 6 | 5 | 6 | 5 | 0 |
| 15 | 8 | 112 | 6 | 19 | 3 | 0 | 0 | 0 | 1 | 9 | 9 | 8 | 9 | 1 | 0 |
| 16 | 9 | 108 | 6 | 25 | 3 | 0 | 0 | 0 | 0 | 9 | 9 | 9 | 5 | 1 | 0 |
| 17 | 14 | 89 | 0 | 25 | 2 | 4 | 0 | 0 | 0 | 7 | 7 | 9 | 4 | 1 | 0 |
| 18 | 5 | 124 | 4 | 24 | 9 | 8 | 0 | 0 | 0 | 9 | 9 | 9 | 6 | 0 | 0 |
| 19 | 12 | 124 | 3 | 21 | 10 | 0 | 0 | 0 | 0 | 8 | 8 | 9 | 5 | 5 | 0 |
| 20 | 12 | 98 | 4 | 25 | 5 | 5 | 0 | 0 | 0 | 9 | 9 | 9 | 6 | 2 | 0 |
| 21 | 0 | 68 | 0 | 21 | 100 | 1 | 0 | 0 | 0 | 6 | 1 | 6 | 3 | 0 | 0 |
| 22 | 0 | 74 | 0 | 9 | 93 | 2 | 0 | 0 | 0 | 9 | 4 | 8 | 6 | 1 | 0 |
| 23 | 0 | 95 | 3 | 7 | 75 | 0 | 0 | 0 | 0 | 6 | 4 | 9 | 4 | 1 | 0 |
| 24 | 1 | 83 | 9 | 12 | 25 | 2 | 0 | 0 | 0 | 7 | 6 | 8 | 6 | 1 | 0 |
| 25 | 4 | 104 | 7 | 19 | 9 | 3 | 0 | 0 | 0 | 9 | 9 | 9 | 9 | 2 | 0 |
| 26 | 10 | 91 | 0 | 16 | 10 | 4 | 0 | 0 | 0 | 8 | 6 | 9 | 4 | 3 | 0 |
| 27 | 9 | 93 | 0 | 7 | 15 | 2 | 0 | 0 | 0 | 9 | 9 | 9 | 6 | 2 | 0 |
| 28 | 23 | 64 | 0 | 0 | 9 | 0 | 0 | 1 | 1 | 10 | 10 | 9 | 7 | 5 | 0 |
| 29 | 28 | 38 | 0 | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 0 | 9 | 0 | 8 | 0 |

### PASS worker-decisions per day, with opportunity context

| day | total PASS | PASS w/ empty crop cell AND seeds held | PASS w/ unplaced animal AND compatible cell |
|---|---|---|---|
| 0 | 125 | 2 | 0 |
| 1 | 126 | 0 | 0 |
| 2 | 14 | 3 | 0 |
| 3 | 1 | 0 | 0 |
| 4 | 5 | 5 | 5 |
| 5 | 8 | 1 | 8 |
| 6 | 21 | 0 | 21 |
| 7 | 8 | 0 | 8 |
| 8 | 6 | 0 | 6 |
| 9 | 16 | 0 | 16 |
| 10 | 2 | 0 | 2 |
| 13 | 2 | 2 | 0 |
| 14 | 9 | 9 | 9 |
| 15 | 8 | 8 | 8 |
| 16 | 9 | 9 | 9 |
| 17 | 14 | 14 | 14 |
| 18 | 5 | 5 | 5 |
| 19 | 12 | 12 | 12 |
| 20 | 12 | 12 | 12 |
| 24 | 1 | 1 | 1 |
| 25 | 4 | 4 | 4 |
| 26 | 10 | 10 | 10 |
| 27 | 9 | 9 | 9 |
| 28 | 23 | 23 | 13 |
| 29 | 28 | 28 | 0 |

## 2. Planting throughput

| day | seq range | seeds @ first h>=4 obs | PLANTs issued | seeds purchased | seeds @ last decision |
|---|---|---|---|---|---|
| 0 | 0–23 | 10 | 12 | 12 | 0 |
| 1 | 24–47 | 0 | 0 | 0 | 0 |
| 2 | 48–71 | 6 | 6 | 6 | 0 |
| 3 | 72–95 | 6 | 6 | 6 | 0 |
| 4 | 96–119 | 8 | 7 | 8 | 1 |
| 5 | 120–143 | 1 | 1 | 0 | 0 |
| 6 | 144–167 | 0 | 0 | 0 | 0 |
| 7 | 168–191 | 0 | 0 | 0 | 0 |
| 8 | 192–215 | 0 | 0 | 0 | 0 |
| 9 | 216–239 | 0 | 0 | 0 | 0 |
| 10 | 240–263 | 0 | 0 | 4 | 4 |
| 11 | 264–287 | 4 | 0 | 3 | 7 |
| 12 | 288–311 | 8 | 0 | 1 | 8 |
| 13 | 312–335 | 12 | 9 | 4 | 3 |
| 14 | 336–359 | 12 | 4 | 13 | 11 |
| 15 | 360–383 | 12 | 6 | 6 | 12 |
| 16 | 384–407 | 12 | 6 | 0 | 6 |
| 17 | 408–431 | 6 | 0 | 0 | 6 |
| 18 | 432–455 | 12 | 4 | 6 | 8 |
| 19 | 456–479 | 12 | 3 | 5 | 10 |
| 20 | 480–503 | 10 | 4 | 0 | 6 |
| 21 | 504–527 | 12 | 0 | 6 | 12 |
| 22 | 528–551 | 12 | 0 | 0 | 12 |
| 23 | 552–575 | 12 | 3 | 3 | 12 |
| 24 | 576–599 | 12 | 9 | 9 | 11 |
| 25 | 600–623 | 12 | 7 | 4 | 9 |
| 26 | 624–647 | 9 | 0 | 0 | 9 |
| 27 | 648–671 | 9 | 0 | 0 | 9 |
| 28 | 672–695 | 9 | 0 | 0 | 9 |
| 29 | 696–718 | 9 | 0 | 0 | 9 |

### Days with seeds held all day and zero PLANT actions

- day 11: seq 264–287 (seeds first=4, last=7, purchased that day=3)
- day 12: seq 288–311 (seeds first=7, last=8, purchased that day=1)
- day 17: seq 408–431 (seeds first=6, last=6, purchased that day=0)
- day 21: seq 504–527 (seeds first=6, last=12, purchased that day=6)
- day 22: seq 528–551 (seeds first=12, last=12, purchased that day=0)
- day 26: seq 624–647 (seeds first=9, last=9, purchased that day=0)
- day 27: seq 648–671 (seeds first=9, last=9, purchased that day=0)
- day 28: seq 672–695 (seeds first=9, last=9, purchased that day=0)
- day 29: seq 696–718 (seeds first=9, last=9, purchased that day=0)

## 3. Land gate forensics (decisions h<=3, owned<4)

Classification order: day>17, then density<0.80, then cash<cost+1600, else none_failed.

- **day>17**: 48 decisions (first seq 432, last seq 699, days [18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29])
- **density<0.80**: 30 decisions (first seq 0, last seq 411, days [0, 1, 2, 13, 14, 15, 16, 17])
- **cash<cost+1600**: 40 decisions (first seq 72, last seq 291, days [3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
- **none_failed**: 2 decisions (first seq 336, last seq 337, days [14])

| day | class counts |
|---|---|
| 0 | density<0.80:4 |
| 1 | density<0.80:4 |
| 2 | density<0.80:4 |
| 3 | cash<cost+1600:4 |
| 4 | cash<cost+1600:4 |
| 5 | cash<cost+1600:4 |
| 6 | cash<cost+1600:4 |
| 7 | cash<cost+1600:4 |
| 8 | cash<cost+1600:4 |
| 9 | cash<cost+1600:4 |
| 10 | cash<cost+1600:4 |
| 11 | cash<cost+1600:4 |
| 12 | cash<cost+1600:4 |
| 13 | density<0.80:4 |
| 14 | density<0.80:2, none_failed:2 |
| 15 | density<0.80:4 |
| 16 | density<0.80:4 |
| 17 | density<0.80:4 |
| 18 | day>17:4 |
| 19 | day>17:4 |
| 20 | day>17:4 |
| 21 | day>17:4 |
| 22 | day>17:4 |
| 23 | day>17:4 |
| 24 | day>17:4 |
| 25 | day>17:4 |
| 26 | day>17:4 |
| 27 | day>17:4 |
| 28 | day>17:4 |
| 29 | day>17:4 |

## 4. Animal placement forensics (unplaced-held intervals)

| species | seq range | days spanned | max held | compatible free cell existed | INSTALL actions in interval |
|---|---|---|---|---|---|
| GOOSE | 2–6 | d0–d0 | 2 | always | COOP:2 PASTURE:0 PLACE:2 PICKUP_an:2 |
| GOOSE | 341–343 | d14–d14 | 1 | always | COOP:1 PASTURE:0 PLACE:1 PICKUP_an:1 |
| COW | 97–329 | d4–d13 | 2 | always | COOP:0 PASTURE:2 PLACE:2 PICKUP_an:4 |
| COW | 340–379 | d14–d15 | 2 | always | COOP:1 PASTURE:3 PLACE:4 PICKUP_an:4 |
| SHEEP | 145–332 | d6–d13 | 1 | always | COOP:0 PASTURE:3 PLACE:3 PICKUP_an:4 |
| SHEEP | 339–693 | d14–d28 | 2 | always | COOP:1 PASTURE:4 PLACE:5 PICKUP_an:6 |
