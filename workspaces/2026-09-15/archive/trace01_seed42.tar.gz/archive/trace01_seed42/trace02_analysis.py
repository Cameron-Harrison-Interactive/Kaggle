"""
TRACE-02 — read-only analysis of saved TRACE-01 artifacts.
Inputs:  trace.jsonl, terminal_state.json, manifest.json (TRACE-01 directory only).
Outputs: trace02_report.json, trace02_report.md (this directory).
No agent edits, verifier edits, installs, submissions, or simulation runs.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
recs = [json.loads(l) for l in open(os.path.join(HERE, "trace.jsonl"))]
term = json.load(open(os.path.join(HERE, "terminal_state.json")))
manifest = json.load(open(os.path.join(HERE, "manifest.json")))


def farm0(obs):
    return obs["farms"][0]


def tile(obs, pos):
    t = farm0(obs)["tiles"][pos[1]][pos[0]]
    if isinstance(t, dict):
        return t
    return {"kind": "EMPTY" if t is None else str(t)}


def tstate(obs, pos):
    tl = tile(obs, pos)
    return {k: tl.get(k) for k in ("kind", "crop", "planted_day",
                                   "watered_today", "consecutive_unwatered")}


def units(rec):
    a = rec["action"] or {}
    return [a.get("farmer")] + list(a.get("hands") or [])


def q_of(pos):
    return ("N" if pos[1] < 5 else "S") + ("W" if pos[0] < 5 else "E")


def animal_line(pos):
    return pos[1] in (4, 5)


def owned_set(obs):
    return set(farm0(obs).get("unlocked_quadrants", ["NW"]))


def priv(obs):
    return obs.get("private") or {}


def day_start_idx(day):
    for i, r in enumerate(recs):
        if r["obs_day"] == day:
            return i
    return None


# ===========================================================================
# 1. PLANTING AUDIT
# ===========================================================================
plants = []
for i, r in enumerate(recs):
    for wi, a in enumerate(units(r)):
        if not a or a[0] != "PLANT" or wi >= len(r["worker_positions"]):
            continue
        plants.append({
            "seq": r["seq"], "day": r["obs_day"], "hour": r["obs_hour"],
            "unit": wi, "pos": tuple(r["worker_positions"][wi]),
            "crop": a[1] if len(a) > 1 else "?",
        })

audit = []
for p in plants:
    i = p["seq"]
    r = recs[i]
    ev = dict(p)
    ev["pos"] = list(p["pos"])
    nxt = r["next_observation"]
    # --- success in next supplied observation ---
    if nxt is None:
        ev["planted_confirmed"] = None
        ev["success_reason"] = "no next supplied observation (episode end)"
    else:
        tl = tile(nxt, p["pos"])
        ev["planted_confirmed"] = (tl.get("kind") == "PLANT"
                                   and tl.get("crop") == p["crop"]
                                   and tl.get("planted_day") == p["day"])
        ev["success_reason"] = "" if ev["planted_confirmed"] else (
            f"next obs tile={tstate(nxt, p['pos'])}")
    # --- same-worker, same-position next-decision WATER command ---
    ev["followup_command"] = False
    ev["followup_note"] = "no next decision"
    if i + 1 < len(recs):
        rn = recs[i + 1]
        au = units(rn)
        if p["unit"] < len(au) and au[p["unit"]]:
            if (au[p["unit"]][0] == "WATER"
                    and p["unit"] < len(rn["worker_positions"])
                    and tuple(rn["worker_positions"][p["unit"]]) == p["pos"]):
                ev["followup_command"] = True
                ev["followup_note"] = ""
                ev["followup_seq"] = rn["seq"]
                ev["followup_hour"] = rn["obs_hour"]
            else:
                ev["followup_note"] = (
                    f"next action of unit={au[p['unit']]} at "
                    f"{tuple(rn['worker_positions'][p['unit']]) if p['unit'] < len(rn['worker_positions']) else 'n/a'}")
    # --- follow-up watering effect ---
    ev["followup_effect"] = None
    ev["followup_effect_note"] = ""
    if ev["followup_command"]:
        rn = recs[i + 1]
        nxt2 = rn["next_observation"]
        if nxt2 is None:
            ev["followup_effect_note"] = "no following observation (episode end)"
        elif rn["obs_hour"] == 23:
            # boundary: use refresh transition + plant identity
            tl = tile(nxt2, p["pos"])
            if (tl.get("kind") == "PLANT" and tl.get("planted_day") == p["day"]
                    and tl.get("crop") == p["crop"]):
                ev["followup_effect"] = (tl.get("consecutive_unwatered", 9) == 0)
                ev["followup_effect_note"] = "boundary: cuw==0 after refresh"
            else:
                ev["followup_effect"] = False
                ev["followup_effect_note"] = f"boundary tile={tstate(nxt2, p['pos'])}"
        else:
            tl = tile(nxt2, p["pos"])
            ev["followup_effect"] = (tl.get("kind") == "PLANT"
                                     and tl.get("watered_today") is True)
            ev["followup_effect_note"] = "" if ev["followup_effect"] else (
                f"following obs tile={tstate(nxt2, p['pos'])}")
    # --- fresh-plant death at the first refresh after planting ---
    ev["first_refresh_outcome"] = "n/a"
    if ev["planted_confirmed"]:
        j = day_start_idx(p["day"] + 1)
        if j is None:
            ev["first_refresh_outcome"] = "no refresh (game ended first)"
        else:
            tl = tile(recs[j]["input_observation"], p["pos"])
            if tl.get("kind") == "WEED":
                ev["first_refresh_outcome"] = "DIED"
            elif tl.get("kind") == "PLANT" and tl.get("planted_day") == p["day"]:
                cuw = tl.get("consecutive_unwatered", 9)
                ev["first_refresh_outcome"] = "alive_watered" if cuw == 0 else (
                    f"alive_cuw{cuw}_ANOMALY")
            else:
                ev["first_refresh_outcome"] = f"other:{tstate(recs[j]['input_observation'], p['pos'])}"
    audit.append(ev)

att = len(audit)
conf = [e for e in audit if e["planted_confirmed"] is True]
fu_cmd = [e for e in conf if e["followup_command"]]
fu_eff = [e for e in fu_cmd if e["followup_effect"] is True]
deaths = [e for e in conf if e["first_refresh_outcome"] == "DIED"]
unresolved = []
for e in audit:
    reasons = []
    if e["planted_confirmed"] is None:
        reasons.append("success-unverifiable")
    if e["planted_confirmed"] and e["followup_command"] and e["followup_effect"] is None:
        reasons.append("water-effect-unverifiable")
    if e["planted_confirmed"] and e["first_refresh_outcome"] == "no refresh (game ended first)":
        reasons.append("no-refresh-before-game-end")
    if e["planted_confirmed"] and str(e["first_refresh_outcome"]).endswith("ANOMALY"):
        reasons.append(e["first_refresh_outcome"])
    if e["planted_confirmed"] and not e["followup_command"]:
        # not unresolved per se, but flagged for the table
        pass
    if reasons:
        unresolved.append((e["seq"], reasons))

# ===========================================================================
# 2. GROWTH TIMELINE (first supplied observation with hour >= 4 each day)
# ===========================================================================
timeline = []
for d in range(30):
    row_rec = None
    for r in recs:
        if r["obs_day"] == d and r["obs_hour"] >= 4:
            row_rec = r
            break
    if row_rec is None:
        continue
    obs = row_rec["input_observation"]
    f = farm0(obs)
    pr = priv(obs)
    animals, crops = {}, {}
    empty_crop, crop_weeds = 0, 0
    ownd = owned_set(obs)
    for y, trow in enumerate(f["tiles"]):
        for x, t in enumerate(trow):
            pos = (x, y)
            if q_of(pos) not in ownd:
                continue
            if isinstance(t, dict):
                if "animal" in t:
                    animals[t["animal"]] = animals.get(t["animal"], 0) + 1
                elif t.get("kind") == "PLANT":
                    crops[t["crop"]] = crops.get(t["crop"], 0) + 1
                elif t.get("kind") == "WEED" and not animal_line(pos):
                    crop_weeds += 1
            elif t is None and not animal_line(pos):
                empty_crop += 1
    shed_an = {k: pr.get("shed", {}).get(k, 0) for k in ("GOOSE", "COW", "SHEEP")}
    car_an = {k: 0 for k in ("GOOSE", "COW", "SHEEP")}
    for inv in pr.get("inventories", []):
        for k in car_an:
            car_an[k] += int(inv.get(k, 0))
    timeline.append({
        "day": d, "seq": row_rec["seq"], "hour": row_rec["obs_hour"],
        "cash": f["money"], "hands": len(f.get("hands") or []),
        "quads": sorted(ownd), "animals": animals,
        "shed_animals": shed_an, "carried_animals": car_an,
        "crops": crops, "seeds": dict(pr.get("seeds", {})),
        "empty_crop_positions": empty_crop, "crop_weeds": crop_weeds,
    })

land_orders = []
for r in recs:
    for o in ((r["action"] or {}).get("market") or []):
        if isinstance(o, list) and o and o[0] == "BUY_LAND":
            n_before = len(owned_set(r["input_observation"]))
            change = None
            for r2 in recs[r["seq"] + 1:]:
                n_now = len(owned_set(r2["input_observation"]))
                if n_now > n_before:
                    change = {"seq": r2["seq"], "day": r2["obs_day"],
                              "hour": r2["obs_hour"],
                              "quads": sorted(owned_set(r2["input_observation"]))}
                    break
            land_orders.append({
                "seq": r["seq"], "day": r["obs_day"], "hour": r["obs_hour"],
                "quads_before": sorted(owned_set(r["input_observation"])),
                "ownership_change_observed": change})

animal_orders = []
for r in recs:
    for o in ((r["action"] or {}).get("market") or []):
        if isinstance(o, list) and len(o) >= 2 and o[0] == "BUY_ANIMAL":
            kind = o[1]
            def standing(obs, k):
                n = 0
                for trow in farm0(obs)["tiles"]:
                    for t in trow:
                        if isinstance(t, dict) and t.get("animal") == k:
                            n += 1
                return n
            before = standing(r["input_observation"], kind)
            placement = None
            for r2 in recs[r["seq"] + 1:]:
                if standing(r2["input_observation"], kind) > before:
                    placement = {"seq": r2["seq"], "day": r2["obs_day"],
                                 "hour": r2["obs_hour"]}
                    break
            animal_orders.append({
                "seq": r["seq"], "day": r["obs_day"], "hour": r["obs_hour"],
                "kind": kind, "qty": o[2] if len(o) > 2 else 1,
                "standing_before": before,
                "first_observed_placement": placement})

# ===========================================================================
# 3. SEED-BLOCKED PLANTING OPPORTUNITIES (representative, hour >= 4)
# ===========================================================================
opps = []
for r in recs:
    if r["obs_hour"] < 4 or r["obs_day"] >= 29:
        continue
    obs = r["input_observation"]
    f = farm0(obs)
    ownd = owned_set(obs)
    empties = [(x, y)
               for y, trow in enumerate(f["tiles"])
               for x, t in enumerate(trow)
               if q_of((x, y)) in ownd and t is None and not animal_line((x, y))]
    if not empties:
        continue
    seeds = priv(obs).get("seeds", {})
    if any(int(v) > 0 for v in seeds.values()):
        continue
    hours_left = 24 - r["obs_hour"]
    best = None
    for wi, wp in enumerate(r["worker_positions"]):
        for e in empties:
            d = abs(wp[0] - e[0]) + abs(wp[1] - e[1])
            if best is None or d < best:
                best = d
    if best is not None and best + 2 <= hours_left:
        opps.append({
            "seq": r["seq"], "day": r["obs_day"], "hour": r["obs_hour"],
            "empty_crop_positions": len(empties),
            "seeds": dict(seeds),
            "nearest_worker_dist": best, "hours_left": hours_left,
        })
per_day = {}
for o in opps:
    per_day.setdefault(o["day"], []).append(o["seq"])
representative = []
seen_days = set()
for o in opps:
    if o["day"] not in seen_days:
        representative.append(o)
        seen_days.add(o["day"])

# ===========================================================================
# 4. FINAL FIVE DECISIONS + TERMINAL COMPARISON
# ===========================================================================
final_five = []
for r in recs[-5:]:
    obs = r["input_observation"]
    f = farm0(obs)
    pr = priv(obs)
    carried = {}
    for inv in pr.get("inventories", []):
        for k, v in inv.items():
            carried[k] = carried.get(k, 0) + int(v)
    final_five.append({
        "seq": r["seq"], "step": r["obs_step"], "day": r["obs_day"],
        "hour": r["obs_hour"],
        "action": r["action"],
        "cash": f["money"],
        "shed": dict(pr.get("shed", {})),
        "carried_products": carried,
    })
t0 = term["observations"][0]
f0 = farm0(t0)
tpriv = t0.get("private") or {}
t_carried = {}
for inv in tpriv.get("inventories", []):
    for k, v in inv.items():
        t_carried[k] = t_carried.get(k, 0) + int(v)
terminal_summary = {
    "statuses": term["statuses"], "rewards": term["rewards"],
    "money": f0["money"], "quads": f0.get("unlocked_quadrants"),
    "hands": len(f0.get("hands") or []),
    "shed": dict(tpriv.get("shed", {})),
    "carried_products": t_carried,
    "captured_utc": term.get("captured_utc"),
}
# h23-dependency flags on the final day
h23_flags = []
last = recs[-1]
for wi, a in enumerate(units(last)):
    if a and a[0] == "PLANT":
        h23_flags.append({
            "issue": "PLANT at final decision (h22) — its mandatory WATER "
                     "follow-up would need a decision at h23/step 719, "
                     "which was never supplied",
            "seq": last["seq"], "unit": wi, "action": a})
for r in recs[-5:]:
    for wi, a in enumerate(units(r)):
        if a and a[0] == "PLANT":
            water_by = None
            j = r["seq"] + 1
            if j < len(recs):
                au = units(recs[j])
                if wi < len(au) and au[wi] and au[wi][0] == "WATER":
                    water_by = recs[j]["seq"]
            h23_flags.append({
                "info": "final-day PLANT", "seq": r["seq"],
                "hour": r["obs_hour"], "unit": wi, "action": a,
                "water_followup_seq": water_by,
                "note": ("follow-up never supplied (no later decision)"
                         if water_by is None and r["seq"] == last["seq"]
                         else "ok" if water_by is not None else
                         f"no same-unit WATER at next decision (seq {j})")})

# ===========================================================================
# SAVE + PRINT
# ===========================================================================
report = {
    "run_id": manifest.get("run_id"),
    "sources": ["trace.jsonl", "terminal_state.json", "manifest.json"],
    "planting_audit": {
        "attempts": att,
        "confirmed_successful_plantings": len(conf),
        "same_worker_same_pos_next_decision_WATER_commands": len(fu_cmd),
        "confirmed_successful_followup_waterings": len(fu_eff),
        "confirmed_fresh_plant_deaths": len(deaths),
        "unresolved": [{"seq": s, "reasons": rs} for s, rs in unresolved],
        "per_event": audit,
    },
    "growth_timeline": timeline,
    "land_orders": land_orders,
    "animal_purchase_orders": animal_orders,
    "seed_blocked_opportunities": {
        "criterion": "hour>=4, day<29, >=1 empty owned non-animal-line tile, "
                     "total seeds == 0, nearest worker dist + 2 <= hours left "
                     "(hours_left = 24 - hour)",
        "total_qualifying_decisions": len(opps),
        "per_day_counts": {str(d): len(v) for d, v in sorted(per_day.items())},
        "representative_first_per_day": representative,
    },
    "final_five_decisions": final_five,
    "terminal_summary": terminal_summary,
    "final_day_h23_dependency_flags": h23_flags,
}
with open(os.path.join(HERE, "trace02_report.json"), "w") as f:
    json.dump(report, f, indent=1)

# ---------- markdown ----------
md = []
md.append(f"# TRACE-02 report — {manifest.get('run_id')}\n")
md.append("## 1. Planting audit\n")
a = report["planting_audit"]
md.append(f"- PLANT attempts: **{a['attempts']}**")
md.append(f"- Confirmed successful plantings: **{a['confirmed_successful_plantings']}**")
md.append(f"- Same-worker, same-position next-decision WATER commands: "
          f"**{a['same_worker_same_pos_next_decision_WATER_commands']}**")
md.append(f"- Confirmed successful follow-up waterings: "
          f"**{a['confirmed_successful_followup_waterings']}**")
md.append(f"- Confirmed fresh-plant deaths: **{a['confirmed_fresh_plant_deaths']}**")
md.append(f"- Unresolved: **{len(a['unresolved'])}**")
for u in a["unresolved"]:
    md.append(f"  - seq {u['seq']}: {', '.join(u['reasons'])}")
alive = [e for e in conf if e["first_refresh_outcome"] == "alive_watered"]
md.append(f"- Context: alive+watered at first refresh: {len(alive)}; "
          f"follow-up command present: {len(fu_cmd)}; "
          f"watered-by-anyone survival basis: first-refresh cuw==0")
md.append("\n## 2. Growth timeline (first obs with hour>=4 each day)\n")
md.append("| day | seq | h | cash | hands | quads | animals | shed_an | "
          "car_an | crops | seeds | empty | weeds |")
md.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
for t in timeline:
    md.append(
        f"| {t['day']} | {t['seq']} | {t['hour']} | {t['cash']:.0f} | {t['hands']} | "
        f"{'/'.join(t['quads'])} | {t['animals']} | {t['shed_animals']} | "
        f"{t['carried_animals']} | {t['crops']} | {t['seeds']} | "
        f"{t['empty_crop_positions']} | {t['crop_weeds']} |")
md.append("\n### BUY_LAND orders\n")
if not land_orders:
    md.append("(none issued)")
for lo in land_orders:
    ch = lo["ownership_change_observed"]
    if ch:
        ch_txt = (f"change observed at seq {ch['seq']} "
                  f"(d{ch['day']} h{ch['hour']}): {'/'.join(ch['quads'])}")
    else:
        ch_txt = "NO ownership change observed afterward"
    md.append(f"- seq {lo['seq']} (d{lo['day']} h{lo['hour']}): "
              f"before={lo['quads_before']} -> {ch_txt}")
md.append("\n### Animal purchase orders\n")
if not animal_orders:
    md.append("(none issued)")
for ao in animal_orders:
    pl = ao["first_observed_placement"]
    if pl:
        pl_txt = f"placement observed at seq {pl['seq']} (d{pl['day']} h{pl['hour']})"
    else:
        pl_txt = "no placement observed afterward"
    md.append(f"- seq {ao['seq']} (d{ao['day']} h{ao['hour']}): {ao['kind']} x{ao['qty']} "
              f"(standing before: {ao['standing_before']}) -> {pl_txt}")
sb = report["seed_blocked_opportunities"]
md.append("\n## 3. Seed-blocked planting opportunities (representative)\n")
md.append(f"Criterion: {sb['criterion']}")
md.append(f"Total qualifying decisions: **{sb['total_qualifying_decisions']}** "
          f"(per day: {sb['per_day_counts']})")
md.append("\n| day | seq | h | empty crop pos | seeds | nearest worker dist | hours left |")
md.append("|---|---|---|---|---|---|---|")
for o in sb["representative_first_per_day"]:
    md.append(f"| {o['day']} | {o['seq']} | {o['hour']} | {o['empty_crop_positions']} | "
              f"all-zero | {o['nearest_worker_dist']} | {o['hours_left']} |")
md.append("\n## 4. Final five decisions\n")
for ff in final_five:
    md.append(f"### seq {ff['seq']} — step {ff['step']} d{ff['day']} h{ff['hour']}")
    md.append(f"- cash {ff['cash']:.0f}, shed `{ff['shed']}`, carried `{ff['carried_products']}`")
    md.append(f"- farmer: `{ff['action']['farmer']}`")
    for hi, h in enumerate(ff["action"].get("hands") or []):
        md.append(f"- hand {hi}: `{h}`")
    mk = ff["action"].get("market") or []
    md.append(f"- market ({len(mk)}): `{mk}`")
ts = terminal_summary
md.append("\n### Terminal state\n")
md.append(f"- statuses {ts['statuses']}, rewards {ts['rewards']}, money **{ts['money']}**")
md.append(f"- quads {ts['quads']}, hands {ts['hands']}")
md.append(f"- shed `{ts['shed']}`")
md.append(f"- carried `{ts['carried_products']}`")
md.append("\n### Final-day h23 dependency flags\n")
if not h23_flags:
    md.append("(none)")
for fl in h23_flags:
    if "issue" in fl:
        md.append(f"- **FLAG** seq {fl['seq']} unit {fl['unit']}: {fl['issue']} (`{fl['action']}`)")
    else:
        md.append(f"- seq {fl['seq']} h{fl['hour']} unit {fl['unit']} `{fl['action']}` "
                  f"-> {fl['note']}")
with open(os.path.join(HERE, "trace02_report.md"), "w") as f:
    f.write("\n".join(md) + "\n")

# ---------- console summary ----------
print("=== 1. PLANTING AUDIT ===")
print(f"attempts {att} | confirmed {len(conf)} | follow-up commands {len(fu_cmd)} | "
      f"follow-up effects confirmed {len(fu_eff)} | fresh deaths {len(deaths)} | "
      f"unresolved {len(unresolved)}")
for s, rs in unresolved:
    print(f"   unresolved seq {s}: {rs}")
no_fu = [e["seq"] for e in conf if not e["followup_command"]]
print(f"confirmed plants WITHOUT same-worker next-decision WATER: {no_fu}")
h23_plants = [e["seq"] for e in plants if e["hour"] == 23]
print(f"PLANTs issued at hour 23: {h23_plants}")
alive_anom = [e["seq"] for e in conf if str(e["first_refresh_outcome"]).endswith("ANOMALY")]
print(f"alive-with-cuw-anomaly seqs: {alive_anom}")
print(f"\n=== 2. TIMELINE (abridged: d0,5,10,15,20,25,29) ===")
for t in timeline:
    if t["day"] in (0, 5, 10, 15, 20, 25, 29):
        print(f"d{t['day']:>2} h{t['hour']} cash={t['cash']:>7.0f} hands={t['hands']} "
              f"quads={'/'.join(t['quads'])} an={t['animals']} crops={t['crops']} "
              f"seeds={t['seeds']} empty={t['empty_crop_positions']} weeds={t['crop_weeds']}")
print(f"\nBUY_LAND orders: {len(land_orders)}")
for lo in land_orders:
    print("  ", lo)
print(f"Animal orders: {len(animal_orders)} (first 5):")
for ao in animal_orders[:5]:
    print("  ", ao)
print(f"\n=== 3. SEED-BLOCKED OPPORTUNITIES ===")
print(f"total qualifying decisions: {sb['total_qualifying_decisions']}")
print(f"per day: {sb['per_day_counts']}")
print(f"representative days: {[o['day'] for o in sb['representative_first_per_day']]}")
print(f"\n=== 4. FINAL FIVE + TERMINAL ===")
for ff in final_five:
    mk = ff["action"].get("market") or []
    print(f"seq {ff['seq']} d{ff['day']} h{ff['hour']}: farmer={ff['action']['farmer']} "
          f"hands={ff['action'].get('hands')} market={mk} cash={ff['cash']:.0f}")
print(f"terminal: statuses={ts['statuses']} rewards={ts['rewards']} money={ts['money']} "
      f"shed={ts['shed']} carried={ts['carried_products']}")
print(f"h23 flags: {len(h23_flags)}")
for fl in h23_flags:
    print("  ", fl)
print("\nsaved: trace02_report.json, trace02_report.md")
