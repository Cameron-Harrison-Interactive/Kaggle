# TRACE-02 report — TRACE-01-20260909T214446Z

## 1. Planting audit

- PLANT attempts: **87**
- Confirmed successful plantings: **87**
- Same-worker, same-position next-decision WATER commands: **87**
- Confirmed successful follow-up waterings: **87**
- Confirmed fresh-plant deaths: **0**
- Unresolved: **0**
- Context: alive+watered at first refresh: 87; follow-up command present: 87; watered-by-anyone survival basis: first-refresh cuw==0

## 2. Growth timeline (first obs with hour>=4 each day)

| day | seq | h | cash | hands | quads | animals | shed_an | car_an | crops | seeds | empty | weeds |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 4 | 4 | 2080 | 8 | NW | {} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'GOOSE': 2, 'COW': 0, 'SHEEP': 0} | {'CARROT': 2} | {'WHEAT': 8, 'CARROT': 2, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0} | 18 | 0 |
| 1 | 28 | 4 | 1943 | 8 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'WHEAT': 8, 'CARROT': 4} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0} | 8 | 0 |
| 2 | 52 | 4 | 1603 | 3 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'WHEAT': 8, 'CARROT': 4} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 8 | 0 |
| 3 | 76 | 4 | 1257 | 4 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 6, 'WHEAT': 8, 'CARROT': 2} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 4 | 0 |
| 4 | 100 | 4 | 624 | 4 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 0} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 12, 'WHEAT': 8} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 8} | 0 | 0 |
| 5 | 124 | 4 | 1870 | 3 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 0} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 19} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 1} | 1 | 0 |
| 6 | 148 | 4 | 1481 | 4 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 20} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0} | 0 | 0 |
| 7 | 172 | 4 | 1137 | 4 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 2, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 20} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0} | 0 | 0 |
| 8 | 196 | 4 | 1272 | 4 | NW | {'GOOSE': 2} | {'GOOSE': 0, 'COW': 2, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 20} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0} | 0 | 0 |
| 9 | 220 | 4 | 1375 | 4 | NW | {'COW': 1, 'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 20} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0} | 0 | 0 |
| 10 | 244 | 4 | 1477 | 4 | NW | {'COW': 1, 'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 20} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0} | 0 | 0 |
| 11 | 268 | 4 | 1290 | 4 | NW | {'COW': 1, 'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 20} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 4} | 0 | 0 |
| 12 | 292 | 4 | 1257 | 5 | NW | {'COW': 1, 'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 20} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 8} | 0 | 0 |
| 13 | 316 | 4 | 10295 | 5 | NW | {'COW': 1, 'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 13} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 12} | 7 | 0 |
| 14 | 340 | 4 | 15640 | 7 | NE/NW | {'SHEEP': 1, 'COW': 2, 'GOOSE': 2} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 0} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'MELON': 17} | {'WHEAT': 0, 'CARROT': 4, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 8} | 23 | 0 |
| 15 | 364 | 4 | 21223 | 7 | NE/NW | {'SHEEP': 2, 'COW': 3, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 1, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14} | {'WHEAT': 0, 'CARROT': 5, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 7} | 26 | 0 |
| 16 | 388 | 4 | 22538 | 7 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 5} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 21 | 0 |
| 17 | 412 | 4 | 23481 | 6 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 11} | {'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 15 | 0 |
| 18 | 436 | 4 | 23794 | 8 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 11} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 14 | 1 |
| 19 | 460 | 4 | 25410 | 8 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 10} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 15 | 1 |
| 20 | 484 | 4 | 27429 | 7 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 7} | {'WHEAT': 0, 'CARROT': 4, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 18 | 1 |
| 21 | 508 | 4 | 29609 | 8 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 11} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 14 | 1 |
| 22 | 532 | 4 | 31652 | 8 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 7} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 18 | 1 |
| 23 | 556 | 4 | 34838 | 8 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'MELON': 14, 'CARROT': 4} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 21 | 1 |
| 24 | 580 | 4 | 45590 | 6 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'CARROT': 3, 'MELON': 4} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 32 | 1 |
| 25 | 604 | 4 | 47170 | 7 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'CARROT': 12, 'MELON': 1} | {'WHEAT': 0, 'CARROT': 6, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 26 | 1 |
| 26 | 628 | 4 | 48887 | 6 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'CARROT': 17} | {'WHEAT': 0, 'CARROT': 3, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 22 | 1 |
| 27 | 652 | 4 | 51418 | 6 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'CARROT': 13} | {'WHEAT': 0, 'CARROT': 3, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 26 | 1 |
| 28 | 676 | 4 | 55231 | 5 | NE/NW | {'SHEEP': 2, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 1} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'CARROT': 3} | {'WHEAT': 0, 'CARROT': 3, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 35 | 2 |
| 29 | 700 | 4 | 59214 | 3 | NE/NW | {'SHEEP': 3, 'COW': 4, 'GOOSE': 3} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {'GOOSE': 0, 'COW': 0, 'SHEEP': 0} | {} | {'WHEAT': 0, 'CARROT': 3, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 6} | 38 | 2 |

### BUY_LAND orders

- seq 337 (d14 h1): before=['NW'] -> change observed at seq 338 (d14 h2): NE/NW

### Animal purchase orders

- seq 1 (d0 h1): GOOSE x2 (standing before: 0) -> placement observed at seq 6 (d0 h6)
- seq 96 (d4 h0): COW x1 (standing before: 0) -> placement observed at seq 216 (d9 h0)
- seq 144 (d6 h0): SHEEP x1 (standing before: 0) -> placement observed at seq 333 (d13 h21)
- seq 168 (d7 h0): COW x1 (standing before: 0) -> placement observed at seq 216 (d9 h0)
- seq 338 (d14 h2): SHEEP x1 (standing before: 1) -> placement observed at seq 359 (d14 h23)
- seq 339 (d14 h3): COW x1 (standing before: 2) -> placement observed at seq 350 (d14 h14)
- seq 340 (d14 h4): GOOSE x1 (standing before: 2) -> placement observed at seq 344 (d14 h8)
- seq 341 (d14 h5): SHEEP x1 (standing before: 1) -> placement observed at seq 359 (d14 h23)
- seq 342 (d14 h6): COW x1 (standing before: 2) -> placement observed at seq 350 (d14 h14)

## 3. Seed-blocked planting opportunities (representative)

Criterion: hour>=4, day<29, >=1 empty owned non-animal-line tile, total seeds == 0, nearest worker dist + 2 <= hours left (hours_left = 24 - hour)
Total qualifying decisions: **33** (per day: {'0': 13, '1': 18, '2': 2})

| day | seq | h | empty crop pos | seeds | nearest worker dist | hours left |
|---|---|---|---|---|---|---|
| 0 | 9 | 9 | 8 | all-zero | 1 | 15 |
| 1 | 28 | 4 | 8 | all-zero | 3 | 20 |
| 2 | 69 | 21 | 2 | all-zero | 0 | 3 |

## 4. Final five decisions

### seq 714 — step 714 d29 h18
- cash 62165, shed `{'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0, 'EGG': 0, 'MILK': 0, 'WOOL': 0, 'FERTILIZER': 0, 'GOOSE': 0, 'COW': 0, 'SHEEP': 0}`, carried `{'FERTILIZER': 1}`
- farmer: `['PASS']`
- hand 0: `['PASS']`
- hand 1: `['EAST']`
- hand 2: `['PASS']`
- market (0): `[]`
### seq 715 — step 715 d29 h19
- cash 62165, shed `{'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0, 'EGG': 0, 'MILK': 0, 'WOOL': 0, 'FERTILIZER': 0, 'GOOSE': 0, 'COW': 0, 'SHEEP': 0}`, carried `{'FERTILIZER': 1}`
- farmer: `['PASS']`
- hand 0: `['PASS']`
- hand 1: `['EAST']`
- hand 2: `['PASS']`
- market (0): `[]`
### seq 716 — step 716 d29 h20
- cash 62165, shed `{'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0, 'EGG': 0, 'MILK': 0, 'WOOL': 0, 'FERTILIZER': 0, 'GOOSE': 0, 'COW': 0, 'SHEEP': 0}`, carried `{'FERTILIZER': 1}`
- farmer: `['PASS']`
- hand 0: `['PASS']`
- hand 1: `['EAST']`
- hand 2: `['PASS']`
- market (0): `[]`
### seq 717 — step 717 d29 h21
- cash 62165, shed `{'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0, 'EGG': 0, 'MILK': 0, 'WOOL': 0, 'FERTILIZER': 0, 'GOOSE': 0, 'COW': 0, 'SHEEP': 0}`, carried `{'FERTILIZER': 1}`
- farmer: `['PASS']`
- hand 0: `['PASS']`
- hand 1: `['DROP']`
- hand 2: `['PASS']`
- market (0): `[]`
### seq 718 — step 718 d29 h22
- cash 62165, shed `{'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0, 'EGG': 0, 'MILK': 0, 'WOOL': 0, 'FERTILIZER': 1, 'GOOSE': 0, 'COW': 0, 'SHEEP': 0}`, carried `{}`
- farmer: `['PASS']`
- hand 0: `['PASS']`
- hand 1: `['PASS']`
- hand 2: `['PASS']`
- market (1): `[['SELL', 'FERTILIZER', 1]]`

### Terminal state

- statuses ['DONE', 'DONE'], rewards [62241.0, 3000.0], money **62241.0**
- quads ['NW', 'NE'], hands 3
- shed `{'WHEAT': 0, 'CARROT': 0, 'TOMATO': 0, 'STRAWBERRY': 0, 'MELON': 0, 'EGG': 0, 'MILK': 0, 'WOOL': 0, 'FERTILIZER': 0, 'GOOSE': 0, 'COW': 0, 'SHEEP': 0}`
- carried `{}`

### Final-day h23 dependency flags

(none)
