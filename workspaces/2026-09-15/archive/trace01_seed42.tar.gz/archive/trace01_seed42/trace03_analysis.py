"""
TRACE-03 — read-only utilization audit of saved TRACE-01 artifacts.
Inputs:  trace.jsonl, terminal_state.json (TRACE-01 directory only).
Outputs: trace03_report.json, trace03_report.md (this directory).
No agent edits, verifier edits, installs, submissions, or simulation runs.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
recs = [json.loads(l) for l in open(os.path.join(HERE, "trace.jsonl"))]
term = json.load(open(os.path.join(HERE, "terminal_state.json")))

SPECIES = ("GOOSE", "COW", "SHEEP")
STRUCT_OF = {"GOOSE": "COOP", "COW": "PASTURE", "SHEEP": "PASTURE"}
WORK_OPS = ("PLANT", "WATER", "HARVEST", "FERTILIZE", "DIG", "BUILD_COOP",
            "BUILD_PASTURE", "PLACE", "FEED", "CARE", "COLLECT_FERTILIZER",
            "PICKUP", "DROP")
INSTALL_OPS = ("BUILD_COOP", "BUILD_PASTURE", "PLACE")


def farm0(obs):
    return obs["farms"][0]


def priv(obs):
    return obs.get("private") or {}


def units(rec):
    a = rec["action"] or {}
    return [a.get("farmer")] + list(a.get("hands") or [])


def q_of(pos):
    return ("N" if pos[1] < 5 else "S") + ("W" if pos[0] < 5 else "E")


def animal_line(pos):
    return pos[1] in (4, 5)


def owned_tiles(obs):
    ownd = set(farm0(obs).get("unlocked_quadrants", ["NW"]))
    out = []
    for y, trow in enumerate(farm0(obs)["tiles"]):
        for x, t in enumerate(trow):
            if q_of((x, y)) in ownd:
                out.append(((x, y), t))
    return out


def empty_owned_crop_cells(obs):
    return [pos for pos, t in owned_tiles(obs)
            if t is None and not animal_line(pos)]


def seed_totals(obs):
    s = priv(obs).get("seeds", {}) or {}
    return sum(int(v) for v in s.values()), dict(s)


def unplaced_animals(obs):
    """Species counts held unplaced (shed + worker inventories)."""
    counts = {k: 0 for k in SPECIES}
    sh = priv(obs).get("shed", {}) or {}
    for k in SPECIES:
        counts[k] += int(sh.get(k, 0))
    for inv in priv(obs).get("inventories", []) or []:
        for k in SPECIES:
            counts[k] += int((inv or {}).get(k, 0))
    return counts


def compatible_free_cell(obs, species):
    """Animal-line cell that is buildable (None/WEED) or an empty matching
    structure for this species (candidate's own site semantics)."""
    want = STRUCT_OF[species]
    for pos, t in owned_tiles(obs):
        if not animal_line(pos):
            continue
        if t is None or t == "LOCKED":
            if t is None:
                return True
            continue
        if isinstance(t, dict):
            if t.get("kind") == "WEED":
                return True
            if (t.get("kind") in ("COOP", "PASTURE") and "animal" not in t
                    and t.get("kind") == want):
                return True
    return False


def day_records(day):
    return [r for r in recs if r["obs_day"] == day]


# ===========================================================================
# 1. LABOR AUDIT
# ===========================================================================
per_day_ops = {}          # day -> op -> count
pass_count = {}           # day -> PASS worker-decisions
pass_seed_opp = {}        # day -> PASS while (empty crop cell AND seeds held)
pass_animal_opp = {}      # day -> PASS while (unplaced animal AND compatible cell)

for r in recs:
    d = r["obs_day"]
    obs = r["input_observation"]
    acts = units(r)
    has_empty = bool(empty_owned_crop_cells(obs))
    seeds_total, _ = seed_totals(obs)
    unplaced = unplaced_animals(obs)
    animal_opp = any(unplaced[k] > 0 and compatible_free_cell(obs, k)
                     for k in SPECIES)
    for wi, a in enumerate(acts):
        if not a:
            continue
        op = a[0]
        per_day_ops.setdefault(d, {})
        per_day_ops[d][op] = per_day_ops[d].get(op, 0) + 1
        if op == "PASS":
            pass_count[d] = pass_count.get(d, 0) + 1
            if has_empty and seeds_total > 0:
                pass_seed_opp[d] = pass_seed_opp.get(d, 0) + 1
            if animal_opp:
                pass_animal_opp[d] = pass_animal_opp.get(d, 0) + 1

# ===========================================================================
# 2. PLANTING THROUGHPUT
# ===========================================================================
throughput = []
held_all_day_no_plant = []
for d in range(30):
    dr = day_records(d)
    if not dr:
        continue
    first_h4 = next((r for r in dr if r["obs_hour"] >= 4), None)
    last = dr[-1]
    seeds_h4, _ = seed_totals(first_h4["input_observation"]) if first_h4 else (None, None)
    seeds_first, _ = seed_totals(dr[0]["input_observation"])
    seeds_last, _ = seed_totals(last["input_observation"])
    plants_issued = 0
    seeds_purchased = 0
    for r in dr:
        for a in units(r):
            if a and a[0] == "PLANT":
                plants_issued += 1
        for o in ((r["action"] or {}).get("market") or []):
            if isinstance(o, list) and len(o) >= 3 and o[0] == "BUY_SEED":
                try:
                    seeds_purchased += int(o[2])
                except Exception:
                    pass
    throughput.append({
        "day": d,
        "seq_range": [dr[0]["seq"], last["seq"]],
        "seeds_at_first_h4_obs": seeds_h4,
        "plant_actions": plants_issued,
        "seeds_purchased": seeds_purchased,
        "seeds_at_first_decision": seeds_first,
        "seeds_at_last_decision": seeds_last,
    })
    if seeds_first > 0 and seeds_last > 0 and plants_issued == 0:
        held_all_day_no_plant.append({
            "day": d, "seq_range": [dr[0]["seq"], last["seq"]],
            "seeds_first": seeds_first, "seeds_last": seeds_last,
            "seeds_purchased": seeds_purchased,
        })

# ===========================================================================
# 3. LAND GATE FORENSICS
# ===========================================================================
land_rows = []
for r in recs:
    if r["obs_hour"] > 3:
        continue
    obs = r["input_observation"]
    ownd = set(farm0(obs).get("unlocked_quadrants", ["NW"]))
    if len(ownd) >= 4 or len(ownd) < 1:
        continue
    f = farm0(obs)
    crops = sum(1 for pos, t in owned_tiles(obs)
                if isinstance(t, dict) and t.get("kind") == "PLANT")
    density = crops / max(1, 20 * len(ownd))
    urgent = sum(1 for pos, t in owned_tiles(obs)
                 if isinstance(t, dict) and t.get("kind") == "PLANT"
                 and not t.get("watered_today", False)
                 and int(t.get("consecutive_unwatered", 0)) >= 1)
    cost = {1: 1000, 2: 2000, 3: 4000}[len(ownd)]
    cash = float(f.get("money", 0))
    if r["obs_day"] > 17:
        cls = "day>17"
    elif density < 0.80:
        cls = "density<0.80"
    elif cash < cost + 1600:
        cls = "cash<cost+1600"
    else:
        cls = "none_failed"
    land_rows.append({
        "seq": r["seq"], "day": r["obs_day"], "hour": r["obs_hour"],
        "cash": cash, "crops": crops, "owned": len(ownd),
        "density": round(density, 4), "urgent_cuw_ge1": urgent,
        "land_cost": cost, "class": cls,
    })

land_by_day = {}
for row in land_rows:
    land_by_day.setdefault(row["day"], {}).setdefault(row["class"], []).append(row)
land_class_summary = {}
for cls in ("day>17", "density<0.80", "cash<cost+1600", "none_failed"):
    rows = [x for x in land_rows if x["class"] == cls]
    land_class_summary[cls] = {
        "count": len(rows),
        "first_seq": rows[0]["seq"] if rows else None,
        "last_seq": rows[-1]["seq"] if rows else None,
        "days": sorted(set(x["day"] for x in rows)),
    }

# ===========================================================================
# 4. ANIMAL PLACEMENT FORENSICS
# ===========================================================================
held_series = {k: [] for k in SPECIES}   # species -> list of (seq, count)
for r in recs:
    up = unplaced_animals(r["input_observation"])
    for k in SPECIES:
        held_series[k].append((r["seq"], up[k]))

intervals = []
for k in SPECIES:
    run = None
    for seq, cnt in held_series[k]:
        if cnt > 0:
            if run is None:
                run = {"species": k, "start": seq, "end": seq,
                       "max_held": cnt, "decisions": 0,
                       "decisions_with_compatible_cell": 0}
            run["end"] = seq
            run["max_held"] = max(run["max_held"], cnt)
            run["decisions"] += 1
            rec = recs[seq]
            if compatible_free_cell(rec["input_observation"], k):
                run["decisions_with_compatible_cell"] += 1
        else:
            if run is not None:
                intervals.append(run)
                run = None
    if run is not None:
        intervals.append(run)

for iv in intervals:
    install_counts = {"BUILD_COOP": 0, "BUILD_PASTURE": 0, "PLACE": 0,
                      "PICKUP_animal": 0}
    for r in recs:
        if not (iv["start"] <= r["seq"] <= iv["end"]):
            continue
        for a in units(r):
            if not a:
                continue
            if a[0] in INSTALL_OPS:
                install_counts[a[0]] += 1
            if a[0] == "PICKUP" and len(a) > 1 and a[1] in SPECIES:
                install_counts["PICKUP_animal"] += 1
    iv["install_actions_in_interval"] = install_counts
    iv["compatible_cell"] = ("always" if iv["decisions_with_compatible_cell"] == iv["decisions"]
                             else ("never" if iv["decisions_with_compatible_cell"] == 0
                                   else f"{iv['decisions_with_compatible_cell']}/{iv['decisions']} decisions"))

# ===========================================================================
# SAVE
# ===========================================================================
report = {
    "sources": ["trace.jsonl", "terminal_state.json"],
    "labor_audit": {
        "per_day_operation_totals": {str(d): per_day_ops.get(d, {}) for d in range(30)},
        "per_day_pass_worker_decisions": {str(d): pass_count.get(d, 0) for d in range(30)},
        "per_day_pass_with_empty_cell_and_seeds": {str(d): pass_seed_opp.get(d, 0) for d in range(30)},
        "per_day_pass_with_unplaced_animal_and_compatible_cell": {str(d): pass_animal_opp.get(d, 0) for d in range(30)},
    },
    "planting_throughput": throughput,
    "days_seeds_held_all_day_zero_plants": held_all_day_no_plant,
    "land_gate_forensics": {
        "classification_order": ["day>17", "density<0.80", "cash<cost+1600", "none_failed"],
        "class_summary": land_class_summary,
        "per_day_class_counts": {str(d): {c: len(v) for c, v in land_by_day[d].items()}
                                 for d in sorted(land_by_day)},
        "all_rows": land_rows,
    },
    "animal_placement_forensics": intervals,
}
with open(os.path.join(HERE, "trace03_report.json"), "w") as f:
    json.dump(report, f, indent=1)

# ---------- markdown ----------
md = ["# TRACE-03 utilization audit report\n",
      "## 1. Labor audit\n",
      "### Per-day worker-decision totals by operation\n",
      "| day | PASS | moves(E/W/N/S) | PLANT | WATER | HARV | FERT | DIG | BUILD | PLACE | FEED | CARE | COLLECT | PICKUP | DROP | other |",
      "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
MOVE = {"EAST", "WEST", "NORTH", "SOUTH"}
for d in range(30):
    ops = per_day_ops.get(d, {})
    if not ops:
        continue
    moves = sum(ops.get(m, 0) for m in MOVE)
    def g(*names):
        return sum(ops.get(n, 0) for n in names)
    known = set(MOVE) | set(WORK_OPS) | {"PASS"}
    other = sum(v for k, v in ops.items() if k not in known)
    md.append(f"| {d} | {ops.get('PASS', 0)} | {moves} | {ops.get('PLANT', 0)} | "
              f"{ops.get('WATER', 0)} | {g('HARVEST')} | {ops.get('FERTILIZE', 0)} | "
              f"{g('DIG')} | {g('BUILD_COOP', 'BUILD_PASTURE')} | {ops.get('PLACE', 0)} | "
              f"{ops.get('FEED', 0)} | {ops.get('CARE', 0)} | "
              f"{ops.get('COLLECT_FERTILIZER', 0)} | {ops.get('PICKUP', 0)} | "
              f"{ops.get('DROP', 0)} | {other} |")
md.append("\n### PASS worker-decisions per day, with opportunity context\n")
md.append("| day | total PASS | PASS w/ empty crop cell AND seeds held | PASS w/ unplaced animal AND compatible cell |")
md.append("|---|---|---|---|")
for d in range(30):
    if pass_count.get(d, 0) or pass_seed_opp.get(d, 0) or pass_animal_opp.get(d, 0):
        md.append(f"| {d} | {pass_count.get(d, 0)} | {pass_seed_opp.get(d, 0)} | "
                  f"{pass_animal_opp.get(d, 0)} |")
md.append("\n## 2. Planting throughput\n")
md.append("| day | seq range | seeds @ first h>=4 obs | PLANTs issued | seeds purchased | seeds @ last decision |")
md.append("|---|---|---|---|---|---|")
for t in throughput:
    md.append(f"| {t['day']} | {t['seq_range'][0]}–{t['seq_range'][1]} | "
              f"{t['seeds_at_first_h4_obs']} | {t['plant_actions']} | "
              f"{t['seeds_purchased']} | {t['seeds_at_last_decision']} |")
md.append("\n### Days with seeds held all day and zero PLANT actions\n")
if not held_all_day_no_plant:
    md.append("(none)")
for h in held_all_day_no_plant:
    md.append(f"- day {h['day']}: seq {h['seq_range'][0]}–{h['seq_range'][1]} "
              f"(seeds first={h['seeds_first']}, last={h['seeds_last']}, "
              f"purchased that day={h['seeds_purchased']})")
md.append("\n## 3. Land gate forensics (decisions h<=3, owned<4)\n")
md.append("Classification order: day>17, then density<0.80, then cash<cost+1600, else none_failed.\n")
for cls, s in land_class_summary.items():
    md.append(f"- **{cls}**: {s['count']} decisions "
              f"(first seq {s['first_seq']}, last seq {s['last_seq']}, days {s['days']})")
md.append("\n| day | class counts |")
md.append("|---|---|")
for d in sorted(land_by_day):
    cc = land_by_day[d]
    md.append(f"| {d} | " + ", ".join(f"{c}:{len(v)}" for c, v in sorted(cc.items())) + " |")
md.append("\n## 4. Animal placement forensics (unplaced-held intervals)\n")
md.append("| species | seq range | days spanned | max held | compatible free cell existed | INSTALL actions in interval |")
md.append("|---|---|---|---|---|---|")
for iv in intervals:
    d0 = recs[iv["start"]]["obs_day"]
    d1 = recs[iv["end"]]["obs_day"]
    ia = iv["install_actions_in_interval"]
    ia_txt = (f"COOP:{ia['BUILD_COOP']} PASTURE:{ia['BUILD_PASTURE']} "
              f"PLACE:{ia['PLACE']} PICKUP_an:{ia['PICKUP_animal']}")
    md.append(f"| {iv['species']} | {iv['start']}–{iv['end']} | d{d0}–d{d1} | "
              f"{iv['max_held']} | {iv['compatible_cell']} | {ia_txt} |")
with open(os.path.join(HERE, "trace03_report.md"), "w") as f:
    f.write("\n".join(md) + "\n")

# ---------- console ----------
print("=== 1. LABOR AUDIT ===")
tot_pass = sum(pass_count.values())
tot_units = sum(sum(v.values()) for v in per_day_ops.values())
print(f"worker-decisions total: {tot_units}, PASS total: {tot_pass}")
print("per-day PASS (d0-29):", [pass_count.get(d, 0) for d in range(30)])
print("PASS w/ empty-cell+seeds per day:", [pass_seed_opp.get(d, 0) for d in range(30)])
print("PASS w/ unplaced-animal+compatible-cell per day:",
      [pass_animal_opp.get(d, 0) for d in range(30)])
print("\n=== 2. PLANTING THROUGHPUT ===")
for t in throughput:
    print(f"d{t['day']:>2} seq{t['seq_range'][0]:>3}-{t['seq_range'][1]:>3} "
          f"seeds@h4={t['seeds_at_first_h4_obs']} plants={t['plant_actions']:>2} "
          f"bought={t['seeds_purchased']:>2} seeds@last={t['seeds_at_last_decision']}")
print("days seeds held all day + zero plants:",
      [(h['day'], h['seq_range']) for h in held_all_day_no_plant] or "none")
print("\n=== 3. LAND GATE ===")
for cls, s in land_class_summary.items():
    print(f"{cls:>16}: {s['count']:>3} decisions, first {s['first_seq']}, last {s['last_seq']}")
print("\n=== 4. ANIMAL INTERVALS ===")
for iv in intervals:
    d0 = recs[iv["start"]]["obs_day"]; d1 = recs[iv["end"]]["obs_day"]
    ia = iv["install_actions_in_interval"]
    print(f"{iv['species']:>5} seq {iv['start']:>3}-{iv['end']:>3} (d{d0}-d{d1}) "
          f"max_held={iv['max_held']} cell={iv['compatible_cell']} "
          f"install=COOP:{ia['BUILD_COOP']} PAST:{ia['BUILD_PASTURE']} "
          f"PLACE:{ia['PLACE']} PICKUP_an:{ia['PICKUP_animal']}")
print("\nsaved: trace03_report.json, trace03_report.md")
