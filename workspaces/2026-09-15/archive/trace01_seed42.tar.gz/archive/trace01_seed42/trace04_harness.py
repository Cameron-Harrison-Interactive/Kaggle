"""
TRACE-01 — one isolated observation/action capture run (approved task).

Frozen (never modified): astra_live.py, astra_live2.py, v58_champion.py,
verifiers, logs, playbook. This harness only READS the frozen candidate and
writes its artifacts into this directory.

Per-decision capture:
  * deep-copy of the ACTUAL observation supplied to the agent call
  * exactly one call to the frozen agent; deep-copy of the returned action
  * the NEXT supplied observation is attached to the previous record when the
    next call happens (no env.steps index inference)
  * terminal environment state saved explicitly after the run
"""
import copy
import glob
import gzip
import hashlib
import importlib.util
import json
import os
import sys
import time
import traceback
from datetime import datetime, timezone

RUN_ID = "TRACE-04-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
HERE = os.path.dirname(os.path.abspath(__file__))
AGENT_PATH = "/home/user/war/astra_live3.py"
ENV_NAME = "kagg" + "riculture"  # the env name (Kaggle+agriculture spelling)
SEED = 42
EPISODE_STEPS = 720
OPPONENT_DESC = "harness-defined PASS agent (seat 1)"

errors = []


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def to_plain(x):
    if not isinstance(x, dict) and hasattr(x, "toDict"):
        try:
            x = x.toDict()
        except Exception:
            pass
    if isinstance(x, dict):
        return {str(k): to_plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [to_plain(v) for v in x]
    if isinstance(x, (str, int, float, bool)) or x is None:
        return x
    return repr(x)


def oget(o, key, default=None):
    try:
        return o[key]
    except Exception:
        return getattr(o, key, default)


manifest = {
    "run_id": RUN_ID,
    "task": "TRACE-01: one isolated observation/action capture",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "env_name": ENV_NAME,
    "seed": SEED,
    "episodeSteps_requested": EPISODE_STEPS,
    "candidate": {"path": AGENT_PATH, "seat": 0, "loaded_without_modification": True},
    "opponent": OPPONENT_DESC,
    "errors": errors,
}


def abort(msg):
    errors.append(msg)
    manifest["status"] = "ABORTED"
    with open(os.path.join(HERE, "trace04_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print("ABORT:", msg)
    sys.exit(2)


# --- dependency checks: report and stop; never install/recreate ---
try:
    import kaggle_environments as ke
except Exception as e:  # pragma: no cover
    abort(f"missing dependency kaggle_environments: {e!r}")

manifest["kaggle_environments_version"] = getattr(ke, "__version__", "unknown")
pkg_dir = os.path.dirname(ke.__file__)
cands = [p for p in glob.glob(os.path.join(pkg_dir, "envs", "kaggr*", "*.py"))
         if "beginner" not in p]
if not cands:
    abort("engine source file not found under installed package")
manifest["engine_source_path"] = cands[0]
manifest["engine_source_sha256"] = sha256_file(cands[0])

if not os.path.exists(AGENT_PATH):
    abort(f"missing frozen agent: {AGENT_PATH}")
manifest["agent_sha256_before"] = sha256_file(AGENT_PATH)

# --- load the frozen candidate read-only ---
spec = importlib.util.spec_from_file_location("astra_live2_frozen_TRACE01", AGENT_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
orig_agent = mod.agent

# --- environment (requested config recorded; resolved config captured) ---
env = ke.make(ENV_NAME, configuration={"seed": SEED, "episodeSteps": EPISODE_STEPS},
              debug=False)
manifest["requested_configuration"] = {"seed": SEED, "episodeSteps": EPISODE_STEPS}
manifest["resolved_configuration"] = to_plain(env.configuration)

records = []
_pending = {"seq": None}


def traced_agent(obs, configuration=None):
    # deep-copy the ACTUAL observation supplied to this call
    try:
        obs_plain = to_plain(copy.deepcopy(obs))
    except Exception as e:
        errors.append(f"seq {len(records)}: deepcopy of supplied observation failed: {e!r}")
        raise

    # this call's supplied observation is the "next supplied observation"
    # for the previous decision (captured directly, not via env.steps)
    if _pending["seq"] is not None:
        records[_pending["seq"]]["next_observation"] = obs_plain

    farm0 = oget(obs, "farms")[0]
    positions = [tuple(farm0["farmer"])] + [tuple(p) for p in (farm0.get("hands") or [])]
    priv = oget(obs, "private") or {}
    inventories = to_plain(copy.deepcopy(priv.get("inventories", [])))

    rec = {
        "seq": len(records),
        "run_id": RUN_ID,
        "obs_step": oget(obs, "step"),
        "obs_day": oget(obs, "day"),
        "obs_hour": oget(obs, "hour"),
        "obs_player": oget(obs, "player"),
        "worker_positions": [list(p) for p in positions],
        "worker_inventories": inventories,
        "input_observation": obs_plain,
        "action": None,
        "next_observation": None,
    }
    records.append(rec)

    cfg = configuration if configuration is not None else env.configuration
    action = orig_agent(obs, cfg)  # exactly one agent call per decision
    rec["action"] = to_plain(copy.deepcopy(action))
    _pending["seq"] = rec["seq"]
    return action


def pass_agent(obs, configuration=None):
    """Direct PASS opponent defined in the harness (seat 1)."""
    farm = obs["farms"][obs["player"]]
    n = 1 + len(farm.get("hands") or [])
    return {"farmer": ["PASS"], "hands": [["PASS"]] * (n - 1), "market": []}


t0 = time.time()
try:
    env.run([traced_agent, pass_agent])
except Exception:
    errors.append("RUN FAILED:\n" + traceback.format_exc())
manifest["run_seconds"] = round(time.time() - t0, 2)

# --- terminal state, captured explicitly (there may be no further agent call) ---
try:
    terminal = {
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "statuses": [to_plain(s.status) for s in env.state],
        "rewards": [to_plain(s.reward) for s in env.state],
        "observations": [to_plain(copy.deepcopy(s.observation)) for s in env.state],
    }
except Exception:
    terminal = {"error": traceback.format_exc()}
    errors.append("terminal capture failed")

# --- save artifacts ---
trace_path = os.path.join(HERE, "trace04_trace.jsonl")
with open(trace_path, "w") as f:
    for rec in records:
        f.write(json.dumps(rec) + "\n")

terminal_path = os.path.join(HERE, "trace04_terminal_state.json")
with open(terminal_path, "w") as f:
    json.dump(terminal, f)

replay_path = os.path.join(HERE, "trace04_replay.json.gz")
with gzip.open(replay_path, "wt") as f:
    json.dump(to_plain(env.steps), f)

manifest["agent_sha256_after"] = sha256_file(AGENT_PATH)
manifest["agent_unchanged"] = (manifest["agent_sha256_before"]
                               == manifest["agent_sha256_after"])
manifest["harness_path"] = os.path.abspath(__file__)
manifest["harness_sha256"] = sha256_file(os.path.abspath(__file__))
manifest["decision_count"] = len(records)
manifest["artifacts"] = {}
for p in (trace_path, terminal_path, replay_path):
    manifest["artifacts"][os.path.basename(p)] = {
        "bytes": os.path.getsize(p), "sha256": sha256_file(p)}
manifest["notes"] = [
    "The candidate's internal logger appends to /tmp/astra_econ2.txt; that "
    "behavior is left unchanged. The pre-existing mixed log is NOT used as "
    "evidence for this run.",
    "Full env.steps serialized post-run into replay.json.gz.",
    "trace.jsonl: per decision — deep-copied observation actually supplied, "
    "deep-copied returned action, and the next supplied observation (attached "
    "on the following call). Terminal state is separate in terminal_state.json.",
]
manifest["status"] = "FAILED" if (errors and not records) else (
    "COMPLETED_WITH_ERRORS" if errors else "COMPLETED")
with open(os.path.join(HERE, "trace04_manifest.json"), "w") as f:
    json.dump(manifest, f, indent=2)

try:
    final_money = terminal["observations"][0]["farms"][0]["money"]
except Exception:
    final_money = None
print(json.dumps({
    "run_id": RUN_ID,
    "status": manifest["status"],
    "decisions": len(records),
    "errors": errors[:3],
    "statuses": terminal.get("statuses"),
    "final_money": final_money,
    "artifacts": {k: v["bytes"] for k, v in manifest["artifacts"].items()},
}, indent=2))
