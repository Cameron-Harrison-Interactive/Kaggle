"""TRACE-05 analysis — where does nb3_tetsu_r5's +$91k (solo seed 42) come from?

Compares the TRACE-05 capture (Tetsu, seat 0, PASS opp, seed 42) against the
TRACE-04 capture (astra_live3, same conditions) decision by decision:
money by day, standing crop mix, quads, herd, crew, sell orders, realized
prices. Reads only stored artifacts; writes trace05_report.{json,md}.
"""
import json
from collections import Counter, defaultdict

HERE = "/home/user/trace01_seed42"
QUAD = lambda x, y: ("N" if y < 5 else "S") + ("W" if x < 5 else "E")


def load(path):
    rows = []
    for line in open(path):
        r = json.loads(line)
        rows.append(r)
    return rows


def farm_view(obs):
    """Snapshot derived from one supplied observation (pre-action state)."""
    seat = int(obs["player"])
    farm = obs["farms"][seat]
    priv = obs.get("private", {}) or {}
    owned = set(farm.get("unlocked_quadrants", ["NW"]))
    standing = Counter()
    empty_owned = 0
    animals = Counter()
    for y, row in enumerate(farm["tiles"]):
        for x, t in enumerate(row):
            if QUAD(x, y) not in owned:
                continue
            if t is None:
                empty_owned += 1
            elif isinstance(t, dict):
                if t.get("kind") == "PLANT":
                    standing[t["crop"]] += 1
                elif t.get("kind") in ("COOP", "PASTURE") and t.get("animal"):
                    animals[t["animal"]] += 1
    return {
        "day": int(obs["day"]), "hour": int(obs["hour"]),
        "money": float(farm.get("money", 0)),
        "owned": len(owned),
        "hands": len(farm.get("hands") or []),
        "standing": standing, "empty": empty_owned, "animals": animals,
        "seeds": dict(priv.get("seeds", {}) or {}),
        "prices": dict((obs.get("market", {}) or {}).get("prices", {}) or {}),
    }


def daily_series(rows):
    """Last observation of each day per metric (end-of-day state)."""
    by_day = {}
    for r in rows:
        v = farm_view(r["input_observation"])
        by_day[v["day"]] = v  # later rows overwrite -> h23 snapshot
    return by_day


def sell_orders(rows):
    """Aggregate market orders by day: item -> total qty sold/bought."""
    sells = defaultdict(Counter)
    buys = defaultdict(Counter)
    for r in rows:
        a = r.get("action") or {}
        d = int(r["input_observation"]["day"])
        for order in a.get("market", []) or []:
            if not isinstance(order, list) or len(order) < 2:
                continue
            op, item = order[0], order[1]
            qty = order[2] if len(order) > 2 else 1
            if op.startswith("SELL"):
                sells[d][item] += qty
            elif op.startswith("BUY"):
                buys[d][item] += qty
    return sells, buys


def main():
    tetsu = load(f"{HERE}/trace05_trace.jsonl")
    ours = load(f"{HERE}/trace04_trace.jsonl")
    T, O = daily_series(tetsu), daily_series(ours)
    Ts, Tb = sell_orders(tetsu)
    Os, Ob = sell_orders(ours)

    days = sorted(set(T) | set(O))
    lines = []
    lines.append("| day | Tetsu $ | ours $ | gap | T plants (mix) | O plants (mix) | T herd | O herd | T quads/hands | O quads/hands |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|")
    for d in days:
        t, o = T.get(d), O.get(d)
        if not t or not o:
            continue
        tmix = ",".join(f"{k[0]}{k[1:]}{v}" for k, v in sorted(t["standing"].items())) or "-"
        omix = ",".join(f"{k[0]}{k[1:]}{v}" for k, v in sorted(o["standing"].items())) or "-"
        therd = sum(t["animals"].values())
        oherd = sum(o["animals"].values())
        lines.append(
            f"| d{d} | {t['money']:,.0f} | {o['money']:,.0f} | {t['money']-o['money']:+,.0f} "
            f"| {sum(t['standing'].values())} ({tmix}) | {sum(o['standing'].values())} ({omix}) "
            f"| {therd} | {oherd} | {t['owned']}/{t['hands']} | {o['owned']}/{o['hands']} |")

    # cumulative revenue between consecutive days
    lines.append("")
    lines.append("## Daily revenue (delta money, incl. spends — sign of pressure)")
    lines.append("| day | Tetsu Δ$ | ours Δ$ | T sells | O sells |")
    lines.append("|---|---|---|---|---|")
    for i, d in enumerate(days):
        if d == 0:
            continue
        t_prev, o_prev = T.get(d - 1), O.get(d - 1)
        t, o = T.get(d), O.get(d)
        if not (t and o and t_prev and o_prev):
            continue
        tsel = ",".join(f"{k}x{v}" for k, v in sorted(Ts.get(d, {}).items())) or "-"
        osel = ",".join(f"{k}x{v}" for k, v in sorted(Os.get(d, {}).items())) or "-"
        lines.append(f"| d{d} | {t['money']-t_prev['money']:+,.0f} | {o['money']-o_prev['money']:+,.0f} | {tsel} | {osel} |")

    # totals by item across the season
    def season(counter_by_day):
        tot = Counter()
        for c in counter_by_day.values():
            tot.update(c)
        return tot
    lines.append("")
    lines.append(f"## Season sell totals — Tetsu: {dict(season(Ts))}")
    lines.append(f"## Season sell totals — ours: {dict(season(Os))}")
    lines.append(f"## Season buys — Tetsu: {dict(season(Tb))}")
    lines.append(f"## Season buys — ours: {dict(season(Ob))}")

    report = "\n".join(lines)
    open(f"{HERE}/trace05_report.md", "w").write(report)
    print(report)


main()
