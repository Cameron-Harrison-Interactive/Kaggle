"""
Kaggriculture v5.1 — no-late-SE fill-first scheduler.

Design goals:
  - No idle animal/barn routine. This version is crop-first.
  - Hire a big crew from turn 0, assign workers to sectors, and route them on different lanes.
  - Buy land only early enough to use it; never buy a late quadrant that cannot pay back.
  - Seed scheduler buys just-in-time: enough seed for empty plots + soon-to-empty harvest slots,
    but stops before endgame so seed bags do not remain dead cash at round 720.
  - Crop timing is explicit: fast crops keep cash flowing while slow crops mature.
  - All actions are LISTS, never bare strings.
  - __file__ guarded for Kaggle exec() loader.
"""

DEFAULT_DNA = {
    "target_hires": 12,
    "buy_land": 3,
    "land_reserve": 0,
    "max_land_buy_day": 20,
    "dump_turn": 690,
    "field_util_early": 96,
    "field_util_mid": 90,
    "field_util_late": 80,
    "melon_danger_opp": 6,
    "melon_crash_price": 185,
    "seed_buffer_early": 10,
    "seed_buffer_mid": 3,
    "use_brain": 1,
    "wheat_sell": 25,
    "carrot_sell": 32,
    "tomato_sell": 60,
    "strawberry_sell": 120,
    "melon_sell": 230,
    "fertilizer_sell": 105,
    "max_wheat_seed_bank": 6,
    "weed_panic": 999,
}


def _load_dna():
    import json, os
    dna = dict(DEFAULT_DNA)
    candidates = []
    try:
        candidates.append(os.path.join(os.path.dirname(__file__), "dna.json"))
    except Exception:
        pass
    candidates += ["Agent/dna.json", "dna.json"]
    for p in candidates:
        try:
            if os.path.exists(p):
                with open(p, "r") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    dna.update(data)
                break
        except Exception:
            pass
    return dna

DNA = _load_dna()
_BRAIN = None
_BRAIN_LOADED = False
_BRAIN_OK = False
_MEMORY = {"last_step": -1, "last_prices": {}, "price_dir": {}}

CROPS = {
    "WHEAT":      {"seed": 10,  "first": 2,  "maxday": 4,  "max_yield": 6, "ongoing": False},
    "CARROT":     {"seed": 20,  "first": 2,  "maxday": 3,  "max_yield": 4, "ongoing": False},
    "TOMATO":     {"seed": 50,  "first": 8,  "maxday": 8,  "max_yield": 4, "ongoing": True},
    "STRAWBERRY": {"seed": 100, "first": 10, "maxday": 10, "max_yield": 4, "ongoing": True},
    "MELON":      {"seed": 80,  "first": 10, "maxday": 12, "max_yield": 6, "ongoing": False},
}
PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]
LAND_PRICES = [1000, 2000, 4000]
# Forced expansion schedule by game day: NE, SW, SE. If we have the cash, buy.
LAND_DUE_DAYS = [2, 6, 11]
# Last planting day that can reasonably mature/harvest/drop/sell by step 720.
LAST_PLANT_DAY = {"MELON": 16, "STRAWBERRY": 14, "TOMATO": 20, "WHEAT": 24, "CARROT": 25}


def _load_brain():
    global _BRAIN, _BRAIN_LOADED, _BRAIN_OK
    if _BRAIN_LOADED:
        return _BRAIN, _BRAIN_OK
    _BRAIN_LOADED = True
    if not DNA.get("use_brain", 1):
        return None, False
    import os, pickle
    candidates = []
    try:
        candidates.append(os.path.join(os.path.dirname(__file__), "HI_Market_Brain.pkl"))
    except Exception:
        pass
    candidates += ["HI_Market_Brain.pkl", "Agent/HI_Market_Brain.pkl"]
    for p in candidates:
        try:
            if os.path.exists(p):
                with open(p, "rb") as f:
                    _BRAIN = pickle.load(f)
                _BRAIN_OK = True
                return _BRAIN, True
        except Exception:
            pass
    return None, False


def brain_sell(day, hour, price, qty):
    brain, ok = _load_brain()
    if not ok or not brain:
        return None
    try:
        import numpy as np
        return int(brain.predict(np.array([[day, hour, price, qty]], dtype="float32"))[0]) == 1
    except Exception:
        return None


def update_memory(step, prices):
    if step < _MEMORY.get("last_step", -1):
        _MEMORY["last_prices"] = {}
        _MEMORY["price_dir"] = {}
    last = _MEMORY.get("last_prices", {}) or {}
    dirs = {}
    for k, v in (prices or {}).items():
        dirs[k] = v - last.get(k, v)
    _MEMORY["last_prices"] = dict(prices or {})
    _MEMORY["price_dir"] = dirs
    _MEMORY["last_step"] = step


def safe_int(x, default=0):
    try:
        return int(x)
    except Exception:
        return default


def manhattan(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])


def _move_candidates(pos, target, idx):
    """Monotonic lane routing: workers choose different axis order, but never
    step away/backtrack just to make a fancy route. This stops the visible
    same-round backtracking while still reducing worker trains.
    """
    x, y = pos; tx, ty = target
    horiz = []
    vert = []
    if x < tx: horiz.append((["EAST"], (x + 1, y)))
    elif x > tx: horiz.append((["WEST"], (x - 1, y)))
    if y < ty: vert.append((["SOUTH"], (x, y + 1)))
    elif y > ty: vert.append((["NORTH"], (x, y - 1)))
    return (horiz + vert) if idx % 2 == 0 else (vert + horiz)


def route_step(pos, target, idx, board_size, reserved_next, tiles=None):
    if pos == target:
        return ["PASS"]

    def passable(nxt):
        nx, ny = nxt
        if not (0 <= nx < board_size and 0 <= ny < board_size):
            return False
        # Movement into locked land is allowed by the engine, but it wastes turns.
        # Treat LOCKED as a wall so workers do not wander into unopened quadrants.
        try:
            if tiles is not None and tiles[ny][nx] == "LOCKED":
                return False
        except Exception:
            pass
        return True

    for action, nxt in _move_candidates(pos, target, idx):
        if not passable(nxt):
            continue
        if nxt in reserved_next:
            continue
        reserved_next.add(nxt)
        return action

    # If both useful direct lanes are occupied, pass rather than wandering/backtracking.
    return ["PASS"]


def step_toward(pos, target):
    # Legacy wrapper for any old call sites.
    return route_step(pos, target, 0, 10, set(), None)


def shed_tiles(board_size):
    h = board_size // 2
    return [(h-1, h-1), (h, h-1), (h-1, h), (h, h)]


def is_shed_tile(pos, board_size):
    return tuple(pos) in set(shed_tiles(board_size))


def scan_farm(farm, day):
    tiles = farm.get("tiles", []) or []
    info = {
        "empty": [], "weeds": [], "plants": [], "harvestable": [], "unwatered": [],
        "active": {c: 0 for c in CROPS}, "mature_soon": {c: 0 for c in CROPS},
        "animals": [], "structures": []
    }
    for y, row in enumerate(tiles):
        for x, t in enumerate(row):
            if t is None:
                info["empty"].append((x, y))
            elif t == "LOCKED":
                continue
            elif isinstance(t, dict):
                kind = t.get("kind")
                if kind == "WEED":
                    info["weeds"].append((x, y))
                elif kind == "PLANT":
                    crop = t.get("crop")
                    if crop in CROPS:
                        cd = CROPS[crop]
                        age = day - t.get("planted_day", day)
                        info["active"][crop] += 1
                        info["plants"].append((x, y, crop, age, t))
                        if t.get("yield_units", 0) > 0 and age >= cd["first"]:
                            # Only target crops when a worker can actually harvest profitably now.
                            # Before this, hands walked to wheat/carrot too early and waited there.
                            ready_now = (not cd["ongoing"] and age >= cd["maxday"]) or (cd["ongoing"] and t.get("yield_units", 0) >= 2)
                            if ready_now:
                                info["harvestable"].append((x, y, crop, age, t))
                        if not cd["ongoing"] and age >= cd["maxday"] - 1:
                            info["mature_soon"][crop] += 1
                        if not t.get("watered_today", False):
                            info["unwatered"].append((x, y, crop, age, t))
                elif kind in ("COOP", "PASTURE"):
                    info["structures"].append((x, y, kind, t))
                    if "animal" in t:
                        info["animals"].append((x, y, t.get("animal"), t))
    return info, len(tiles)



def reserve_coord(info, coord):
    x, y = coord
    try:
        info["empty"] = [p for p in info.get("empty", []) if p != coord]
        info["weeds"] = [p for p in info.get("weeds", []) if p != coord]
        info["harvestable"] = [h for h in info.get("harvestable", []) if not (h[0] == x and h[1] == y)]
        info["unwatered"] = [u for u in info.get("unwatered", []) if not (u[0] == x and u[1] == y)]
    except Exception:
        pass

def unlocked_usable_tiles(farm, info):
    n = 0
    for row in farm.get("tiles", []) or []:
        for t in row:
            if t != "LOCKED":
                n += 1
    # reserve structures and a little practical movement slack around shed
    return max(0, n - len(info.get("structures", [])))


def crop_value(crop, prices, day, opp_info=None):
    cd = CROPS[crop]
    if day > LAST_PLANT_DAY.get(crop, 99):
        return -10**9
    price = prices.get(crop, cd["seed"] * 2)
    val = cd["max_yield"] * price - cd["seed"]
    # cash-flow bonus for fast crops; long crops are good but cannot be everything.
    if crop == "CARROT": val *= 1.20
    if crop == "WHEAT": val *= 0.95
    if crop == "TOMATO" and day > 12: val *= 0.75
    if crop == "STRAWBERRY" and day > 8: val *= 0.70
    if crop == "MELON":
        opp_melon = ((opp_info or {}).get("active", {}) or {}).get("MELON", 0)
        if opp_melon >= int(DNA.get("melon_danger_opp", 6)) or prices.get("MELON", 250) <= int(DNA.get("melon_crash_price", 185)):
            val *= 0.35
        elif day <= 6 and price >= 235:
            val *= 1.15
    return val


def desired_mix(info, opp_info, prices, day, step, farm):
    targets = {c: 0 for c in CROPS}
    if step >= int(DNA.get("dump_turn", 690)):
        return targets
    usable = unlocked_usable_tiles(farm, info)
    if day <= 10:
        util = int(DNA.get("field_util_early", 92)) / 100.0
    elif day <= 22:
        # After SW/SE are bought, burn cash into crops instead of hoarding money.
        util = max(int(DNA.get("field_util_mid", 82)) / 100.0, 0.92)
    else:
        util = int(DNA.get("field_util_late", 80)) / 100.0
    desired_total = max(0, int(usable * util))
    # As cutoff approaches, do not ask for impossible plants.
    eligible = [c for c in CROPS if day <= LAST_PLANT_DAY[c]]
    if not eligible:
        return targets
    ranked = sorted(eligible, key=lambda c: crop_value(c, prices, day, opp_info), reverse=True)

    # Opening philosophy: cheap wheat ignition first, then melon layer.
    # Wheat is not the highest value, but it is cheap enough to fill more plots immediately
    # and starts the cash flywheel while melons mature.
    if day <= 1:
        # True ignition: mostly cheap fast crops. Melon is only a small starter layer.
        targets["WHEAT"] = int(desired_total * 0.62)
        targets["CARROT"] = int(desired_total * 0.26)
        if "MELON" in eligible: targets["MELON"] = int(desired_total * 0.10)
        if "TOMATO" in eligible: targets["TOMATO"] = max(0, desired_total - sum(targets.values()))
    elif day <= 5:
        # After cash starts moving, add melon — but do not choke workers with melon-only seed.
        if "MELON" in eligible: targets["MELON"] = int(desired_total * 0.26)
        targets["CARROT"] = int(desired_total * 0.34)
        targets["WHEAT"] = int(desired_total * 0.24)
        if "TOMATO" in eligible: targets["TOMATO"] = int(desired_total * 0.12)
        if "STRAWBERRY" in eligible: targets["STRAWBERRY"] = max(0, desired_total - sum(targets.values()))
    elif day <= 12:
        # Mid: keep melon pressure while fast crops fund expansion/workers.
        if "MELON" in eligible: targets["MELON"] += int(desired_total * 0.24)
        targets["CARROT"] += int(desired_total * 0.34)
        targets["WHEAT"] += int(desired_total * 0.18)
        if "TOMATO" in eligible: targets["TOMATO"] += int(desired_total * 0.14)
        if "STRAWBERRY" in eligible: targets["STRAWBERRY"] += max(0, desired_total - sum(targets.values()))
    elif day <= 17:
        # Cash-burn expansion push: if SW/SE are open and we have money, turn outer rings into melon.
        if "MELON" in eligible: targets["MELON"] += int(desired_total * 0.46)
        if "TOMATO" in eligible: targets["TOMATO"] += int(desired_total * 0.22)
        if "STRAWBERRY" in eligible: targets["STRAWBERRY"] += int(desired_total * 0.10)
        targets["CARROT"] += int(desired_total * 0.14)
        targets["WHEAT"] += max(0, desired_total - sum(targets.values()))
    elif day <= 22:
        # Late final push: tomatoes in middle/outer-mid, fast crops only inside.
        if "TOMATO" in eligible: targets["TOMATO"] += int(desired_total * 0.45)
        if "CARROT" in eligible: targets["CARROT"] += int(desired_total * 0.35)
        if "WHEAT" in eligible: targets["WHEAT"] += max(0, desired_total - sum(targets.values()))
    else:
        # Final cash-flow: fast crops only, with enough time to clear.
        if "CARROT" in eligible:
            targets["CARROT"] = int(desired_total * 0.60)
        if "WHEAT" in eligible:
            targets["WHEAT"] = desired_total - sum(targets.values())

    # Do not demand crops past their cutoff.
    for c in list(targets):
        if day > LAST_PLANT_DAY[c]:
            targets[c] = 0
    return targets


def bullseye_ring(pos, board_size):
    x, y = pos
    h = board_size // 2
    centers = [(h - 1, h - 1), (h, h - 1), (h - 1, h), (h, h)]
    return min(manhattan(pos, c) for c in centers)


def is_outer_plot(pos, board_size):
    x, y = pos
    edge_dist = min(x, y, board_size - 1 - x, board_size - 1 - y)
    return edge_dist <= 1 or bullseye_ring(pos, board_size) >= 4


def empty_plot_score(crop, target, board_size):
    if not crop:
        return 0
    r = bullseye_ring(target, board_size)
    x, y = target
    edge_dist = min(x, y, board_size - 1 - x, board_size - 1 - y)
    if crop == "WHEAT": ideal = 0
    elif crop == "CARROT": ideal = 1
    elif crop == "TOMATO": ideal = 3
    elif crop == "STRAWBERRY": ideal = 4
    else: ideal = 5
    score = abs(r - ideal) * 100
    if crop in ("MELON", "STRAWBERRY"):
        score -= max(0, 2 - edge_dist) * 60
    if crop in ("WHEAT", "CARROT") and edge_dist <= 1:
        score += 450
    return score


def layer_adjustment(crop, pos, board_size):
    if pos is None:
        return 0
    r = bullseye_ring(pos, board_size)
    x, y = pos
    edge_dist = min(x, y, board_size - 1 - x, board_size - 1 - y)
    if crop == "WHEAT":
        adj = 2500 - 900 * abs(r - 0)
        if r >= 4 or edge_dist <= 1: adj -= 5000
    elif crop == "CARROT":
        adj = 2400 - 750 * abs(r - 1)
        if r >= 5 or edge_dist <= 1: adj -= 4200
    elif crop == "TOMATO":
        adj = 1900 - 550 * abs(r - 3)
        if r <= 1: adj -= 1800
    elif crop == "STRAWBERRY":
        adj = 1700 - 450 * abs(r - 4)
        if edge_dist <= 1: adj += 700
        if r <= 2: adj -= 2200
    else:
        adj = 2600 - 500 * abs(r - 5)
        if edge_dist <= 1: adj += 1200
        if r <= 2: adj -= 3500
    return adj


def crop_allowed_on_plot(crop, pos, board_size):
    """Strict bullseye crop zoning.

    Inner rings are high-maintenance crops. Outer rings are long crops.
    This intentionally prevents wheat/carrot from leaking to the outside edges.
    """
    if pos is None:
        return True
    r = bullseye_ring(pos, board_size)
    x, y = pos
    edge_dist = min(x, y, board_size - 1 - x, board_size - 1 - y)
    # Very outer edge/corners: no wheat/carrot, period.
    if edge_dist <= 1 or r >= 5:
        return crop in ("MELON", "STRAWBERRY", "TOMATO")
    # Inner bullseye: fast maintenance crops.
    if r <= 1:
        return crop in ("WHEAT", "CARROT")
    # Middle ring: carrot/tomato bridge.
    if r <= 3:
        return crop in ("CARROT", "TOMATO", "WHEAT")
    # Outer-middle: tomato/long crops.
    return crop in ("TOMATO", "STRAWBERRY", "MELON")


def any_allowed_seed(seeds, day, pos, board_size):
    for crop in CROPS:
        if seeds.get(crop, 0) > 0 and day <= LAST_PLANT_DAY[crop] and crop_allowed_on_plot(crop, pos, board_size):
            return True
    return False


def best_crop_for_empty_slot(pos, prices, day, opp_info, board_size):
    # What seed should we buy for this empty slot's bullseye zone?
    # Once SW/SE are open-ish and we are in the last big-money window, outer ring
    # slots should become MELON unless it is too late. This prevents the bot from
    # continuing tiny wheat/carrot cycles while holding thousands in cash.
    if is_outer_plot(pos, board_size) and 12 <= day <= LAST_PLANT_DAY["MELON"] and crop_allowed_on_plot("MELON", pos, board_size):
        return "MELON"
    best = None
    best_score = -10**9
    for crop in CROPS:
        if day > LAST_PLANT_DAY[crop]:
            continue
        if not crop_allowed_on_plot(crop, pos, board_size):
            continue
        score = crop_value(crop, prices, day, opp_info) + layer_adjustment(crop, pos, board_size)
        if score > best_score:
            best_score = score
            best = crop
    return best


def preferred_crop_for_empty(active, targets, seeds, prices, day, opp_info=None):
    """Best desired crop for routing toward empty plots when no exact seed/plot is chosen yet."""
    best = None
    best_score = -10**9
    for crop in CROPS:
        if day > LAST_PLANT_DAY[crop]:
            continue
        deficit = targets.get(crop, 0) - active.get(crop, 0)
        score = crop_value(crop, prices, day, opp_info) + max(0, deficit) * 1000
        if seeds.get(crop, 0) > 0:
            score += 250
        if score > best_score:
            best_score = score
            best = crop
    return best


def choose_any_seed_for_plot(seeds, prices, day, opp_info, pos, board_size):
    """Fallback planter for owned seed bags.

    If a worker is standing on empty dirt and we already paid for a seed, plant
    the best seed that is compatible with this bullseye zone. This function was
    accidentally removed in a revert, which made v4.4 no-op via the safety except.
    """
    best = None
    best_score = -10**9
    for crop in CROPS:
        if seeds.get(crop, 0) <= 0 or day > LAST_PLANT_DAY[crop]:
            continue
        if not crop_allowed_on_plot(crop, pos, board_size):
            continue
        score = crop_value(crop, prices, day, opp_info) + layer_adjustment(crop, pos, board_size)
        if score > best_score:
            best_score = score
            best = crop
    if best is None:
        # Last resort: empty dirt is also bad. If no zone-compatible seed exists,
        # plant the best available seed rather than leaving a worker idle.
        for crop in CROPS:
            if seeds.get(crop, 0) <= 0 or day > LAST_PLANT_DAY[crop]:
                continue
            score = crop_value(crop, prices, day, opp_info)
            if score > best_score:
                best_score = score
                best = crop
    return best


def choose_crop_to_plant(active, targets, seeds, prices, day, opp_info=None, pos=None, board_size=10):
    best = None; best_score = -10**9
    strict_has_option = any_allowed_seed(seeds, day, pos, board_size) if pos is not None else False
    for crop in CROPS:
        if seeds.get(crop, 0) <= 0 or day > LAST_PLANT_DAY[crop]:
            continue
        # Strict zoning: if this plot has an allowed seed available, never choose a wrong-zone crop.
        # This stops wheat/carrot from going to the outside edges.
        if pos is not None and strict_has_option and not crop_allowed_on_plot(crop, pos, board_size):
            continue
        # If outer edge has no long seed, do NOT plant wheat/carrot just to fill it.
        if pos is not None and not crop_allowed_on_plot(crop, pos, board_size):
            continue
        deficit = targets.get(crop, 0) - active.get(crop, 0)
        score = crop_value(crop, prices, day, opp_info) + max(0, deficit) * 1000
        if deficit <= 0:
            score -= 500
        score += layer_adjustment(crop, pos, board_size)
        if score > best_score:
            best_score = score; best = crop
    return best if best_score > -10**8 else None



def worker_sector(idx, board_size):
    # idx 0 is main farmer = flexible sweeper. Hands are striped through quadrants.
    # This spreads bought-land labor instead of sending every hand over the same crops.
    if idx <= 0:
        return None
    h = board_size // 2
    sectors = [
        (0, h-1, 0, h-1),                 # NW
        (h, board_size-1, 0, h-1),        # NE
        (0, h-1, h, board_size-1),        # SW
        (h, board_size-1, h, board_size-1)# SE
    ]
    return sectors[(idx - 1) % 4]


def in_sector(pos, sector):
    if sector is None:
        return True
    x, y = pos
    x0, x1, y0, y1 = sector
    return x0 <= x <= x1 and y0 <= y <= y1


def sector_center(sector):
    x0, x1, y0, y1 = sector
    return ((x0 + x1) // 2, (y0 + y1) // 2)


def target_score(idx, pos, target, board_size, urgent=False):
    # Main farmer and urgent carrying tasks just go nearest. Hands prefer their own quadrant.
    dist = manhattan(pos, target)
    sector = worker_sector(idx, board_size)
    if sector is None or urgent:
        return (0, dist)
    if in_sector(target, sector):
        return (0, dist)
    # If no local work is left, allow cross-sector work, but make it less attractive.
    return (2 + (manhattan(target, sector_center(sector)) // 4), dist)

def sector_candidates(idx, candidates, board_size):
    """Soft recovery version: do NOT lock workers to quadrants.

    Hard quadrant ownership tanked score because workers ignored useful work and the
    economy never reached SE.  We keep route/lane diversity elsewhere, but task
    choice is global with lookahead scoring.
    """
    return candidates


def lookahead_target_key(idx, pos, target, board_size, kind, crop_hint=None):
    """3-ish step lookahead scoring. Lower is better.

    Prioritize tasks that can be reached/actioned soon. Empty plots are valuable
    only if the worker can get there fast enough to plant instead of wandering.
    """
    dist = manhattan(pos, target)
    sector_penalty = target_score(idx, pos, target, board_size, urgent=(kind in ("harvest", "water", "drop")))[0]
    if kind == "water":
        # watering prevents crop death, but don't drag everyone cross-map
        return (0, min(dist, 3), sector_penalty, dist)
    if kind == "harvest":
        return (1, min(dist, 4), sector_penalty, dist)
    if kind == "empty":
        # empty plot only useful if close or excellent bullseye match
        layer = empty_plot_score(crop_hint, target, board_size) if crop_hint else 0
        return (2, dist // 3, layer, sector_penalty, dist)
    if kind == "weed":
        return (9, dist)
    return (5, sector_penalty, dist)



def plan_unit(idx, pos, inv, tiles, info, targets, seeds, prices, day, step, reserved, reserved_next, stage_empty=False, stage_slots=None, opp_info=None):
    board_size = len(tiles)
    x, y = pos
    tile = tiles[y][x] if 0 <= y < board_size and 0 <= x < len(tiles[y]) else "LOCKED"
    is_dump = step >= int(DNA.get("dump_turn", 690))
    # Do NOT reserve the current tile. Hands often spawn stacked around the shed,
    # including on locked shed-access tiles. Reserving current positions traps them.

    # Drop harvested items ASAP so market can sell them.
    if inv and any(v > 0 for k, v in inv.items() if k in PRODUCTS):
        if is_shed_tile((x, y), board_size):
            return ["DROP"]

    if isinstance(tile, dict) and tile.get("kind") == "PLANT":
        crop = tile.get("crop")
        cd = CROPS.get(crop, {})
        age = day - tile.get("planted_day", day)
        yld = tile.get("yield_units", 0)
        if yld > 0:
            # Non-ongoing wait for maxday unless cleanup; ongoing harvest at 2+ or cleanup.
            if is_dump or (not cd.get("ongoing", False) and age >= cd.get("maxday", 99)) or (cd.get("ongoing", False) and (yld >= 2 or day >= 20)):
                reserve_coord(info, (x, y))
                return ["HARVEST"]
        if not tile.get("watered_today", False) and not is_dump:
            reserve_coord(info, (x, y))
            return ["WATER"]
        if yld > 0 and is_dump and age >= cd.get("first", 99):
            reserve_coord(info, (x, y))
            return ["HARVEST"]
        if is_dump and step >= 700:
            # Final emergency only: immature plants are dead capital at 720.
            reserve_coord(info, (x, y))
            return ["DIG"]

    if tile is None and not is_dump:
        crop = choose_crop_to_plant(info["active"], targets, seeds, prices, day, opp_info, (x, y), board_size)
        if not crop:
            crop = choose_any_seed_for_plot(seeds, prices, day, opp_info, (x, y), board_size)
        if crop and reserved.get(crop, 0) < seeds.get(crop, 0):
            reserved[crop] = reserved.get(crop, 0) + 1
            info["active"][crop] = info["active"].get(crop, 0) + 1
            reserve_coord(info, (x, y))
            return ["PLANT", crop]

    if isinstance(tile, dict) and tile.get("kind") == "WEED" and not is_dump:
        reserve_coord(info, (x, y))
        return ["DIG"]

    # Movement task lists. We choose in priority bands so workers do not walk to
    # a far empty plot while a crop beside them is dying unwatered. Within each
    # band, hands prefer their assigned quadrant/sector.
    if inv and any(v > 0 for k, v in inv.items() if k in PRODUCTS):
        candidates = shed_tiles(board_size)
        target = min(candidates, key=lambda p: target_score(idx, (x, y), p, board_size, urgent=True))
        reserve_coord(info, target)
        return route_step((x, y), target, idx, board_size, reserved_next, tiles)

    priority_bands = []
    # Harvest/water are urgent: choose nearest, no sector penalty.
    priority_bands.append(([(a[0], a[1]) for a in info.get("harvestable", [])], True, "harvest"))
    if not is_dump:
        priority_bands.append(([(u[0], u[1]) for u in info.get("unwatered", [])], True, "water"))
        # Ignore weeds unless they are truly in the way. They do not pay money.
        # Empty/crop tasks come first; weed clearing is only a fallback when useful planting
        # is otherwise blocked.
        # Even if seeds are not available until the market phase, stage workers on empty plots
        # instead of letting them sit from turn 49->75. Next turn they can plant immediately.
        wants_more = sum(targets.values()) > sum(info.get("active", {}).values())
        empty_stage_ok = False
        if choose_crop_to_plant(info["active"], targets, seeds, prices, day, opp_info, None, board_size):
            empty_stage_ok = True
        elif stage_empty and stage_slots is not None and stage_slots[0] > 0:
            empty_stage_ok = True
        elif wants_more and stage_empty and stage_slots is not None and stage_slots[0] > 0:
            empty_stage_ok = True
        # If weeds are taking over planting space, clear them before more distant staging.
        # Weeds do not pay, but they block plots; ignoring them kept the first field half empty.
        weed_list = list(info.get("weeds", []))
        if weed_list and (len(weed_list) >= 4 or (stage_empty and len(info.get("empty", [])) <= 6)) and day <= 24:
            priority_bands.append((weed_list, False, "weed"))
        if empty_stage_ok:
            empties = list(info.get("empty", []))
            # If we already have seed bags, prefer compatible plots, but do not let strict
            # zoning make workers idle. If no compatible plot exists, use any empty dirt.
            if sum(seeds.values()) > 0:
                compat = [p for p in empties if any_allowed_seed(seeds, day, p, board_size)]
                if compat:
                    empties = compat
            if empties:
                priority_bands.append((empties, False, "empty"))
        # Fallback weed cleanup if there is nothing else useful nearby.
        if weed_list and day <= 24:
            priority_bands.append((weed_list, False, "weed"))

    for candidates, urgent, kind in priority_bands:
        if candidates:
            if kind == "empty":
                if stage_slots is not None and stage_slots[0] <= 0 and not choose_crop_to_plant(info["active"], targets, seeds, prices, day, opp_info, None, board_size):
                    continue
                pcrop = preferred_crop_for_empty(info["active"], targets, seeds, prices, day, opp_info)
                def empty_target_key(p):
                    crop_here = choose_any_seed_for_plot(seeds, prices, day, opp_info, p, board_size) if sum(seeds.values()) > 0 else pcrop
                    if crop_here is None:
                        crop_here = pcrop
                    return (target_score(idx, (x, y), p, board_size, urgent=False)[0], empty_plot_score(crop_here, p, board_size), target_score(idx, (x, y), p, board_size, urgent=False)[1])
                target = min(candidates, key=empty_target_key)
                if stage_slots is not None:
                    stage_slots[0] -= 1
            else:
                target = min(candidates, key=lambda p: target_score(idx, (x, y), p, board_size, urgent=urgent))
            reserve_coord(info, target)
            return route_step((x, y), target, idx, board_size, reserved_next, tiles)
    return ["PASS"]



def quadrant_fill(farm, quadrant):
    """Return (filled_ratio, active, empty, weeds, usable) for a quadrant."""
    tiles = farm.get("tiles", []) or []
    if not tiles:
        return 0.0, 0, 0, 0, 0
    board_size = len(tiles)
    h = board_size // 2
    if quadrant == "NW": x0, x1, y0, y1 = 0, h - 1, 0, h - 1
    elif quadrant == "NE": x0, x1, y0, y1 = h, board_size - 1, 0, h - 1
    elif quadrant == "SW": x0, x1, y0, y1 = 0, h - 1, h, board_size - 1
    else: x0, x1, y0, y1 = h, board_size - 1, h, board_size - 1
    active = empty = weeds = usable = 0
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            t = tiles[y][x]
            if t == "LOCKED":
                continue
            usable += 1
            if t is None:
                empty += 1
            elif isinstance(t, dict) and t.get("kind") == "PLANT":
                active += 1
            elif isinstance(t, dict) and t.get("kind") == "WEED":
                weeds += 1
    return (active / float(max(1, usable))), active, empty, weeds, usable


def expansion_readiness(farm, info, seeds):
    """Return whether current unlocked land is being used well enough to expand.

    This follows the user's rule: fill/maintain the current square first, then
    unlock the next quadrant.  Empty/weed-heavy current land means the crew is
    not ready for more acreage yet.
    """
    unlocked = 0
    for row in farm.get("tiles", []) or []:
        for t in row:
            if t != "LOCKED":
                unlocked += 1
    structures = len(info.get("structures", []))
    usable = max(1, unlocked - structures)
    active = sum(info.get("active", {}).values())
    empty = len(info.get("empty", []))
    weeds = len(info.get("weeds", []))
    seed_total = sum(safe_int(v) for v in (seeds or {}).values())
    filled_ratio = active / float(usable)
    # Seeds about to be planted count a little, but empty ground is still the warning sign.
    potential_ratio = min(1.0, (active + min(seed_total, empty)) / float(usable))
    # Full-drive rule: don't buy another drive until this one is basically full.
    ready = (filled_ratio >= 0.82 and potential_ratio >= 0.92 and empty <= max(3, usable // 8) and weeds <= max(6, usable // 8))
    return ready, filled_ratio, potential_ratio, empty, weeds, usable


def next_land_need(farm, day):
    unlocked = farm.get("unlocked_quadrants", ["NW"]) or ["NW"]
    extra = max(0, len(unlocked) - 1)
    if extra >= min(3, int(DNA.get("buy_land", 3))):
        return None
    if day > int(DNA.get("max_land_buy_day", 20)):
        return None
    return extra, LAND_PRICES[extra], LAND_DUE_DAYS[extra]

def agent(obs):
    try:
        player = obs.get("player", 0)
        step = safe_int(obs.get("step", 0))
        day = safe_int(obs.get("day", step // 24))
        hour = safe_int(obs.get("hour", step % 24))
        farms = obs.get("farms", []) or []
        if not farms or player >= len(farms):
            return {"farmer": ["PASS"], "hands": [], "market": []}
        my_farm = farms[player]
        opp_farm = farms[1-player] if len(farms) > 1 else None
        private = obs.get("private", {}) or {}
        shed = private.get("shed", {}) or {}
        seeds = private.get("seeds", {}) or {}
        inventories = private.get("inventories", [{}]) or [{}]
        prices = (obs.get("market", {}) or {}).get("prices", {}) or {}
        cash = float(my_farm.get("money", 0) or 0)
        tiles = my_farm.get("tiles", []) or []
        hands = my_farm.get("hands", []) or []
        farmer_pos = my_farm.get("farmer", [4, 4]) or [4, 4]

        update_memory(step, prices)
        my_info, board_size = scan_farm(my_farm, day)
        opp_info, _ = scan_farm(opp_farm, day) if opp_farm else ({"active": {}}, board_size)
        targets = desired_mix(my_info, opp_info, prices, day, step, my_farm)
        is_dump = step >= int(DNA.get("dump_turn", 690))

        reserved = {}
        # Planned next-step lane reservations. Do not pre-reserve current positions;
        # overlap is legal and pre-reserving trapped workers at spawn.
        reserved_next = set()
        # Stage workers on empty plots only when seed exists, and only as many
        # workers as seed bags available. This avoids workers camping empty dirt.
        seed_total_now = sum(safe_int(v) for v in seeds.values())
        stage_empty = (seed_total_now > 0)
        stage_slots = [max(seed_total_now, min(8, len(my_info.get("empty", []))) if seed_total_now > 0 else 0)]
        farmer_inv = inventories[0] if len(inventories) > 0 and isinstance(inventories[0], dict) else {}
        farmer_action = plan_unit(0, tuple(farmer_pos), farmer_inv, tiles, my_info, targets, seeds, prices, day, step, reserved, reserved_next, stage_empty, stage_slots, opp_info)
        hand_actions = []
        for i, hp in enumerate(hands):
            inv = inventories[i+1] if i+1 < len(inventories) and isinstance(inventories[i+1], dict) else {}
            hand_actions.append(plan_unit(i+1, tuple(hp), inv, tiles, my_info, targets, seeds, prices, day, step, reserved, reserved_next, stage_empty, stage_slots, opp_info))

        market = []
        # Sell harvested crops early enough to recycle cash. In cleanup sell everything.
        opp_melon_loaded = (opp_info.get("active", {}) or {}).get("MELON", 0) >= int(DNA.get("melon_danger_opp", 6))
        for item in PRODUCTS:
            qty = safe_int(shed.get(item, 0))
            if qty <= 0 or len(market) >= 10:
                continue
            price = prices.get(item, 0)
            gate = int(DNA.get(item.lower() + "_sell", 99999))
            if item == "MELON" and opp_melon_loaded and price >= 215:
                gate = min(gate, 215)
            brain_vote = brain_sell(day, hour, price, qty)
            if is_dump or price >= gate or (brain_vote is True and price >= int(gate * 0.85)):
                market.append(["SELL", item, qty])

        # Staged expansion: fill and maintain the current unlocked square first.
        # Buying land early only helps if the current crew can keep existing plots full.
        land_need = next_land_need(my_farm, day)
        land_reserve_floor = 0
        if not is_dump and land_need and len(market) < 10:
            extra, land_price, due_day = land_need
            land_reserve_floor = land_price + int(DNA.get("land_reserve", 0))
            ready_expand, filled_ratio, potential_ratio, empty_count, weed_count, usable_now = expansion_readiness(my_farm, my_info, seeds)
            # NE is allowed once the first square is mostly full; SW requires the full-field gate.
            # SE is special: if SW is only half-used, buying SE is dead money. In the 24.9k run,
            # SE was bought at ~455 and only got ~5 crops, so block late SE unless SW is truly full.
            first_extra = (extra == 0 and day >= 2 and filled_ratio >= 0.82 and potential_ratio >= 0.90)
            staged_ready = ready_expand and day >= due_day
            if extra == 2:
                sw_fill, sw_active, sw_empty, sw_weeds, sw_usable = quadrant_fill(my_farm, "SW")
                se_allowed = (day <= 15 and sw_fill >= 0.78 and sw_empty <= max(4, sw_usable // 5))
                staged_ready = staged_ready and se_allowed
            if cash >= land_price and (first_extra or staged_ready):
                market.append(["BUY_LAND"]); cash -= land_price
                land_reserve_floor = 0

        # Just-in-time seed scheduler after sell/land reserve. Empty plots with no seed were causing
        # 20+ turn idle gaps, so seed orders get first claim on market slots after selling.
        if not is_dump:
            active = my_info["active"]
            total_seed = sum(safe_int(v) for v in seeds.values())
            plant_requests = sum(1 for a in [farmer_action] + hand_actions if isinstance(a, list) and a and a[0] == "PLANT")
            empty_now = len(my_info.get("empty", []))
            soon_empty = sum(1 for x, y, c, age, t in my_info.get("harvestable", []) if not CROPS.get(c, {}).get("ongoing", False))
            target_hires = int(DNA.get("target_hires", 12))
            intended_workers = 1 + max(len(hands), min(target_hires, len(hands) + 5))
            buffer = int(DNA.get("seed_buffer_early", 6)) if day <= 8 else int(DNA.get("seed_buffer_mid", 3)) if day <= 16 else 0
            practical_need = min(empty_now + soon_empty, intended_workers * 2 + soon_empty + buffer)
            seed_budget = max(0, practical_need - total_seed + plant_requests)
            all_land_open = len(my_farm.get("unlocked_quadrants", ["NW"]) or ["NW"]) >= 4
            # Once land is open and cash is sitting around, stop hoarding and flood empty zones.
            ready_for_more, fr_now, pr_now, ec_now, wc_now, usable_now2 = expansion_readiness(my_farm, my_info, seeds)
            # If current acreage is not full, seed every empty slot before thinking about more land.
            if cash >= 400 and ec_now > 0 and day <= 22:
                seed_budget = max(seed_budget, min(60, empty_now + soon_empty - total_seed + plant_requests))
            if all_land_open and cash >= 1500 and 12 <= day <= 22:
                seed_budget = max(seed_budget, min(70, empty_now + soon_empty - total_seed + plant_requests))
            if day <= 3:
                seed_budget = max(seed_budget, min(24, empty_now + soon_empty - total_seed + plant_requests))
            if day >= 23:
                seed_budget = min(seed_budget, max(0, intended_workers + soon_empty - total_seed))

            deficits = {}
            zone_empty_need = {c: 0 for c in CROPS}
            # Critical: buy seeds for the plots that are actually empty in each bullseye zone.
            # This prevents the bot from owning only wheat/carrot while outer slots wait empty.
            for p in my_info.get("empty", []):
                c = best_crop_for_empty_slot(p, prices, day, opp_info, board_size)
                if c:
                    zone_empty_need[c] += 1
            outer_empty_count = sum(1 for p in my_info.get("empty", []) if is_outer_plot(p, board_size))
            for crop in CROPS:
                # In the all-land cash-burn window, allow melon buying until its true last plant day.
                if crop == "MELON" and all_land_open and cash >= 1200 and day <= LAST_PLANT_DAY["MELON"]:
                    stop_buy_day = LAST_PLANT_DAY[crop] + 1
                else:
                    stop_buy_day = LAST_PLANT_DAY[crop] - (2 if crop in ("MELON", "STRAWBERRY", "TOMATO") else 1)
                if day >= stop_buy_day:
                    deficits[crop] = 0
                else:
                    target_need = max(0, targets.get(crop, 0) - active.get(crop, 0) - seeds.get(crop, 0))
                    slot_need = max(0, zone_empty_need.get(crop, 0) - seeds.get(crop, 0))
                    deficits[crop] = max(target_need, slot_need)
            if all_land_open and cash >= 1200 and 12 <= day <= LAST_PLANT_DAY["MELON"]:
                # Hard override: buy enough MELON to fill outer ring empties.
                deficits["MELON"] = max(deficits.get("MELON", 0), max(0, outer_empty_count - seeds.get("MELON", 0)))
                # During melon surge, do not waste cash on additional wheat bank.
                deficits["WHEAT"] = min(deficits.get("WHEAT", 0), 2)
                deficits["CARROT"] = min(deficits.get("CARROT", 0), 4)

            # Seed-bank discipline. Wheat is cheap, so the bot was over-buying it and
            # ending with 35 bags. Keep only a small rolling bank and stop late wheat buys.
            if seeds.get("WHEAT", 0) >= int(DNA.get("max_wheat_seed_bank", 6)) or day >= 20:
                deficits["WHEAT"] = 0
            if seeds.get("CARROT", 0) >= 10 or day >= 22:
                deficits["CARROT"] = 0

            if day <= 1:
                order = ["WHEAT", "CARROT", "MELON", "TOMATO", "STRAWBERRY"]
            elif all_land_open and cash >= 1200 and 12 <= day <= LAST_PLANT_DAY["MELON"]:
                # Once SW/SE are open and cash is sitting around, burn money into outer value,
                # not more wheat seed bank.
                order = ["MELON", "TOMATO", "STRAWBERRY", "CARROT", "WHEAT"]
            elif day <= 17:
                order = ["CARROT", "WHEAT", "MELON", "TOMATO", "STRAWBERRY"]
            else:
                order = sorted(CROPS.keys(), key=lambda c: (-deficits.get(c, 0), -crop_value(c, prices, day, opp_info)))
            for crop in order:
                if len(market) >= 10 or seed_budget <= 0:
                    break
                cap = 30
                if crop == "MELON" and all_land_open and cash >= 1200 and 12 <= day <= LAST_PLANT_DAY["MELON"]:
                    cap = 40
                elif crop == "MELON" and day <= 3:
                    cap = 4
                elif crop == "MELON" and day <= 10:
                    cap = 8
                elif crop == "WHEAT":
                    cap = 18 if day <= 3 else (6 if day <= 12 else 3)
                elif crop == "CARROT":
                    cap = 18 if day <= 3 else 8
                n = min(seed_budget, deficits.get(crop, 0), cap)
                if n <= 0:
                    continue
                cost = CROPS[crop]["seed"] * n
                reserve = 40 if day <= 22 else 160
                if land_reserve_floor and day >= (land_need[2] - 1 if land_need else 99):
                    # Hard-save for due land. Do not let seed buying repeatedly delay SW/SE.
                    reserve = max(reserve, land_reserve_floor)
                # If there are zero seeds and empty plots, buy enough to keep the crew busy.
                # Only clamp small when land is due and we are saving for it.
                if total_seed <= 0 and empty_now > 0 and day <= 16:
                    if land_reserve_floor and day >= (land_need[2] - 1 if land_need else 99):
                        n = min(n, 4)
                    cost = CROPS[crop]["seed"] * n
                    reserve = min(reserve, 120)
                if cash >= cost + reserve:
                    market.append(["BUY_SEED", crop, n])
                    cash -= cost
                    seed_budget -= n


        # Hire AFTER seed orders. Hands without seeds just stand around; seed-first keeps them busy next turn.
        if not is_dump and hour <= 20 and len(market) < 10:
            target_hires = int(DNA.get("target_hires", 12))
            unlocked_count = len(my_farm.get("unlocked_quadrants", ["NW"]) or ["NW"])
            # Estimate next-turn work including seed orders we just placed.
            ordered_seeds = 0
            for order in market:
                if isinstance(order, list) and len(order) >= 3 and order[0] == "BUY_SEED":
                    ordered_seeds += safe_int(order[2])
            compatible_seed_slots = 0
            if seed_total_now + ordered_seeds > 0:
                compatible_seed_slots = len(my_info.get("empty", []))
            active_jobs = len(my_info.get("unwatered", [])) + len(my_info.get("harvestable", []))
            plant_jobs = min(len(my_info.get("empty", [])), max(compatible_seed_slots, 8 if day <= 6 else 4))
            work_pressure = active_jobs + plant_jobs + (len(my_info.get("weeds", [])) if len(my_info.get("empty", [])) <= 3 else 0)
            acreage_floor = {1: 4, 2: 7, 3: 9, 4: 12}.get(unlocked_count, 9)
            desired_hands = min(target_hires, max(2, acreage_floor, work_pressure))
            while len(hands) + sum(1 for o in market if o == ["HIRE"]) < desired_hands and len(market) < 10 and cash > 70:
                market.append(["HIRE"]); cash -= 5

        return {"farmer": farmer_action, "hands": hand_actions, "market": market[:10]}
    except Exception:
        return {"farmer": ["PASS"], "hands": [], "market": []}
