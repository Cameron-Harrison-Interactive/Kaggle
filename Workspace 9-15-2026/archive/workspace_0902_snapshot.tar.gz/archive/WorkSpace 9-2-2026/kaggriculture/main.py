"""
main.py — Kaggriculture submission. Fully self-contained (stdlib only).

A FARMER that plans the whole day before stepping into the field — it knows
what it has planted, when each crop needs water, when each crop becomes
harvestable, when each animal produces, how much money and seed it has, what
the market is doing, which town shops are open, and what the opponent is
building. It then routes every worker for the day, exactly, and re-plans from
the live board every morning so nothing is ever memorized, nothing desyncs,
and no two matches play the same way.

The design principles (everything below implements these):

1. NO DEDICATED ANIMAL WORKERS.  Every worker starts the day on a shed tile
   (the animals are pastured right next to the shed), so every worker "walks
   over the top of the animals".  Feeding is done ON THE WAY OUT (pick up
   wheat at the shed, feed the nearest animals as you leave), and fertilizer /
   animal products are collected ON THE WAY BACK (walk past the animals on
   the way home).  Nobody is a full-time animal tender.

2. ROUTE THE QUADS, DAY BY DAY, FROM THE LIVE BOARD.  Each worker owns a
   quadrant (rotated by a per-match signature).  The route visits ONLY tiles
   that need work — water, harvest, plant, dig — never empty dead space.  The
   route is rebuilt every morning from the current board, so a copied "build
   and timing" can never sync to us, and any drift self-corrects.

3. HARVEST -> REPLANT -> WATER IN ONE PASS.  When a worker harvests a crop,
   it plants a new seed in that same tile and waters it the same day — because
   the bot knows the harvest is coming (it knows every crop's planted_day and
   the rules that say when it matures).

4. IT KNOWS THE RULES.  Exact crop/animal/market tables + the exact price
   function.  A crop planted at hour 22 must be watered at hour 23, so a
   plant is only scheduled with its water slot guaranteed.  A melon needs 10
   days, wheat 4, carrot 3, a strawberry pays over 16 days — "what to plant"
   is decided from the days left AND the market AND the town.

5. IT READS THE TOWN.  Shop unlocks are random (with replacement) — a second
   Pet Cafe doubles carrot demand, a Yarn Store doubles wool demand.  The bot
   reads obs.town.unlocked_shops every day and tilts its crop/animal mix
   toward what the town is buying.

6. IT READS THE OPPONENT AND THE MARKET.  The opponent's farm is public.  The
   bot classifies the opponent's build (animal-heavy vs crop-heavy vs
   balanced) and counters: herd tilt, crop-mix counter, front-run sells, and
   a "market rotation" that avoids sharing a glut and can deliberately dump a
   product to crash the price the opponent depends on.  It also stops buying
   cows/sheep the moment milk/wool crash and pivots that cash into crops.

7. IT DECIDES ITS OWN CREW.  The day's work is counted exactly (Manhattan walk
   + 1 action per job); if it does not fit the crew's hours, it hires more
   hands (fib cost) until it fits or the money runs out.

8. ANTI-MIRROR.  Crop priority, quadrant assignment, and the harvest/replant
   rotation are keyed by a per-match signature, so two matches never produce
   the same schedule.

Every plan is rebuilt each morning from the live board.  Nothing is fixed,
nothing is a "tape", nothing is pre-compiled.
"""

from collections import namedtuple, defaultdict

# ============================================================================
# SECTION 1 — RULES (transcribed from the official engine)
# ============================================================================

BOARD = 10
HALF = BOARD // 2
SEASON_DAYS = 30
DAY_TURNS = 24

# The four tiles orthogonally adjacent to the shed (one per quadrant).
SHED_TILES = {(HALF - 1, HALF - 1), (HALF, HALF - 1), (HALF - 1, HALF), (HALF, HALF)}
SHED_TILE_LIST = [(4, 4), (5, 4), (4, 5), (5, 5)]   # NWSE order
# Hands spawn on shed-access tiles in NWSE preference; ties broken by occupancy.
SPAWN_SEQ = [(5, 4), (4, 5), (5, 5), (4, 4)]

# --- crops ------------------------------------------------------------------
# seed, first_yield_day, max_yield_day, interval(ongoing), max_yield, ongoing
CROPS = {
    "WHEAT":      {"seed": 10,  "first": 2,  "max_day": 4,  "interval": 0, "max_yield": 6, "ongoing": False},
    "CARROT":     {"seed": 20,  "first": 2,  "max_day": 3,  "interval": 0, "max_yield": 4, "ongoing": False},
    "TOMATO":     {"seed": 50,  "first": 8,  "max_day": 8,  "interval": 1, "max_yield": 4, "ongoing": True},
    "STRAWBERRY": {"seed": 100, "first": 10, "max_day": 10, "interval": 2, "max_yield": 4, "ongoing": True},
    "MELON":      {"seed": 80,  "first": 10, "max_day": 12, "interval": 0, "max_yield": 6, "ongoing": False},
}

# --- animals ----------------------------------------------------------------
# cost, structure, first_yield_day, interval(days), max_held, product
ANIMALS = {
    "GOOSE": {"cost": 300, "struct": "COOP",    "first": 4, "interval": 1, "max_held": 4, "product": "EGG"},
    "COW":   {"cost": 400, "struct": "PASTURE", "first": 8, "interval": 2, "max_held": 6, "product": "MILK"},
    "SHEEP": {"cost": 500, "struct": "PASTURE", "first": 6, "interval": 3, "max_held": 6, "product": "WOOL"},
}

ANIMAL_ORDER = ["SHEEP", "COW", "GOOSE"]

# --- market -----------------------------------------------------------------
PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON",
            "EGG", "MILK", "WOOL", "FERTILIZER"]

BASE_PRICE = {"WHEAT": 25, "CARROT": 35, "TOMATO": 60, "STRAWBERRY": 120,
              "MELON": 250, "EGG": 50, "MILK": 160, "WOOL": 200, "FERTILIZER": 100}

# price(inv) = base +/- amp * f(|inv - I0|), floored at 1.
# (base, T, below_func, below_target, above_func, above_target)
MARKET = {
    "WHEAT":      (25,  400, "sqrt",   0.80, "log",    0.20),
    "CARROT":     (35,  450, "log",    0.20, "sqrt",   0.70),
    "TOMATO":     (60,  200, "linear", 0.40, "sqrt",   0.60),
    "STRAWBERRY": (120, 100, "sqrt",   0.70, "linear", 1.60),
    "MELON":      (250, 300, "log",    0.20, "sq",     3.60),
    "EGG":        (50,  332, "linear", 0.40, "log",    0.20),
    "MILK":       (160, 122, "sqrt",   0.60, "linear", 1.60),
    "WOOL":       (200, 105, "log",    0.20, "sq",     3.20),
    "FERTILIZER": (100, 200, "linear", 0.40, "linear", 0.40),
}

# --- town shops -------------------------------------------------------------
# Each unlocked shop INSTANCE consumes its demanded products every
# townShopSellInterval turns (default 4 = 6/day). Single-product shops are 2x.
# Shops unlock randomly WITH REPLACEMENT, so the same shop can appear twice —
# the bot must read the actual list, not assume variety.
SHOP_DEMAND = {
    "BAKERY":         {"EGG": 1, "WHEAT": 1},
    "PIZZA_SHOP":     {"MILK": 1, "TOMATO": 1, "WHEAT": 1},
    "BRUNCH_SPOT":    {"EGG": 1, "WHEAT": 1, "STRAWBERRY": 1},
    "YARN_STORE":     {"WOOL": 2},
    "ICE_CREAM_SHOP": {"STRAWBERRY": 1, "MILK": 1, "WHEAT": 1},
    "PET_CAFE":       {"CARROT": 2},
    "SMOOTHIE_SHOP":  {"STRAWBERRY": 1, "MILK": 1},
    "FARMERS_MARKET": {"WHEAT": 1, "CARROT": 1, "TOMATO": 1, "STRAWBERRY": 1},
}

# --- economics helpers ------------------------------------------------------
# Days a crop needs before it is fully done (one-time: max_day; ongoing: last
# production day).
CROP_NEED = {"WHEAT": 4, "CARROT": 3, "MELON": 10, "STRAWBERRY": 16, "TOMATO": 11}
CROP_UNITS = {"WHEAT": 4, "CARROT": 3, "MELON": 6, "STRAWBERRY": 4, "TOMATO": 4}
# Expected price retention after our own dumping (glut). Wheat holds up (log
# glut curve); melon/wool crash (sq); strawberry/milk/tofu crash (linear 1.6).
GLUT_DISCOUNT = {"WHEAT": 1.0, "CARROT": 0.8, "MELON": 0.85,
                 "STRAWBERRY": 0.8, "TOMATO": 0.5}

FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987]

SELL_ORDER = ["MILK", "WOOL", "EGG", "FERTILIZER", "MELON", "STRAWBERRY",
              "CARROT", "TOMATO", "WHEAT"]

Job = namedtuple("Job", "op x y arg")


# ============================================================================
# SECTION 2 — MARKET MATH (exact price function + town demand)
# ============================================================================

def _shape(name, x):
    x = max(0.0, x)
    if name == "linear":
        return x
    if name == "sq":
        return x * x
    if name == "sqrt":
        return x ** 0.5
    if name == "log":
        return __import__("math").log(1.0 + x)
    return x


def market_price(item, inventory):
    """Exact sell price at a given market inventory (matches the engine)."""
    base, T, below, bt, above, at = MARKET[item]
    if inventory < 10000:
        amp = bt * base / _shape(below, T)
        price = base + amp * _shape(below, 10000 - inventory)
    else:
        amp = at * base / _shape(above, T)
        price = base - amp * _shape(above, inventory - 10000)
    return max(1, int(round(price)))


def sell_value(item, inventory, units):
    """Total revenue from selling `units` one at a time into `inventory`."""
    total = 0
    inv = inventory
    for _ in range(int(units)):
        total += market_price(item, inv)
        inv += 1
    return total


def avg_sell_price(item, inventory, units):
    if units <= 0:
        return 0.0
    return sell_value(item, inventory, units) / units


def town_demand(shops):
    """Aggregate extra demand (units/day) for each product from the unlocked
    shop list. Town-center demand (1/day/product, flat) is added by callers."""
    d = defaultdict(int)
    for s in (shops or []):
        for prod, n in SHOP_DEMAND.get(s, {}).items():
            d[prod] += n * 6     # each shop ticks every 4 turns = 6/day
    return d


# ============================================================================
# SECTION 3 — GEOMETRY (movement is never blocked => Manhattan = exact)
# ============================================================================

def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def move_toward(pos, goal):
    if pos == goal:
        return ["PASS"]
    px, py = pos
    gx, gy = goal
    dx, dy = gx - px, gy - py
    if abs(dx) >= abs(dy):
        return ["EAST"] if dx > 0 else ["WEST"] if dx < 0 else ["PASS"]
    return ["SOUTH"] if dy > 0 else ["NORTH"] if dy < 0 else ["PASS"]


def _quad_of(x, y):
    return ("N" if y < HALF else "S") + ("W" if x < HALF else "E")


def _serpentine(quad):
    """Row-by-row serpentine tile order for a 5x5 quadrant (short walks)."""
    x0 = 0 if quad[1] == "W" else 5
    y0 = 0 if quad[0] == "N" else 5
    out = []
    for r in range(5):
        row = [(x, y0 + r) for x in range(x0, x0 + 5)]
        if r % 2:
            row = row[::-1]
        out += row
    return out


# ============================================================================
# SECTION 4 — PARAMETERS (the few fixed constants; everything else is live)
# ============================================================================

DEFAULT_PARAMS = {
    # OPENING (day 0, hour 0 — buys land under the 10-order market cap).
    #
    # Ramp fix (this session, verified 40 seeds vs PASS):
    #   * open_hires bumped 4 -> 7.  Hires are almost free (fib-costed:
    #     1,1,2,3,5,8,13 — seven hires total $33) and starting cash is $3k,
    #     so an extra 3 workers on day 0 is trivial to fund.  The 10-order
    #     market cap means the 3 seed lines get bumped to hour 1 (they run
    #     the same day and the planner already schedules against them via
    #     day0_plan), so we lose no seeds — we just gain 3 more workers.
    #   * day0_plan flipped False -> True.  The seed orders placed at hour 0
    #     are DETERMINISTIC and always land in the shed at hour 1, so the
    #     morning plan can schedule day-0 planting against them.  Together
    #     with the extra hires the field starts filling on day 0 instead of
    #     day 1 (7 plants down day 0, 13 by day 2 — vs 15-by-day-1 previously
    #     but with only 4 crew, half of which starve the crops days 2-4).
    #   Net measured (40 seeds vs PASS):
    #     BASE               avg $92,697  min $33,342  max $116,470
    #     d0p + hires=7      avg $93,830  min $60,091  max $118,565
    #                        --> +$1,133 avg, MIN FLOOR jumps $27k
    #   Battles (10 seeds x 2 seats = 20 games per archetype):
    #     sheepbot   20W  -> 16W   avg margin +$20,266 -> +$23,023
    #     goosebot   18W  -> 20W   avg margin +$45,436 -> +$46,115
    #     mirror     17W  -> 17W   avg margin +$17,290 -> +$17,894
    #     cropbot    20W  -> 20W   avg margin +$48,490 -> +$50,854
    #     cowbot     19W  -> 20W   avg margin +$22,806 -> +$30,772
    #     tape_v25   0W   ->  0W   still contested ($-83k -> $-79k avg)
    #
    # Opening buys: 8 wheat feed (was 12; lower is better vs meta-line ladder
    # opponents who buy 40+ wheat/day and drive prices up -- we save cash for
    # more melon seeds), 8 hires (was 7; extra hand lets us plant 2 more
    # tiles on day 0 which matters vs the meta-line's 30-day production race).
    # Verified head-to-head vs ladder reference agents:
    #   broker_bea    margin -$70.5k -> -$49.5k  (+$21k)
    #   ledger_lena   margin -$70.9k -> -$49.8k  (+$21k)
    #   slotter_silas margin -$70.2k -> -$49.8k  (+$20k)
    #   closer_cleo   margin -$76.7k -> -$55.0k  (+$22k)
    # Solo: -$759 (99,647 vs 100,405 on 40 seeds).  All other archetypes:
    # 20W held, margins within ±$4k.  Only mirror lost $0.8k margin.
    "open_wheat": 8, "open_hires": 8, "open_sheep": 2, "open_cows": 2,
    "open_goose": 0,
    # PLANNER-DEPTH TRICK (Session 26): open_melon_seed=10 does NOT put more
    # seeds in the shed -- the day-0 opener only fits 4 BUY_SEED slots under
    # the 10-order market cap, and the actual purchase remains BUY_SEED MELON 4
    # (the min of the request and remaining shop stock, atomically).  What DOES
    # change is the day-0 planner's mental accounting: it "budgets" N melon
    # seeds when planning worker capacity, so it commits more labor to that
    # quadrant.  The extra phantom melons plans absorb into more watering /
    # planting elsewhere once the physical 4 seeds run out, and the resulting
    # labor mix is net-better.
    # Bumped 10 -> 20 (after ladder analysis).  The higher budget helps the
    # day-0 planner allocate MORE labor to future melon plantings once the
    # NE quadrant unlocks -- Bea plants 11 melons by day 8, we need to keep up.
    # Verified: solo N=40 $99.6k -> $100.8k (+$1.1k, MIN floor +$8k), all
    # ladder margins improved +$2-3k, non-tape archetypes unchanged.
    "open_melon_seed": 20,
    "open_straw_seed": 4, "open_wheat_seed": 8,
    # crew
    "daily_hires": 4, "late_hires": 7, "late_day": 10,
    "max_extra_hires": 12,
    "max_total_hires": 14,
    # land — a new quadrant is bought ONLY when the quads we already own are
    # FULL of crops (>= land_density of every plantable tile is a living
    # plant) AND we hold cash >= price + land_seed_budget, so the expansion
    # can buy its own seeds + hands.  This is the user's rule: quad 3/4
    # (SW/SE) only unlocks once the earlier quads are full and stay full and
    # pay for the next one.
    "ne_land_day": 5, "sw_land_day": 8, "se_land_day": 13,
    "land_density": 0.8, "land_seed_budget": 600,
    # land_crop_last_day: latest day the bot will buy a new quadrant on a
    # crop town.  Cut 19 -> 15 to match the shorter game (terminal_day=18):
    # buying a quadrant after day 15 doesn't leave enough turns to plant AND
    # harvest, so the land money is wasted.  Small win: +$212 avg / 60 seeds,
    # min $60,278 -> $62,560 (+$2,282 floor).
    "land_crop_last_day": 15, "land_min_seeds": 4,
    # animals are pastured within this many steps of the shed (soft cap) so
    # the daily feed/care/collect sweep stays short; if the animal type ever
    # changes size we only bump this number to account for the extra steps.
    # pasture_reserve keeps that many near-shed tiles clear of crops so the
    # herd actually lands inside the cap (score-neutral on 20 seeds, measured).
    "max_animal_dist": 4, "pasture_reserve": 14,
    # crops
    "crop_wheat": 0.50, "crop_melon": 0.28, "crop_straw": 0.22,
    "slow_crop_days": 2, "plant_max": 56, "plant_cost": 5,
    "wheat_rebuy": 6, "melon_rebuy": 4, "straw_rebuy": 3,
    "melon_last_day": 19, "straw_last_day": 13,
    # herd
    "target_sheep": 2, "final_sheep": 4, "sheep_ramp_start": 0, "sheep_ramp_end": 4,
    "target_cow": 2, "final_cow": 10, "cow_ramp_start": 1, "cow_ramp_end": 12,
    "target_goose": 0, "final_goose": 0, "goose_ramp_start": 0, "goose_ramp_end": 14,
    "herd_cap": 14,
    # behavior
    "harvest_animal_min": 2, "wheat_batch": 5,
    "wheat_reserve_per_animal": 2, "cash_buffer": 250,
    # terminal_day: from this day onwards we STOP buying (seeds/animals/land)
    # and DUMP everything every hour (not just sell_hour).  Holds are also
    # ignored.  Session 28: dropped from 28 to 18 -- the crop/animal pipeline
    # is already fully built by day 15 (last melon plants day 12 -> harvest
    # day 22; strawberries planted day 8-10 -> production days 10, 12, 14, 16
    # already done).  Continuing to buy after that just locks cash we should
    # be racing to convert into shed inventory sales.  Verified head-to-head
    # (10 seeds x 2 seats): mirror +$10k margin, sheepbot +$13k, goosebot
    # +$7k, cropbot +$5k, tape +$2k.  Solo N=40: $98.6k -> $100.1k (+$1.5k).
    "terminal_day": 18,
    # SELL TIMING — town shops consume every 4 turns (hours 0,4,8,12,16,20).
    # Consumption LOWERS the market inventory, which RAISES prices next turn
    # (the interpreter order is: process_market -> town_consume -> _refresh_prices).
    # So selling right AFTER a town tick nets the peak post-tick price.
    # Verified (40 seeds vs PASS, base=93,830):
    #   sell_hour= 2 (old default) baseline
    #   sell_hour= 5 (after hour-4 tick)   +$849
    #   sell_hour=13 (after hour-12 tick)  +$1,404
    #   sell_hour=21 (after hour-20 tick)  +$2,076   <-- winner
    # 21 wins because it is the LAST town-tick before the day rolls -- inventory
    # is at its daily minimum so prices are at their daily peak, and end-of-day
    # animal collections have already landed in the shed.
    "sell_hour": 21,
    # sell_hour_secondary: optional second SELL burst earlier in the day. Set
    # to -1 to disable, or e.g. 13 to also sell right after the noon tick.
    # (Off by default -- accumulating and dumping at hour 21 outperforms two
    # smaller dumps because the day-21 dump AVERAGES a higher price.)
    "sell_hour_secondary": -1,
    # STRAWBERRY hold-until: strawberry sell price rises monotonically because
    # town shops eat them faster than any bot produces them.  Hold the small
    # strawberry stock until the price peak (~day 22) then dump.  Verified
    # +$957 avg on 60 seeds vs PASS (59/60 wins).
    "hold_straw_until": 22,
    # MELON hold: melon price rises slightly (~5%) from day 10 to day 15 as
    # town shops eat the small early melon harvest.  Holding early stock
    # until day 15 nets +$181 on 60 seeds (60/60 wins -- perfectly stable).
    "hold_melon_until": 15,
    # PRICE-MOMENTUM DUMP: when a product's current price drops this fraction
    # below its 5-day rolling max, dump our stock immediately (at the next
    # 4-hour tick, so we can react WITHIN the day rather than waiting for
    # the once-a-day hour-21 sale).  Verified on head-to-head:
    #   mirror   +$4k margin (17W -> 18W)
    #   sheepbot +$2k margin
    #   solo neutral (no opponent means no downtrend to detect)
    # Set to 0 to disable.  Strawberry is exempt (rising-price product;
    # hold_straw_until owns it).
    "momentum_drop_pct": 0.04,
    # market reader
    "wheat_cheap": 20, "wheat_expensive": 32, "wheat_extra_buy": 6,
    "fert_reserve": 2, "straw_fert_min_price": 90, "fert_early_day": 0,
    # crop engine — these are the knobs that decide how hard the bot chases
    # crop VOLUME vs the herd's milk/wool income (they were all A/B tested
    # this session; the shipped values are the ones that won on 10 seeds):
    #   day0_plan     : plant on day 0 using the (deterministic) opening seed
    #                   orders (they arrive in the shed at hour 1 and the
    #                   planner schedules them into the same day's timeline).
    #                   HISTORY: rejected early on when we only had 4 opening
    #                   hires (the 15-crop day-0 field died on the cash-poor
    #                   days 2-4 with no watering crew).  Now RE-ENABLED
    #                   together with open_hires=7 -- the extra 3 workers pay
    #                   for the watering, and the day-0 fill starts on day 0
    #                   instead of day 1.  Verified: +$1,133 avg / 40 seeds
    #                   AND the worst-case floor goes $33k -> $60k.
    #   survival_water: schedule must-water plants BEFORE herd placement.
    #                   TESTED: net-negative (steals hours from harvest/CARE)
    #                   -> OFF.  Left as a switch for crop-heavy seasons.
    #   crop_town     : shrink the herd on crop/egg towns and spend the cash on
    #                   the field instead (milk->cows, wool->sheep, egg->geese,
    #                   else small herd + crops).  ON (user-approved).
    #   seed_floor_*  : extra cash (over cash_buffer) we require before buying
    #                   crop seeds.  Lower = buy crops earlier (more volume,
    #                   fewer cows); higher = herd first.
    # hire_reserve: minimum cash left after ordering the day's hires (fib-
    # costed; a 10th hire only costs $55).  Cut from 250 -> 100: hires are
    # dirt cheap and being cash-conservative here just leaves the field
    # under-staffed on cash-poor days.  Verified +$883 solo N=60, zero H2H
    # regression across all 5 archetypes + tape.
    "day0_plan": True, "hire_reserve": 100, "survival_water": False,
    "crop_town": True,
    "seed_floor_straw": 200, "seed_floor_melon": 250,
    # counter
    "frontrun_enabled": True, "frontrun_pending": 3,
    "cow_shift": 2, "sheep_shift": 2, "min_cow_keep": 6,
    "milk_floor": 50, "wool_floor": 60,
    "dump_enabled": True, "dump_ratio": 0.35,
    # anti-mirror
    "anti_mirror": True,
}


# ============================================================================
# SECTION 5 — THE AGENT
# ============================================================================

class Agent:
    def __init__(self, params=None, seat=0):
        self.params = dict(DEFAULT_PARAMS)
        if params:
            self.params.update(params)
        self.seat = seat
        # per-day state
        self._timelines = {}   # worker_idx -> [Job, ...]
        self._ptrs = {}        # worker_idx -> next job index
        self._extra_hires = 0
        # per-match state
        self._sig = None       # anti-mirror signature
        self._opp = None       # opponent scan (public farm)
        self._town = None      # town demand
        self._last_prices = {}
        # PRICE HISTORY (rolling window of last-N daily prices per product),
        # used to detect a downtrend caused by the opponent flooding a
        # product's market -- when we spot it we dump our stock IMMEDIATELY
        # instead of waiting for hour 21 (by which point the opponent may
        # have crashed the price further).
        self._price_history = {}   # item -> [ (day, price), ... ]
        self._animal_bonus = 0
        self._crop_bonus = 0
        self._n_tomato = 0
        self._goose_pivot = False
        self._sheep_pivot = False
        self._cow_pivot = False
        # Opponent signature: 1c + 4s day-0 opening = the v25 tape signature.
        # When true we shrink our own cow ramp + drop crop seed floors, so
        # we don't compete with the tape's late milk glut and instead race
        # into crops.
        self._tape_like_opp = False
        # META-LINE opponent signature (from analysing kaggle reference agents
        # broker_bea / ledger_lena / slotter_silas / closer_cleo).  They all
        # execute the shared meta plan: 10 wheat + 7 melon plants by day 1,
        # 3 cows + 1 sheep herd, ramp to 8 cows + 6 sheep + 12 hands/day and
        # 30+ strawberry plants by day 12.  This is the strongest strategy
        # on the ladder and needs a specific counter -- see notes on
        # _meta_line_opp handling below.
        self._meta_line_opp = False
        self._crop_town = False
        self._milk_town = False
        self._wool_town = False
        self._egg_town = False
        # Init hire carry-over state (was accidentally removed during Session 43 patching)
        self._hires_left = 0
        self._hired_so_far = 0
        # ============ SESSION 43: predictive-opponent intelligence ============
        # Fingerprint the opponent at D0 (their opening market action leaves
        # public fingerprints: cow count, sheep count, melon-seed count, wheat
        # BUY, land purchases, hire count).  Store per-day fingerprint history
        # and match against a KNOWN-TEAM database of what beats each style.
        self._opp_fingerprint = {}   # day -> {'cow':N, 'sheep':N, 'melon_seeds':N, 'wheat_buy':N, 'hires':N, 'money':N}
        self._opp_class = None       # 'c2s2_melon12' | 'c1s4_wheat14' | 'cleo_style' | 'v25_tape' | 'unknown'
        self._opp_class_confidence = 0
        self._opp_predicted_bank = 0  # what we expect opp to make by D29
        self._counter_mode = None    # 'over_produce' | 'front_run' | 'market_dump' | 'crop_race'
        # DYNAMIC MARKET-SLOT MAXIMIZER: fill unused market slots with
        # opportunistic sells of items whose price is above 60% of base and
        # whose shed stock exceeds a threshold.  This closes the gap where
        # v25/session-35 uses only 63 SELL slots vs Tanmay's 200+.
        self._max_slot_sells = True
        # LAND AGGRESSION: buy quadrants earlier and always aim for 3+ quads
        # by D10 (top-bots consistently reach 3-4).  Session-35 tops out at 2.
        self._land_target_quads = 3

    # ============= SESSION 43: PREDICTIVE OPPONENT INTELLIGENCE ==============
    def _fingerprint_opponent(self, obs, day):
        """Read opp's public farm and record production fingerprint per-day.
        Called every hour but only records at D0H1, D1H0, D2H0, D3H0 to keep
        the fingerprint deterministic (no mid-day fluctuations)."""
        seat = int(obs.get("player", 0) or 0)
        ofarm = obs["farms"][1 - seat]
        cow = sheep = goose = 0
        pasture = coop = 0
        wheat_plants = melon_plants = straw_plants = carrot_plants = 0
        weed = 0
        for row in ofarm.get("tiles", []):
            if not isinstance(row, list): continue
            for t in row:
                if not isinstance(t, dict): continue
                if t.get("animal") == "COW": cow += 1
                elif t.get("animal") == "SHEEP": sheep += 1
                elif t.get("animal") == "GOOSE": goose += 1
                if t.get("kind") == "PASTURE": pasture += 1
                elif t.get("kind") == "COOP": coop += 1
                elif t.get("kind") == "PLANT":
                    c = t.get("crop", "")
                    if c == "WHEAT": wheat_plants += 1
                    elif c == "MELON": melon_plants += 1
                    elif c == "STRAWBERRY": straw_plants += 1
                    elif c == "CARROT": carrot_plants += 1
                elif t.get("kind") == "WEED": weed += 1
        fp = {
            "day": day,
            "cow": cow, "sheep": sheep, "goose": goose,
            "pasture": pasture, "coop": coop,
            "wheat_plants": wheat_plants,
            "melon_plants": melon_plants,
            "straw_plants": straw_plants,
            "carrot_plants": carrot_plants,
            "weed": weed,
            "money": int(ofarm.get("money", 0) or 0),
            "hands": len(ofarm.get("hands", []) or []),
            "quads": len(ofarm.get("unlocked_quadrants", []) or []),
        }
        self._opp_fingerprint[day] = fp
        return fp

    def _classify_opponent_v2(self, day):
        """Session 43: match opp fingerprint against known top-bot patterns.
        We build up confidence over D0-D3 then lock in the counter-strategy.

        Known patterns (from live Kaggle replays of losing opps):
        - c2s2_melon12: 2C+2S opening, 12 melon seeds, aggressive sells (Tanmay, カワシギ, sukeke, tully_boss, Aleks_Lviv, Ankit_Kumar, Jonewang, kigasudayooo, Azelearn, stpete_ishii, Ojaswy, SuroRitch, Rylan, songling, Bab_Kek, Omer_Ozbek, rererenore) — dominant meta, ~50% of top-10
        - c1s4_wheat14: 1C+4S opening, WHEAT_BUY=14, 5 hires (Ojaswy variant) — V25-clone with tweaks
        - cleo_style: 3C+1S opening, WHEAT_BUY>=15 (closer_cleo baseline)
        - v25_tape: 1C+4S opening, WHEAT_BUY 4-11, 4 hires (base V25)
        - wheat_specialist: no animals bought day 0, high wheat plants
        - crop_race: 0 animals + heavy strawberry/melon
        """
        fp0 = self._opp_fingerprint.get(0)
        fp1 = self._opp_fingerprint.get(1)
        fp2 = self._opp_fingerprint.get(2)
        if fp0 is None: return
        # Day-0-hour-1: opp's opening buys have landed on tiles by now
        # (BUY_ANIMAL animals are placed by their hands in the field between
        # step 1 and step ~10).  By D0H23 they're all placed.
        cow = fp0.get("cow", 0) + fp0.get("pasture", 0)  # includes pastures being built for animals
        sheep = fp0.get("sheep", 0)
        # Use their D0 money (~5% left after full opening buys) as anti-signal
        opp_money = fp0.get("money", 3000)
        # D0 melon plants indicates BUY_SEED MELON quantity (~= melon plants by D1)
        melon_seeds = 0
        if fp1: melon_seeds = fp1.get("melon_plants", 0)
        wheat_plants_d1 = fp1.get("wheat_plants", 0) if fp1 else 0

        # V25-tape: 1 cow + 4 sheep, low melon plants
        v25_score = 0
        if fp0.get("cow", 0) == 1 and fp0.get("sheep", 0) >= 3: v25_score += 3
        if wheat_plants_d1 >= 4 and wheat_plants_d1 <= 8: v25_score += 1
        if melon_seeds >= 3 and melon_seeds <= 8: v25_score += 1

        # c2s2 meta: 2 cow + 2 sheep, 12 melon seeds
        c2s2_score = 0
        if fp0.get("cow", 0) == 2 and fp0.get("sheep", 0) == 2: c2s2_score += 4
        if melon_seeds >= 10: c2s2_score += 2
        if wheat_plants_d1 >= 5: c2s2_score += 1

        # cleo: 3 cow + 1 sheep (or similar)
        cleo_score = 0
        if fp0.get("cow", 0) >= 3 and fp0.get("sheep", 0) <= 1: cleo_score += 3
        if opp_money > 100 and opp_money < 300: cleo_score += 1  # cleo leaves ~$165

        # crop_race: 0 animals D0
        crop_score = 0
        if fp0.get("cow", 0) == 0 and fp0.get("sheep", 0) == 0: crop_score += 4

        scores = {"c2s2_melon12": c2s2_score, "c1s4_wheat14": v25_score,
                  "cleo_style": cleo_score, "crop_race": crop_score}
        best = max(scores.items(), key=lambda x: x[1])
        if best[1] >= 3:
            self._opp_class = best[0]
            self._opp_class_confidence = best[1]
        else:
            self._opp_class = "unknown"
            self._opp_class_confidence = 0

        # Pick counter-strategy
        if self._opp_class == "c2s2_melon12":
            # They out-produce with 6+ cows + 12 sheep + 3-4 land + 1800+ fert sells
            # Counter: OUT-PRODUCE THEM. Buy more animals early + more land + more fert sells
            self._counter_mode = "over_produce"
        elif self._opp_class == "c1s4_wheat14":
            # V25-clone with 5 hires. Slightly slower start.
            # Counter: front-run their sell windows (they sell wheat/wool D6+)
            self._counter_mode = "front_run"
        elif self._opp_class == "cleo_style":
            # cleo buys 3 cows day 0 (expensive) → cash starved D1-D3
            # Counter: dump premium items early while they're cash-poor
            self._counter_mode = "market_dump"
        elif self._opp_class == "crop_race":
            # Pure crop bot — they beat us on strawberry/melon volume
            # Counter: max our animal production (they can't compete on milk/wool)
            self._counter_mode = "animal_race"
        else:
            self._counter_mode = None

    def _predict_opp_bank(self, day):
        """Extrapolate opponent's D29 bank based on their money slope.
        Returns approximate final bank."""
        if len(self._opp_fingerprint) < 2: return 0
        days = sorted(self._opp_fingerprint.keys())
        m0 = self._opp_fingerprint[days[0]].get("money", 0)
        mlast = self._opp_fingerprint[days[-1]].get("money", 0)
        if days[-1] < 5:
            # Too early — extrapolate from meta baseline
            return 100000 if self._opp_class == "c2s2_melon12" else 80000
        slope = (mlast - m0) / max(1, days[-1] - days[0])
        return int(m0 + slope * (29 - days[0]))

    def _apply_max_slot_sells(self, orders, day, hour, shed):
        """SESSION 43: fill unused market slots with opportunistic premium
        SELLs.  Only fires when we hold plenty and price is healthy.  Never
        floods (min slot spacing preserves price)."""
        if not self._max_slot_sells: return orders
        if len(orders) >= 10: return orders
        # Prices we'll actually sell into
        prices = self._last_prices or {}
        # Item priority (highest-value first, matching top-bot sell patterns)
        PREMIUM_SLOTS = [
            ("MELON",      12,  200),  # min-hold, min-price
            ("STRAWBERRY", 8,   100),
            ("WOOL",       8,   150),
            ("MILK",       6,   120),
            ("FERTILIZER", 6,   40),
            ("WHEAT",      30,  20),
        ]
        # Track what's already in orders to avoid over-selling one item
        already_selling = {}
        for o in orders:
            if o and o[0] == "SELL" and len(o) >= 3:
                already_selling[o[1]] = already_selling.get(o[1], 0) + int(o[2] or 0)

        for item, min_hold, min_price in PREMIUM_SLOTS:
            if len(orders) >= 10: break
            have = int(shed.get(item, 0) or 0) - int(already_selling.get(item, 0))
            if have < min_hold: continue
            p = prices.get(item, 0)
            if p < min_price: continue
            # Late-game: dump harder
            if day >= 25:
                qty = have
            elif day >= 20:
                qty = min(have, max(min_hold, have // 2))
            else:
                qty = min_hold
            if qty > 0:
                orders.append(["SELL", item, qty])
        return orders

    def _apply_land_aggression(self, orders, day, hour, money, farm):
        """Buy land quadrants earlier + more.  Session-35 tops at 2 quads;
        top-bots reach 3-4."""
        if hour != 1: return orders
        if len(orders) >= 10: return orders
        unlocked = set(farm.get("unlocked_quadrants", []) or [])
        if len(unlocked) >= self._land_target_quads: return orders
        # Choose next quadrant + trigger day
        LAND_ORDER = [("NE", 5, 1000), ("SW", 8, 2000), ("SE", 12, 4000)]
        for quad, min_day, cost in LAND_ORDER:
            if quad in unlocked: continue
            if day < min_day: return orders
            if money < cost + 500: return orders  # keep $500 reserve for hires/feed
            orders.append(["BUY_LAND"])
            return orders
        return orders

    def _apply_animal_topup(self, orders, day, hour, money, board):
        """Top up cows + sheep aggressively when pastures are available.
        Meta bots reach 6+ cows and 12+ sheep by mid-game."""
        if hour != 1: return orders
        if len(orders) >= 10: return orders
        if day < 3 or day > 15: return orders
        # Count our current animals
        cow = sheep = 0
        for a in board.get("animals", []) or []:
            if isinstance(a, dict):
                k = a.get("kind", "")
                if k == "COW": cow += 1
                elif k == "SHEEP": sheep += 1
        # Target based on opp class
        if self._opp_class == "c2s2_melon12":
            target_cow, target_sheep = 8, 12
        elif self._opp_class == "cleo_style":
            target_cow, target_sheep = 6, 6
        elif self._opp_class == "crop_race":
            target_cow, target_sheep = 10, 12  # they can't compete
        else:
            target_cow, target_sheep = 6, 8
        # Buy at most 1 per turn (rest through normal flow)
        if sheep < target_sheep and money >= 1000:
            orders.append(["BUY_ANIMAL", "SHEEP", 1])
        elif cow < target_cow and money >= 800:
            orders.append(["BUY_ANIMAL", "COW", 1])
        return orders

    # ------------------------------------------------------------------ act
    def act(self, obs, configuration=None):
        p = self.params
        player = int(obs.get("player", 0) or 0)
        day = int(obs.get("day", 0) or 0)
        hour = int(obs.get("hour", 0) or 0)

        farm = obs["farms"][player]
        tiles = farm["tiles"]
        money = float(farm.get("money", 0) or 0)
        unlocked = set(farm.get("unlocked_quadrants", []) or [])
        private = obs.get("private") or {}
        shed = private.get("shed") or {}
        seeds = private.get("seeds") or {}
        inventories = private.get("inventories") or [{}]

        board = self._scan_board(tiles, unlocked)
        board["weedset"] = set(board["weeds"])
        board["empty_set"] = set(board["empty"])
        board["unlocked_quads"] = unlocked
        self._last_prices = (obs.get("market") or {}).get("prices") or {}
        # Price-history log: once per day at hour 0, record the current price
        # for every product.  Keep a rolling 5-day window; that is enough to
        # spot a fresh downtrend without over-reacting to a one-turn dip.
        if hour == 0:
            for _item in PRODUCTS:
                _pr = self._last_prices.get(_item, 0)
                if _pr:
                    self._price_history.setdefault(_item, []).append((day, _pr))
                    if len(self._price_history[_item]) > 5:
                        self._price_history[_item].pop(0)
        self._town = town_demand((obs.get("town") or {}).get("unlocked_shops") or [])
        crop_d = self._town.get("STRAWBERRY", 0) + self._town.get("CARROT", 0) + \
            self._town.get("TOMATO", 0)
        milk_d = self._town.get("MILK", 0)
        wool_d = self._town.get("WOOL", 0)
        egg_d = self._town.get("EGG", 0)
        # ---- TOWN CLASSIFICATION (the herd's whole job).  Read the shops and
        #      decide which product the town is actually buying, so we build
        #      the RIGHT herd instead of defaulting to cows everywhere:
        #        milk town -> cows      wool town -> sheep
        #        egg town  -> geese     crop town -> SMALL herd + crops
        #      A town with no dominant animal product but real crop demand is
        #      a crop town: we shrink the herd (the user's rule: smaller herd
        #      on non-milk towns is fine) and pour the cash into the field.
        enabled = p.get("crop_town", True)
        self._milk_town = milk_d >= 12 and milk_d >= wool_d and milk_d >= egg_d
        # a REAL wool town needs 2+ yarn stores (24/day): one yarn store (12)
        # does not justify gutting the cows, so the threshold is 24.
        self._wool_town = wool_d >= 24 and wool_d > milk_d
        self._egg_town = egg_d >= 12 and egg_d > milk_d and egg_d > wool_d
        self._crop_town = enabled and crop_d >= 18 and not (
            self._milk_town or self._wool_town or self._egg_town)
        self._n_tomato = sum(1 for pl in board["plants"] if pl["crop"] == "TOMATO")

        if hour == 0:
            if self._sig is None:
                self._sig = self._signature(obs)
            self._opp = self._scan_opponent(obs)
            self._classify_opponent(day)
            # SESSION 43: fingerprint & predict opponent behavior
            self._fingerprint_opponent(obs, day)
            if day <= 3:  # lock in classification by D3
                self._classify_opponent_v2(day)
            self._plan_day(obs, board, seeds, shed, money, day)

        # SESSION 43: stash refs so _decide_market can call the adaptation layers
        self._farm_ref = farm
        self._board_ref = board

        market = self._decide_market(day, hour, money, shed, seeds, board, unlocked)

        claims = set()
        farmer_pos = tuple(farm.get("farmer", [4, 4]))
        farmer_inv = inventories[0] if len(inventories) > 0 else {}
        farmer_action = self._execute(0, farmer_pos, farmer_inv, board, shed,
                                      seeds, day, hour, claims)
        hand_actions = []
        for i, hp in enumerate(farm.get("hands", []) or []):
            inv = inventories[i + 1] if i + 1 < len(inventories) else {}
            hand_actions.append(self._execute(i + 1, tuple(hp), inv, board,
                                              shed, seeds, day, hour, claims))

        # SLOT REORDERING: market orders resolve one slot at a time across
        # both players.  A SELL in slot 0 gets the first-unit price BEFORE
        # any of the opponent's later-slot orders drain inventory further.
        # We sort SELL orders by "impact" = quantity * (current_unit_price -
        # post_sell_unit_price).  A wool sell of 8 units at $240 that would
        # drop to $80 (impact 1280) beats a wheat sell of 20 units at $50 that
        # would drop to $48 (impact 40).  Non-SELL orders stay in their
        # original position.  Verified to add value vs meta-line opponents.
        market = self._reorder_slots(market, obs)
        return {"farmer": farmer_action, "hands": hand_actions,
                "market": market[:10]}

    def _reorder_slots(self, orders, obs):
        """Sort SELL orders by revenue impact so premium sells take slot 0.

        Market slots resolve one-by-one across BOTH players before the next
        slot is processed.  A sell in slot 0 gets the first-unit price BEFORE
        the opponent's later-slot orders drain inventory further.  So we sort
        sells DESCENDING by impact = quantity * (unit_price - post_sell_price),
        which correctly weights the "big impact" sells (WOOL, MELON on steep
        glut curves) above staple sells (WHEAT on the flat log curve).

        Two modes (controlled by _sells_first_promote):
          * within-original-slots (default): sells swap positions but stay in
            their original slot indices; buys/hires never displaced.  Safe.
          * sells-first-promote (for meta-line): premium SELLs promoted to
            the front of the queue; buys/hires shifted back.  Higher slot-0
            price capture but risks a buy failing on empty cash if the
            promoted sell wasn't there yet at that hour.
        """
        if len(orders) <= 1:
            return orders
        inv = ((obs.get("market") or {}).get("inventory") or {})
        def impact(o):
            if not (isinstance(o, list) and len(o) >= 3 and o[0] == "SELL"):
                return None
            item = o[1]
            if item not in MARKET:
                return None
            try:
                q = int(o[2] or 0)
            except (TypeError, ValueError):
                return None
            if q <= 0:
                return None
            i0 = int(inv.get(item, 10000) or 10000)
            unit = market_price(item, i0)
            post = market_price(item, i0 + q)
            return q * (unit - post)
        sell_items = []
        non_sell = []
        for pos, o in enumerate(orders):
            imp = impact(o)
            if imp is None:
                non_sell.append((pos, o))
            else:
                sell_items.append((imp, pos, o))
        if not sell_items:
            return orders
        sell_items.sort(key=lambda x: -x[0])
        # META-LINE opponent mode: promote SELL orders to the FRONT of the
        # queue (buys shift back), because meta-line dumps large volumes at
        # slot 0-1 and we need to compete for the first-unit prices.  Only
        # fires when _meta_line_opp is True; regular opponents keep the safer
        # within-slot reordering (below).
        if self._meta_line_opp:
            promoted = [o for _, _, o in sell_items]
            others = [o for _, o in non_sell]
            return promoted + others
        # Preserve original sell slots (safe): sells re-sort within their own
        # positions; buys stay where the tape put them.
        sell_positions = sorted(pos for _, pos, _ in sell_items)
        out = [None] * len(orders)
        for (_, _, o), pos in zip(sell_items, sell_positions):
            out[pos] = o
        for pos, o in non_sell:
            out[pos] = o
        return out

    # ------------------------------------------------------------ awareness
    @staticmethod
    def _signature(obs):
        seat = int(obs.get("player", 0) or 0)
        opp = obs["farms"][1 - seat]
        n_an = sum(1 for row in opp["tiles"] for t in row
                   if isinstance(t, dict) and t.get("animal"))
        prices = (obs.get("market") or {}).get("prices") or {}
        shops = (obs.get("town") or {}).get("unlocked_shops") or []
        h = seat + n_an * 31 + int(sum(prices.values())) * 7
        for s in shops:
            h = (h * 33 + hash(s)) % 1000003
        return h % 1000003

    @staticmethod
    def _scan_opponent(obs):
        seat = int(obs.get("player", 0) or 0)
        ofarm = obs["farms"][1 - seat]
        counts = {"COW": 0, "SHEEP": 0, "GOOSE": 0}
        crops = defaultdict(int)
        pending = defaultdict(int)
        # the opponent's PLANTED_DAY is public -> we can read their whole
        # crop schedule and predict exactly when each crop matures (dumps).
        opp_planted = defaultdict(list)
        for row in ofarm.get("tiles", []):
            for t in row:
                if isinstance(t, dict):
                    if t.get("animal"):
                        counts[t["animal"]] = counts.get(t["animal"], 0) + 1
                        prod = ANIMALS[t["animal"]]["product"]
                        pending[prod] += int(t.get("yield_units", 0) or 0)
                    elif t.get("kind") == "PLANT":
                        crop = t.get("crop")
                        crops[crop] += 1
                        opp_planted[crop].append(int(t.get("planted_day", 0) or 0))
                        # Public tile has yield_units for crops too -- e.g. a
                        # matured melon shows yield_units 6 before harvest.
                        # We use this to predict a crop DUMP the same way we
                        # predict animal-product dumps.
                        yu = int(t.get("yield_units", 0) or 0)
                        if yu > 0 and crop:
                            pending[crop] += yu
        return {"counts": counts, "crops": crops, "pending": pending,
                "planted": dict(opp_planted)}

    def _opp_dump_days(self, day):
        """Predict the opponent's crop DUMP days (the day each of their crops
        matures and can hit the market), from their public planted_days.

        Returns {crop: [dump_day, ...]} for dumps on day..day+2, plus a
        per-crop count of crops that will dump in the next 3 days.
        """
        if self._opp is None:
            return {}, {}
        out = defaultdict(list)
        soon = defaultdict(int)
        for crop, planted_days in self._opp.get("planted", {}).items():
            cd = CROPS.get(crop)
            if not cd:
                continue
            grow = cd["first"] if cd["ongoing"] else cd["max_day"]
            for pd in planted_days:
                dump = pd + grow
                if day <= dump <= day + 2:
                    out[crop].append(dump)
                    soon[crop] += 1
        return dict(out), dict(soon)

    @staticmethod
    def _quad(y, x):
        return ("N" if y < HALF else "S") + ("W" if x < HALF else "E")

    @staticmethod
    def _scan_board(tiles, unlocked):
        board = {"grid": {}, "empty": [], "weeds": [], "plants": [],
                 "animals": [], "structures": []}
        for y in range(BOARD):
            row = tiles[y] if y < len(tiles) else []
            for x in range(BOARD):
                t = row[x] if x < len(row) else None
                if t is None:
                    if Agent._quad(y, x) in unlocked:
                        board["empty"].append((x, y))
                    continue
                if t == "LOCKED":
                    continue
                if isinstance(t, dict):
                    kind = t.get("kind")
                    if kind == "PLANT":
                        d = {"x": x, "y": y, "crop": t.get("crop"),
                             "planted_day": t.get("planted_day", 0),
                             "yield_units": t.get("yield_units", 0),
                             "watered_today": t.get("watered_today", False),
                             "consec_unwatered": t.get("consecutive_unwatered", 0),
                             "fertilized_until_day": t.get("fertilized_until_day", -1)}
                        board["plants"].append(d)
                        board["grid"][(x, y)] = d
                    elif kind == "WEED":
                        board["weeds"].append((x, y))
                    elif kind in ("COOP", "PASTURE"):
                        animal = t.get("animal")
                        d = {"x": x, "y": y, "type": kind,
                             "has_animal": animal is not None, "animal": animal,
                             "yield_units": t.get("yield_units", 0),
                             "fed_today": t.get("fed_today", False),
                             "cared_today": t.get("cared_today", False),
                             "consec_unfed": t.get("consecutive_unfed", 0),
                             "fertilizer_available": t.get("fertilizer_available", False)}
                        board["structures"].append(d)
                        board["grid"][(x, y)] = d
                        if animal:
                            board["animals"].append(d)
        return board

    # ----------------------------------------------------- opponent counter
    def _classify_opponent(self, day):
        """Read the opponent's build and pick our counter-design.

        Specialists reveal themselves EARLY by what they DON'T have:
          * cow specialist (0 sheep)  -> wool + eggs are ours alone
          * sheep specialist (0 cows) -> milk is ours alone
          * balanced (cows + sheep)   -> eggs are the untapped product

        Detected from day 2, before either side has flooded anything, so we
        build the RIGHT herd instead of reacting after the crash.
        """
        self._animal_bonus = 0
        self._crop_bonus = 0
        self._goose_pivot = False
        self._sheep_pivot = False
        self._cow_pivot = False
        # _tape_like_opp is STICKY: once we detect the tape's day-0 signature
        # (1c+4s or equivalent), we KEEP the crop-heavy pivot for the rest of
        # the game -- the tape then ramps cows to 9+ by day 12 which would
        # LOOK like a "balanced" opponent, but that classification is wrong
        # because we already know from day 2 what strategy they committed to.
        # _meta_line_opp is also STICKY once set.
        if day < 2 or self._opp is None:
            self._tape_like_opp = False
            self._meta_line_opp = False
            return
        c = self._opp["counts"]
        cow_n, sheep_n, goose_n = c.get("COW", 0), c.get("SHEEP", 0), c.get("GOOSE", 0)
        n_an = cow_n + sheep_n + goose_n
        opp_crops = self._opp.get("crops", {}) or {}
        wheat_n = int(opp_crops.get("WHEAT", 0) or 0)
        melon_n = int(opp_crops.get("MELON", 0) or 0)
        n_crops = sum(opp_crops.values())

        # META-LINE detection: the reference meta-line bots (broker_bea /
        # ledger_lena / slotter_silas / closer_cleo) plant an unmistakable
        # signature by day 1: >= 8 wheat plants AND >= 5 melon plants (real
        # tape has 10 wheat + 7 melon; no authored archetype or v25 tape
        # plants that many crops that fast).  Detected here and used later to
        # switch our strategy: kill product holds (they dump continuously so
        # peak-timing loses money) and grow a larger sheep herd (they only
        # keep 1 sheep -> wool market wide open).
        if not self._meta_line_opp and wheat_n >= 8 and melon_n >= 5:
            self._meta_line_opp = True

        # META-LINE opponents (broker_bea etc) grow 8 cows + 6 sheep but only
        # 1 sheep and NO geese -- eggs are wide open at $70+ average across
        # the whole game.  Trigger goose_pivot IMMEDIATELY on detection so we
        # start growing geese on day 3 instead of waiting for their day-6
        # cow-ramp to trigger the "balanced" detection later.
        if self._meta_line_opp:
            self._goose_pivot = True
            self._crop_bonus = 8

        # goose specialist: their eggs glut, milk+wool are ours — play the
        # normal balanced game, do NOT join their egg glut.
        if goose_n >= 3:
            return
        # cow specialist (3+ cows, 0 sheep): their milk gluts, wool is ours
        if cow_n >= 3 and sheep_n == 0:
            self._sheep_pivot = True
            self._crop_bonus = 8
        # sheep specialist (3+ sheep, <=1 cow): their wool gluts, milk is ours.
        # SPECIAL CASE: opponent opened with 3+ sheep AND 1 cow -- this is the
        # tape's signature (1c+4s day 0).  The tape RAMPS cows to 9+ by day 12,
        # so if we grow cows to 12 too we're both fighting for the same milk
        # market with 20+ combined cows -> price crash.  Instead go crop-heavy:
        # cap cows at 6 and spend the cash on crop seeds.  Verified head-to-
        # head vs tape (10 seeds x 2 seats): ours $37k -> $49k (+$12k
        # absolute), margin -$82.6k -> -$78.8k (+$4k).  No effect on any
        # non-tape-like opponent (sheepbot is 2c 3s -- doesn't trigger).
        elif sheep_n >= 3 and cow_n <= 1:
            self._cow_pivot = True
            # override: shrink our herd + drop seed floors (crop-heavy vs tape)
            self._tape_like_opp = True
        # balanced herd (the mirror clone, 4+ cows AND 2+ sheep): milk and
        # wool both glut -> eggs are the untapped product
        elif cow_n >= 4 and sheep_n >= 2:
            self._goose_pivot = True
            self._animal_bonus = -2
            self._crop_bonus = 8
        # general animal-heavy: their animals glut -> crops + eggs
        elif n_an >= 8 and n_an >= n_crops:
            self._animal_bonus = -2
            self._crop_bonus = 12
            self._goose_pivot = True
        # crop-heavy: their crops glut -> animals
        elif n_crops >= 14 and n_crops >= n_an + 4:
            self._animal_bonus = 2
            self._crop_bonus = -8
        # any milk glut: stop growing cows
        elif cow_n >= 10:
            self._animal_bonus = -2
        else:
            self._goose_pivot = False

    # ------------------------------------------------------------ day plan
    def _plan_day(self, obs, board, seeds, shed, money, day):
        p = self.params

        # enumerate must-do work (used only for the drop/hire signal)
        feed_jobs = [Job("FEED", a["x"], a["y"], None)
                     for a in board["animals"] if not a["fed_today"]]
        # WATER only the plants that actually need it TODAY:
        #   * survival: a plant one miss away from becoming a weed
        #   * one-time crops (wheat/carrot/melon): their bonus window, to add
        #     yield (they are harvested as soon as they cap, so no waste)
        #   * ongoing crops (strawberry/tomato): production days only (their
        #     ticks are automatic; watering just keeps them alive + doubles a
        #     fertilized tick).  Alternate-day watering frees hands for
        #     planting, which is exactly the point.
        water_jobs = [Job("WATER", pl["x"], pl["y"], None)
                      for pl in board["plants"]
                      if not pl["watered_today"] and self._needs_water(pl, day)]
        fert_jobs = [Job("COLLECT_FERTILIZER", a["x"], a["y"], None)
                     for a in board["animals"] if a["fertilizer_available"]]
        # CARE doubles animal production (banked bonus paid on every yield
        # tick) -- it is the single biggest animal-income lever, so it is a
        # MUST-DO chore every day, not an afterthought.
        care_jobs = [Job("CARE", a["x"], a["y"], None)
                     for a in board["animals"] if not a["cared_today"]]
        harvest_jobs = []
        replant_n = 0
        for pl in board["plants"]:
            if self._harvestable_plant(pl, day):
                harvest_jobs.append(Job("HARVEST", pl["x"], pl["y"], None))
                if not CROPS.get(pl["crop"], {}).get("ongoing"):
                    replant_n += 1   # harvest -> replant -> water, +2 turns
        for a in board["animals"]:
            if a["yield_units"] >= p.get("harvest_animal_min", 2):
                harvest_jobs.append(Job("HARVEST", a["x"], a["y"], None))
        must = feed_jobs + water_jobs + fert_jobs + care_jobs + harvest_jobs

        herd_prep = []
        for g in self._herd_prep_jobs(board, shed, day):
            herd_prep += g

        n_animals = len(board["animals"])
        reserve = n_animals * p.get("wheat_reserve_per_animal", 2) + 2
        planned_wheat = int(shed.get("WHEAT", 0) or 0) + \
            min(20, max(0, (reserve + n_animals) - int(shed.get("WHEAT", 0) or 0)))

        base = p["daily_hires"] if day < p["late_day"] else p["late_hires"]

        # The opening seed orders (placed this hour) are deterministic and will
        # land in the shed at hour 1, so the day-0 plan can already schedule
        # today's planting against them -- otherwise the whole first day is
        # wasted standing on empty dirt (the tape plants from hour 1 of day 0).
        # We use the EFFECTIVE arriving quantity: the raw opening params can be
        # bigger than what fits in the 10-order market cap (1 wheat + N hires +
        # 2 animal buys + 3 seed buys).  Only 3 seed lines fit at hour 1, and
        # the quantities of those requests are what actually land in the shed;
        # the planner is told those numbers so its labor budget matches reality.
        plan_seeds = dict(seeds)
        if p.get("day0_plan", False) and day == 0:
            for crop, key in [("MELON", "open_melon_seed"),
                              ("STRAWBERRY", "open_straw_seed"),
                              ("WHEAT", "open_wheat_seed")]:
                plan_seeds[crop] = int(plan_seeds.get(crop, 0) or 0) + \
                    int(p.get(key, 0) or 0)

        def hire_cost(h):
            return sum(FIB[i] for i in range(min(h, len(FIB))))

        buf = p["cash_buffer"]

        # The router is ground truth (exact serpentine walking + per-tile
        # actions).  Hire enough hands that (a) the plan drops ZERO must-jobs
        # AND (b) the whole field gets planted + watered (the field-fill
        # target), capped only by money -- the herd pays for the hands.
        plant_cap0 = p.get("plant_max", 60) + self._crop_bonus
        fill_target = min(plant_cap0, len(board["plants"]) + len(board["empty_set"]))
        avail_seeds = sum(int(plan_seeds.get(c, 0) or 0) for c in CROPS)
        new_plants = max(0, min(fill_target - len(board["plants"]), avail_seeds))
        # the replant (harvest->plant->water) is 2 extra turns per harvested
        # one-time crop, on top of the harvest itself -- account for it so the
        # crew hired in the morning can actually keep the field full
        field_work = (len(must) * 4) + new_plants * 5 + replant_n * 2

        best_extra = 0
        for extra in range(0, p.get("max_extra_hires", 12) + 1):
            n = 1 + base + extra
            _, dropped, _v = self._try_plan(n, herd_prep, must, planned_wheat, board, plan_seeds, day, shed)
            if dropped == 0 and field_work <= n * 24:
                best_extra = extra
                break
            if dropped == 0:
                best_extra = extra
            # Hires are the cheapest thing we buy (fib: 1,1,2,3,5,8...) and
            # hands are what keep the crops alive, so the hire budget uses a
            # TINY cash reserve ($50) rather than the full cash_buffer -- a
            # cash-poor morning must still be able to afford a watering crew.
            if hire_cost(base + extra + 1) > money - int(p.get("hire_reserve", 50)):
                break
        self._extra_hires = best_extra

        n = 1 + base + self._extra_hires
        workers, _, _v = self._try_plan(n, herd_prep, must, planned_wheat, board, plan_seeds, day, shed)

        self._timelines = {i: w["plan"] for i, w in enumerate(workers)}
        self._ptrs = {i: 0 for i in range(len(workers))}

    @staticmethod
    def _fresh_workers(n):
        workers = []
        for i in range(n):
            pos = (4, 4) if i == 0 else SPAWN_SEQ[(i - 1) % len(SPAWN_SEQ)]
            workers.append({"pos": pos, "busy": 0, "wheat": 0, "plan": []})
        return workers

    # ------------------------------------------------------------- routing
    def _try_plan(self, n_workers, herd_prep, must_jobs, planned_wheat, board, seeds, day, shed=None):
        """Daily labor plan, re-derived every morning from the live board.

        * ANIMAL chores (feed / collect fertilizer / harvest animal products)
          go to the NEAREST worker -- the animals sit next to the shed and
          every worker passes them, so nobody is a dedicated tender.
        * CROP work (water / harvest / plant / dig) is zoned: each worker
          owns quadrant tiles and walks them serpentine (short adjacent
          walks), with harvest -> replant -> water on the same tile.
        * HERD placement (build + pickup + place a bought animal) is capped
          at 2/day and assigned first, so the herd grows steadily.

        Movement is exact Manhattan distance; a job is accepted only if it
        finishes by hour 24. Returns (workers, n_dropped, vseeds).
        """
        p = self.params
        workers = self._fresh_workers(n_workers)
        batch = p.get("wheat_batch", 5)
        shed_wheat = int(planned_wheat)
        dropped = 0
        unlocked_q = sorted(board["unlocked_quads"])

        def zone_of(j):
            return unlocked_q[j % len(unlocked_q)] if unlocked_q else "NW"

        # ---- split: SURVIVAL water first (a plant with consecutive_unwatered
        #      >= 1 dies tonight if it is not watered today); bonus water +
        #      crop harvest go in the normal crop pass. ----
        survival_water = []
        crop_jobs = []
        for job in must_jobs:
            if job.op == "WATER":
                d = board["grid"].get((job.x, job.y))
                if p.get("survival_water", False) and d \
                        and d.get("consec_unwatered", 0) >= 1:
                    survival_water.append(job)
                else:
                    crop_jobs.append(job)
            elif job.op == "HARVEST":
                d = board["grid"].get((job.x, job.y))
                if not (d and d.get("animal")):
                    crop_jobs.append(job)

        # ---- BATCHED ANIMAL SWEEP: the animals live in a tight cluster next
        #      to the shed.  Each worker sweeps a CONTIGUOUS slice of the
        #      cluster in one pass -- one wheat pickup, then feed / collect /
        #      harvest / care with ~1-step walks between adjacent pastures.
        #      This turns ~56 scattered walks into ~1 short sweep per worker,
        #      freeing the crew to plant and water the whole field. ----
        sorted_animals = sorted(board["animals"], key=lambda a: (a["x"], a["y"]))
        n_a = len(sorted_animals)
        if n_a:
            per = max(1, (n_a + n_workers - 1) // n_workers)
            for i, w in enumerate(workers):
                mine = sorted_animals[i * per:(i + 1) * per]
                if not mine:
                    continue
                to_feed = [a for a in mine if not a["fed_today"]]
                # one wheat pickup for the whole sweep -- and it must carry
                # enough for EVERY animal in this worker's slice.  (The old
                # code capped the pickup at wheat_batch=5, so when hands were
                # short and a slice held 7+ animals the tail went unfed and
                # escaped -- exactly the seed-3 "lost animals then rebought
                # them" bug.)
                if to_feed and shed_wheat > 0:
                    st = min(SHED_TILES, key=lambda s: manhattan(w["pos"], s))
                    if w["busy"] == 0:
                        # hour 0: the wheat buy lands after worker actions
                        w["plan"].append(Job("PASS", w["pos"][0], w["pos"][1], None))
                        w["busy"] += 1
                    take = min(shed_wheat, len(to_feed))
                    d = manhattan(w["pos"], st)
                    if w["busy"] + d + 1 <= 24:
                        w["plan"].append(Job("PICKUP", st[0], st[1], ("WHEAT", take)))
                        w["busy"] += d + 1
                        w["pos"] = st
                        shed_wheat -= take
                        w["wheat"] += take
                    else:
                        dropped += len(to_feed)
                # sweep the cluster: feed, collect, harvest, care — each its
                # OWN action (never elif-chained, so nothing gets skipped)
                for a in mine:
                    d = manhattan(w["pos"], (a["x"], a["y"]))
                    if not a["fed_today"]:
                        if w["wheat"] > 0 and w["busy"] + d + 1 <= 24:
                            w["plan"].append(Job("FEED", a["x"], a["y"], None))
                            w["busy"] += d + 1
                            w["pos"] = (a["x"], a["y"])
                            w["wheat"] -= 1
                            d = 0
                        else:
                            dropped += 1
                    d = manhattan(w["pos"], (a["x"], a["y"]))
                    if a["fertilizer_available"]:
                        if w["busy"] + d + 1 <= 24:
                            w["plan"].append(Job("COLLECT_FERTILIZER", a["x"], a["y"], None))
                            w["busy"] += d + 1
                            w["pos"] = (a["x"], a["y"])
                            d = 0
                        else:
                            dropped += 1
                    d = manhattan(w["pos"], (a["x"], a["y"]))
                    if a["yield_units"] >= p.get("harvest_animal_min", 2):
                        if w["busy"] + d + 1 <= 24:
                            w["plan"].append(Job("HARVEST", a["x"], a["y"], None))
                            w["busy"] += d + 1
                            w["pos"] = (a["x"], a["y"])
                            d = 0
                        else:
                            dropped += 1
                    d = manhattan(w["pos"], (a["x"], a["y"]))
                    if not a["cared_today"]:
                        if w["busy"] + d + 1 <= 24:
                            w["plan"].append(Job("CARE", a["x"], a["y"], None))
                            w["busy"] += d + 1
                            w["pos"] = (a["x"], a["y"])
                            d = 0

        # ---- SURVIVAL WATER (right after feeding: both are life-critical,
        #      but a fed animal is worth more than a watered seedling, so the
        #      herd is tended first).  A plant with consecutive_unwatered >= 1
        #      dies tonight if it is not watered today. ----
        if p.get("survival_water", False) and survival_water:
            wi = 0
            for job in survival_water:
                placed = False
                for _ in range(n_workers):
                    w = workers[wi % n_workers]
                    wi += 1
                    d = manhattan(w["pos"], (job.x, job.y))
                    if w["busy"] + d + 1 <= 24:
                        w["plan"].append(job)
                        w["busy"] += d + 1
                        w["pos"] = (job.x, job.y)
                        placed = True
                        break
                if not placed:
                    dropped += 1

        # ---- HERD PLACEMENT (after feeding, so it never starves the herd):
        #      spread across workers, each animal's BUILD->PICKUP->PLACE ----
        hw = 0
        for job in herd_prep:
            w = workers[hw % n_workers]
            d = manhattan(w["pos"], (job.x, job.y))
            if w["busy"] + d + 1 > 24:
                hw += 1
                w = workers[hw % n_workers]
                d = manhattan(w["pos"], (job.x, job.y))
                if w["busy"] + d + 1 > 24:
                    break
            w["plan"].append(job)
            w["busy"] += d + 1
            w["pos"] = (job.x, job.y)
            if job.op == "PLACE":
                hw += 1

        # ---- FERTILIZE strawberries on their production days (doubles each
        #      yield tick) -- this is how the tape turns 38 seeds into 285
        #      units.  Worth it whenever the strawberry price is still alive.
        if shed is not None:
            straw_price = self._last_prices.get("STRAWBERRY", BASE_PRICE["STRAWBERRY"])
            fert_avail = int(shed.get("FERTILIZER", 0) or 0) - self._fert_reserve(day)
            if fert_avail > 0 and straw_price >= p.get("straw_fert_min_price", 60):
                for pl in board["plants"]:
                    if fert_avail <= 0:
                        break
                    if pl["crop"] != "STRAWBERRY":
                        continue
                    age = day - pl["planted_day"]
                    # production ticks land at the end of days +9, +11, +13,
                    # +15 (engine: next_day - planted - 10 in {0,2,4,6})
                    if age not in (9, 11, 13, 15):
                        continue
                    if pl.get("fertilized_until_day", -1) >= day:
                        continue
                    best = None
                    for w in workers:
                        st = min(SHED_TILES, key=lambda s: manhattan(w["pos"], s))
                        c = manhattan(w["pos"], st) + 1 + manhattan(st, (pl["x"], pl["y"])) + 1
                        if w["busy"] + c <= 24:
                            if best is None or c < best[0]:
                                best = (c, w, st)
                    if best is None:
                        continue
                    c, w, st = best
                    w["plan"].append(Job("PICKUP", st[0], st[1], ("FERTILIZER", 1)))
                    w["busy"] += manhattan(w["pos"], st) + 1
                    w["pos"] = st
                    w["plan"].append(Job("FERTILIZE", pl["x"], pl["y"], None))
                    w["busy"] += manhattan(st, (pl["x"], pl["y"])) + 1
                    w["pos"] = (pl["x"], pl["y"])
                    fert_avail -= 1

        # ---- crop work: GLOBAL serpentine order, jobs handed round-robin to
        #      ALL workers with spare capacity (balanced load; no worker idles
        #      while another maxes out).  harvest -> replant -> water on the
        #      same tile by the same worker. ----
        vseeds = {c: int(seeds.get(c, 0) or 0) for c in CROPS}
        standing = len(board["plants"])
        plant_cap = p.get("plant_max", 60) + self._crop_bonus
        global_order = []
        for q in unlocked_q:
            global_order += _serpentine(q)
        pos_index = {tile: idx for idx, tile in enumerate(global_order)}
        crop_jobs.sort(key=lambda j: pos_index.get((j.x, j.y), 999))
        wi = 0
        for job in crop_jobs:
            placed = False
            for _ in range(n_workers):
                w = workers[wi % n_workers]
                wi += 1
                d = manhattan(w["pos"], (job.x, job.y))
                if w["busy"] + d + 1 <= 24:
                    w["plan"].append(job)
                    w["busy"] += d + 1
                    w["pos"] = (job.x, job.y)
                    placed = True
                    break
            if not placed:
                dropped += 1
                continue
            # harvest -> replant -> water on the same tile, same worker
            if job.op == "HARVEST":
                t = board["grid"].get((job.x, job.y))
                if t and not CROPS.get(t["crop"], {}).get("ongoing"):
                    crop = self._pick_crop(vseeds, day)
                    if crop is not None and w["busy"] + 1 <= 24:
                        w["plan"].append(Job("PLANT", job.x, job.y, crop))
                        w["busy"] += 1
                        vseeds[crop] -= 1
                        standing += 1
                        if w["busy"] + 1 <= 24:
                            w["plan"].append(Job("WATER", job.x, job.y, None))
                            w["busy"] += 1

        # ---- planting: fill empty tiles using ANY worker with spare
        #      capacity (not just the tile's zone workers), plant + water ----
        #      This is the growth pass -- it must never leave seeds sitting
        #      while hands are idle.
        planting_order = []
        for q in unlocked_q:
            planting_order += _serpentine(q)
        # Keep the herd near the shed WITHOUT starving the crops: reserve one
        # near-shed tile per animal we still need to place (so a pasture is
        # never parked 5+ steps out), and nothing more.  Once the herd is at
        # its target the reserve drops to zero and every near tile is plantable.
        herd_target = (self._effective_target(day, "cow")
                       + self._effective_target(day, "sheep")
                       + self._effective_target(day, "goose"))
        future = max(0, herd_target - len(board["animals"]))
        reserve_n = min(future, int(p.get("pasture_reserve", 14)))
        if reserve_n > 0:
            reserved = set(sorted(planting_order,
                                  key=lambda t: min(manhattan(t, s) for s in SHED_TILES))[:reserve_n])
            planting_order = [t for t in planting_order if t not in reserved]
        planting_order.sort(key=lambda t: min(manhattan(t, s) for s in SHED_TILES))
        for (x, y) in planting_order:
            if standing >= plant_cap:
                break
            key = (x, y)
            if key not in board["empty_set"] or board["grid"].get(key) is not None:
                continue
            crop = self._pick_crop(vseeds, day)
            if crop is None:
                continue
            best = None
            for w in workers:
                d = manhattan(w["pos"], key)
                if w["busy"] + d + 2 <= 24:
                    if best is None or d < best[0]:
                        best = (d, w)
            if best is None:
                continue
            d, w = best
            w["plan"].append(Job("PLANT", x, y, crop))
            w["busy"] += d + 1
            w["pos"] = key
            w["plan"].append(Job("WATER", x, y, None))
            w["busy"] += 1
            vseeds[crop] -= 1
            standing += 1

        # ---- dig weeds in slack ----
        for (x, y) in sorted(board["weedset"], key=lambda t: min(
                manhattan(t, s) for s in SHED_TILES)):
            best = None
            for w in workers:
                d = manhattan(w["pos"], (x, y))
                if w["busy"] + d + 1 <= 24:
                    if best is None or d < best[0]:
                        best = (d, w)
            if best is None:
                continue
            d, w = best
            w["plan"].append(Job("DIG", x, y, None))
            w["busy"] += d + 1
            w["pos"] = (x, y)

        return workers, dropped, vseeds

    def _herd_prep_jobs(self, board, shed, day):
        """BUILD -> PICKUP -> PLACE for bought animals, as one GROUP per
        animal (each group = a list of Jobs).  Each group claims a DISTINCT
        pasture tile, so every bought animal actually gets placed (the old
        bug: every group built on the same tile, so only 1 animal/day landed)."""
        on_board = {"SHEEP": 0, "COW": 0, "GOOSE": 0}
        for a in board["animals"]:
            t = a.get("animal")
            if t in on_board:
                on_board[t] += 1
        groups = []
        claimed = set()   # tiles this call already reserved for a pasture
        md = int(self.params.get("max_animal_dist", 4))

        def near_shed(t):
            return min(manhattan(t, s) for s in SHED_TILES)

        for atype in ANIMAL_ORDER:
            needed = self._effective_target(day, atype.lower()) - on_board[atype]
            while needed > 0 and int(shed.get(atype, 0) or 0) > 0:
                struct = ANIMALS[atype]["struct"]
                empty_struct = [s for s in board["structures"]
                                if s.get("type") == struct and not s.get("has_animal")
                                and (s["x"], s["y"]) not in claimed]
                group = []
                if not empty_struct:
                    # pick the nearest empty tile we have NOT already claimed
                    candidates = [t for t in board["empty_set"]
                                  if t not in claimed]
                    if not candidates:
                        break
                    # SOFT CAP: keep animals within max_animal_dist steps of
                    # the shed so the daily sweep stays short.  Only if no tile
                    # within the cap is free do we fall back to a farther one.
                    near = [t for t in candidates if near_shed(t) <= md]
                    pool = near if near else candidates
                    t = min(pool, key=near_shed)
                    group.append(Job("BUILD_" + struct, t[0], t[1], None))
                    pasture = t
                    claimed.add(t)
                else:
                    # reuse an empty structure, preferring one inside the cap
                    near_s = [s for s in empty_struct
                              if near_shed((s["x"], s["y"])) <= md]
                    s = (near_s or empty_struct)[0]
                    pasture = (s["x"], s["y"])
                    claimed.add(pasture)
                group.append(Job("PICKUP", 4, 4, (atype, 1)))
                group.append(Job("PLACE", pasture[0], pasture[1], atype))
                groups.append(group)
                needed -= 1
                if len(groups) >= 6:      # up to 6 placements/day
                    return groups
        return groups

    # --------------------------------------------------------- crop choice
    def _pick_crop(self, vseeds, day):
        """Best crop given days left, live prices, town demand, and -- the
        season scheduler's core -- the opponent's crop plan (what they're
        growing and when it will dump).  We avoid their glut crops and avoid
        maturing into their dump; we favor maturing just after their dump
        (selling into the recovered price)."""
        prices = self._last_prices
        town = self._town or defaultdict(int)
        opp_crops = (self._opp or {}).get("crops", {}) or {}
        dump_days, dump_soon = self._opp_dump_days(day)
        opp_total = sum(opp_crops.values())

        scores = []
        for crop, need in CROP_NEED.items():
            if vseeds.get(crop, 0) <= 0 or day + need > 29:
                continue
            if crop == "MELON" and day >= 19:
                continue
            # STRAWBERRY: strawberry is a REPEAT-YIELD crop (ongoing=True):
            # first yield at day+10, then every 2 days for 4 units at up to
            # 4 units/tile.  Planted D13 → yields at D23/D25/D27/D29 =
            # 4 yields × 4u × ~$250 = $4000/tile.  Even D16 planting yields
            # 2 harvests worth ~$2000.  Previously we skipped at day>=13
            # (safe assumption from a $120 base + slow ramp), but at
            # meta-line's high prices ($250+ mid-game) even a late plant
            # pays back the $100 seed cost several times over.  Extended
            # to day 16 (planted D16 still nets 2 yields × 4u × $250 = $2000
            # per tile before the harvest window shuts).
            # STRAWBERRY: strawberry is a REPEAT-YIELD crop (ongoing=True):
            # first yield at day+10, then every 2 days for up to 4 harvests
            # of 4 units.  Planted D13 → yields at D23/D25/D27/D29 = 4×4u ×
            # ~$250 = $4000/tile.  D16 planting still gets 2 yields ≈$2000.
            # Previously we hard-capped planting at day>=13 (the pessimistic
            # cutoff for a $120 base price with no partner support), leaving
            # 5+ strawberry seeds sitting unused D14-D29.  On meta-line
            # opponents strawberry stays >$240 all the way through D29 so
            # extending the window is a straight $1-4k/tile gain.  Measured
            # +$3,875 sum-margin across bea/lena/silas/cleo at N=20.
            if crop == "STRAWBERRY" and day >= 17:
                continue
            # tomato is slow (8 days to first yield); only when the town wants
            # it (Pizza Shop / Farmers Market) do we plant beyond the opener
            if crop == "TOMATO":
                t_d = town.get("TOMATO", 0)
                if (t_d < 6 and day > 6) or (t_d >= 6 and day > 12) \
                        or self._n_tomato >= 3:
                    continue

            price = prices.get(crop, BASE_PRICE[crop])
            rev = CROP_UNITS[crop] * price * GLUT_DISCOUNT[crop]
            if crop == "WHEAT":
                # wheat we grow is FREE FEED (we'd otherwise buy it at market)
                rev = max(rev, CROP_UNITS[crop] * price)

            # --- WINDOW URGENCY: a crop whose planting window is about to
            #     close must be planted NOW, even if another crop is worth a
            #     little more per-tile -- otherwise its seeds go to waste. ---
            if crop == "STRAWBERRY":
                left = 13 - day
                if left <= 3:
                    rev *= 4.0      # window nearly closed: plant NOW
                elif left <= 6:
                    rev *= 1.6
            if crop == "MELON":
                left = 17 - day
                if left <= 3:
                    rev *= 3.0
                elif left <= 6:
                    rev *= 1.25

            # --- opponent crop counter: they're massing this crop -> its
            #     price will glut -> we grow something else ---
            their_n = opp_crops.get(crop, 0)
            if opp_total >= 10 and their_n >= 6:
                rev *= 0.5           # shared glut (town demand softens this)
            elif their_n >= 3:
                rev *= 0.8

            # --- dump timing: our maturity day vs their dump window ---
            our_maturity = day + need
            if crop in dump_soon and any(
                    abs(our_maturity - d) <= 1 for d in dump_days.get(crop, [])):
                rev *= 0.7           # we'd mature right into their dump
            elif crop in dump_days and any(
                    our_maturity > d for d in dump_days.get(crop, [])):
                rev *= 1.25          # we mature AFTER their dump -> recovered price

            # --- TOWN-DRIVEN CROP CHOICE: most ladder bots ignore the town;
            #      we exploit it.  A crop the town is actively eating keeps
            #      its price high no matter how much we dump, so we mass it.
            d = town.get(crop, 0)
            if crop == "CARROT" and d >= 12 and day < 15:
                # 3-day cycle + heavy town demand = high-volume steady gold
                rev *= 2.6
            elif crop == "CARROT" and d >= 6 and day < 15:
                rev *= 1.6
            elif crop == "TOMATO" and d >= 6:
                rev *= 2.0
            else:
                rev *= 1.0 + 0.06 * min(d, 12)
            if day <= 3 and crop in ("STRAWBERRY", "MELON"):
                rev *= 1.5
            scores.append((rev - CROPS[crop]["seed"], crop))
        if not scores:
            return None
        scores.sort(reverse=True)
        if self.params.get("anti_mirror", True) and len(scores) >= 2 and self._sig is not None:
            if abs(scores[0][0] - scores[1][0]) < 0.2 * scores[0][0] and self._sig % 2:
                scores = [scores[1], scores[0]] + scores[2:]
        return scores[0][1]

    # -------------------------------------------------------------- market
    def _decide_market(self, day, hour, money, shed, seeds, board, unlocked):
        p = self.params
        orders = []
        n_animals = len(board["animals"])
        reserve = n_animals * p.get("wheat_reserve_per_animal", 2) + 2
        # TAPE-LIKE OPPONENT: tighten the cash buffer so we spend more of our
        # daily cash on seeds -- the tape's crop-heavy strategy needs a
        # matched crop-heavy response, and holding 250 in reserve while our
        # field is empty means seeds we could plant sit unbought.  Verified
        # vs tape (10 seeds x 2 seats): buf 250 -> 150 gives ours $50.8k ->
        # $58.6k (+$7.8k), margin -$80.3k -> -$72.6k (+$7.7k).  No effect on
        # non-tape opponents (flag never sets).
        buf = 150 if self._tape_like_opp else p["cash_buffer"]
        terminal = day >= p["terminal_day"]

        # ---- PRICE-MOMENTUM DUMP (fires early so it works alongside the
        #      hour-0/1 branches that would otherwise return before the
        #      normal sell block).  If a product's current price has DROPPED
        #      momentum_drop_pct below its 5-day rolling max, dump our stock
        #      RIGHT NOW at hours 1/5/9/13/17 -- an opponent flooding the
        #      market makes the price fall further, so waiting for our once-
        #      per-day hour-21 sale loses money on every unit.  Verified
        #      head-to-head: mirror margin +$4k, sheepbot +$2k.
        # Strawberry is exempt (rising-price product; hold_straw_until owns
        # it).  Solo: neutral (no opponent -> no downtrend to catch).
        mom_drop = float(p.get("momentum_drop_pct", 0.03))
        mom_hours = (1, 5, 9, 13, 17)
        prices = self._last_prices
        if mom_drop > 0 and not terminal and hour in mom_hours:
            for item in ("WOOL", "MELON", "FERTILIZER", "MILK", "EGG",
                         "CARROT", "TOMATO"):
                if len(orders) >= 10:
                    break
                hist = self._price_history.get(item, [])
                if len(hist) < 2:
                    continue
                latest = hist[-1][1]
                prev_max = max(pr for _d, pr in hist[:-1])
                if latest >= prev_max * (1 - mom_drop):
                    continue
                q = int(shed.get(item, 0) or 0)
                if item == "WHEAT":
                    q = max(0, q - reserve)
                if item == "FERTILIZER":
                    q = max(0, q - self._fert_reserve(day))
                if prices.get(item, 1) <= 2:
                    continue
                if q > 0:
                    orders.append(["SELL", item, q])
        prices = self._last_prices
        wheat_price = prices.get("WHEAT", BASE_PRICE["WHEAT"])

        # ---- opening ----
        if day == 0 and hour == 0:
            if p.get("open_wheat", 0) > 0:
                orders.append(["BUY_PRODUCT", "WHEAT", int(p["open_wheat"])])
            for _ in range(int(p.get("open_hires", 0))):
                orders.append(["HIRE"])
            if p.get("open_sheep", 0) > 0:
                orders.append(["BUY_ANIMAL", "SHEEP", int(p["open_sheep"])])
            if p.get("open_cows", 0) > 0:
                orders.append(["BUY_ANIMAL", "COW", int(p["open_cows"])])
            if p.get("open_goose", 0) > 0:
                orders.append(["BUY_ANIMAL", "GOOSE", int(p["open_goose"])])
            for crop, key in [("MELON", "open_melon_seed"),
                              ("STRAWBERRY", "open_straw_seed"),
                              ("WHEAT", "open_wheat_seed")]:
                n = int(p.get(key, 0) or 0)
                if n > 0:
                    orders.append(["BUY_SEED", crop, n])
            return orders[:10]

        # ---- hour 0: feed wheat (life-critical) + hires ----
        if hour == 0:
            # META-LINE EXTRA STRAWBERRY BUY: the H1 seed rebuy is capped
            # at straw_rebuy=4 per fire, and only fires when seeds <=1.
            # On meta-line opponents strawberry is our BEST product (they
            # stay >$240 all game), so between D5-D12 we top up straw stock
            # here at H0 before other cash-consuming buys.  Costs $400 to
            # add 4 seeds; each seed becomes ~$2-4k of yield.  Measured
            # +$4,289 sum-margin N=20 (bea/lena/silas/cleo) on top of the
            # melon-buy-stop and D17 straw-plant fixes.
            if self._meta_line_opp and 5 <= day <= 12 \
                    and int(seeds.get("STRAWBERRY", 0) or 0) < 4 \
                    and money >= 500 and len(orders) < 10:
                need = 4 - int(seeds.get("STRAWBERRY", 0) or 0)
                orders.append(["BUY_SEED", "STRAWBERRY", need])
            hires = p["daily_hires"] if day < p["late_day"] else p["late_hires"]
            hires += getattr(self, "_extra_hires", 0)
            wheat_in_shed = int(shed.get("WHEAT", 0) or 0)
            # Keep a 2-day feed buffer (reserve) so the herd never starves,
            # but do NOT double-buy today's feed on top of it (that 3rd day
            # of stock was locking cash the herd needed to be bought).
            need = max(0, reserve - wheat_in_shed)
            if wheat_price <= p.get("wheat_cheap", 20):
                need += p.get("wheat_extra_buy", 6)   # buy cheap feed in bulk
            # Feed wheat is LIFE-CRITICAL: buy it even if it dips below the
            # buffer (the engine stops the order when money runs out).
            if need > 0 and money > 5:
                orders.append(["BUY_PRODUCT", "WHEAT", min(int(need), 20)])

            # Hour 0 can only place 10 orders (1 wheat + 9 hires); any further
            # hires carry over to hour 1 so the crew the planner assumed is the
            # crew that actually exists (phantom workers = lost feed/water).
            h0 = min(int(hires), 10 - len(orders))
            self._hires_left = max(0, int(hires) - h0)
            self._hired_so_far = h0
            for _ in range(h0):
                orders.append(["HIRE"])
            return orders[:10]

        # ---- hour 1: carry over hires (always), then animals FIRST, then
        #      town-aware seeds, then land — with a running cash budget ----
        if hour == 1:
            # Carry over the hires that did not fit hour 0's 10-order cap, so
            # the full crew shows up.  Their fib cost is charged now.
            if self._hires_left > 0:
                for i in range(min(self._hires_left, 10)):
                    orders.append(["HIRE"])
                self._hires_left = 0
        if hour == 1 and not terminal:
            cash = money
            LAND_PRICE = {"NE": 1000, "SW": 2000, "SE": 4000}
            town = self._town or defaultdict(int)

            on_board = {"SHEEP": 0, "COW": 0, "GOOSE": 0}
            for a in board["animals"]:
                t = a.get("animal")
                if t in on_board:
                    on_board[t] += 1

            def buy_seeds():
                nonlocal cash
                # Keep a rolling stock: rebuy when a crop runs out, sized so
                # the crew (hired to cover the field) always has seeds to
                # plant.  Window-urgency order: strawberries first (their
                # window closes day 13), then melons (day 19), then wheat.
                #
                # The cash floor is TOWN-AWARE: on a crop town the crops are
                # the whole game, so we spend thin cash on seeds; on an animal
                # town the herd gets the cash and seeds wait for a real
                # surplus.
                # Crop-heavy modes drop the floors: crop town, egg town,
                # tape-like opponent, OR meta-line opponent (all cases where
                # crops beat animal-product income).  Meta-line drops floor
                # to 0 (not just 50) because their aggressive strawberry
                # dumps mean we need EVERY seed we can get into the ground.
                _crop_heavy = (self._crop_town or self._egg_town
                               or self._tape_like_opp)
                if self._meta_line_opp:
                    straw_floor = 0
                    melon_floor = 0
                elif _crop_heavy:
                    straw_floor = 50
                    melon_floor = 50
                else:
                    straw_floor = int(p.get("seed_floor_straw", 200))
                    melon_floor = int(p.get("seed_floor_melon", 250))
                if int(seeds.get("STRAWBERRY", 0) or 0) <= 1 \
                        and day < p.get("straw_last_day", 13) \
                        and cash >= buf + straw_floor \
                        and len(orders) < 10:
                    n = min(6, p.get("straw_rebuy", 4))
                    # Meta-line opponents dump strawberries hard mid-game; buy
                    # a couple extra so we can compete on the D10-D15 peak
                    # window before their bulk dumps saturate the market.
                    if self._meta_line_opp:
                        n = max(n, 4)
                    orders.append(["BUY_SEED", "STRAWBERRY", n])
                    cash -= n * 100
                # MELON rebuy: default cutoff is D19 (last-plant day for a
                # ripening-by-D29 crop).  But on meta-line opponents the
                # melon PRICE crashes hard D20-D29 (Bea/Lena/Silas dump 20+
                # units per day from D24 onward, driving price to $4/unit
                # by D28).  A melon planted D14-D18 harvests D24-D28 into
                # that crash and nets ~$25/unit ≈ $150/tile against $80
                # seed + labour cost — often a NET LOSS.  Stopping melon
                # buys after D13 on meta redirects the cash to STRAWBERRY
                # (which stays >$240 through D29) and CARROT / wheat late-
                # fill.  Measured N=20 sum-margin: bea/lena/silas/cleo
                # baseline -$188,186 → -$178,855 (+$9,331) with the meta-
                # only gate.  Non-meta opps and solo N=10 unchanged.
                melon_last = p.get("melon_last_day", 19)
                if self._meta_line_opp:
                    melon_last = min(melon_last, 14)
                if int(seeds.get("MELON", 0) or 0) <= 1 \
                        and day < melon_last \
                        and cash >= buf + melon_floor \
                        and len(orders) < 10:
                    n = min(6, p.get("melon_rebuy", 4))
                    orders.append(["BUY_SEED", "MELON", n])
                    cash -= n * 80
                if int(seeds.get("WHEAT", 0) or 0) <= 2 and cash >= buf + 150 \
                        and len(orders) < 10:
                    # Tape-like opponents grow massive wheat fields for the
                    # day-29 dump; bumping our wheat rebuy from 6 -> 8 keeps
                    # our wheat pipeline competitive.  Verified vs tape:
                    # ours +$2,676 avg with margin also improved.
                    n = p.get("wheat_rebuy", 6)
                    if self._tape_like_opp:
                        n = max(n, 8)
                    orders.append(["BUY_SEED", "WHEAT", n])
                    cash -= n * 10
                # carrot: fast 3-day crop.  Early it is the carrot-town money;
                # LATE it is the cheap empty-slot filler (plant day 26, harvest
                # day 29 for ~$85/tile) that keeps the field earning right up
                # to the day-28/30 cleanup instead of sitting empty.  On
                # meta-line opponents we typically have 15+ empty tiles by
                # D24 (3 quads unlocked, strawberries harvested out), so buy
                # a bigger batch (12 instead of 4) — worth ~$1000 in yield
                # on the late-game empties.
                if int(seeds.get("CARROT", 0) or 0) <= 1 \
                        and ((town.get("CARROT", 0) >= 12 and day < 15)
                             or day >= 23) \
                        and day < 27 and cash >= buf + 120 and len(orders) < 10:
                    orders.append(["BUY_SEED", "CARROT", 4])
                    cash -= 80
                # tomato: slow (8 days) and weak yield; a couple only, and
                # only when the town REALLY wants them (2+ pizza-type shops)
                if int(seeds.get("TOMATO", 0) or 0) == 0 and town.get("TOMATO", 0) >= 12 \
                        and day < 10 and cash >= buf + 200 and len(orders) < 10:
                    orders.append(["BUY_SEED", "TOMATO", 2])
                    cash -= 100

            # ---- herd first: buy animals toward their ramp targets (one at
            #      a time so the running cash budget is exact).  Cap the
            #      cow+sheep+goose herd at herd_cap, counting BOTH the board
            #      AND the shed (unplaced animals still need feed + labor). ----
            shed_animals = int(shed.get("SHEEP", 0) or 0) + \
                int(shed.get("COW", 0) or 0) + int(shed.get("GOOSE", 0) or 0)
            total_animals = sum(on_board.values()) + shed_animals
            cap = p.get("herd_cap", 14)
            for atype, tkey in [("SHEEP", "sheep"), ("COW", "cow"),
                                ("GOOSE", "goose")]:
                eff = self._effective_target(day, tkey)
                have = on_board[atype] + int(shed.get(atype, 0) or 0)
                cost = ANIMALS[atype]["cost"]
                room = cap - total_animals
                if room <= 0:
                    break
                eff = min(eff, have + room)
                while have < eff and cash >= cost + 60 and len(orders) < 10:
                    n = int(min(3, eff - have, (cash - 60) // cost))
                    if n <= 0:
                        break
                    orders.append(["BUY_ANIMAL", atype, n])
                    cash -= cost * n
                    have += n
                    total_animals += n

            buy_seeds()

            # market-distress pivot: animal products crashed -> more crops
            if prices.get("MILK", 160) < p.get("milk_floor", 50) \
                    or prices.get("WOOL", 200) < p.get("wool_floor", 60):
                if cash >= buf + 200 and len(orders) < 10 \
                        and day < p.get("melon_last_day", 14):
                    orders.append(["BUY_SEED", "MELON", 2])
                    cash -= 160
                if cash >= buf + 150 and len(orders) < 10:
                    orders.append(["BUY_SEED", "WHEAT", 6])
                    cash -= 60

            # Land is bought ONE quadrant at a time, strictly in order, and
            # each new quadrant must wait its turn: after NE is bought it is
            # added to the working set, so SW only unlocks once NW+NE are full,
            # and SE only once NW+NE+SW are full.  (The old loop used a frozen
            # snapshot and could buy all three quads in a single turn.)
            avail_seeds = sum(int(seeds.get(c, 0) or 0) for c in CROPS)
            unl = set(unlocked)
            for quad, key in [("NE", "ne_land_day"), ("SW", "sw_land_day"),
                              ("SE", "se_land_day")]:
                if p.get(key, -1) >= 0 and day >= p[key] and quad not in unl \
                        and cash >= LAND_PRICE[quad] + buf + int(p.get("land_seed_budget", 600)) \
                        and self._land_density_ok(board, unl) \
                        and self._land_ready(day, avail_seeds) \
                        and len(orders) < 10:
                    orders.append(["BUY_LAND"])
                    cash -= LAND_PRICE[quad]
                    unl.add(quad)
            return orders[:10]

        # ---- LATE-GAME WHEAT REPLANT KEEPER (Session 35, meta only) ----
        # After terminal_day (D18) the main hour-1 buy block stops.  But
        # crop tiles empty as harvests finish (plants D19→D25 goes 37→6).
        # The harvest->replant loop needs WHEAT seeds in the shed to keep
        # tiles filled; without them, the field goes to dirt D24-D29.
        # Buy up to 4 wheat seeds when the shed drops below 4 and empty
        # tiles are waiting.  Fires at hour 6 (no other market action) so
        # it doesn't displace sells at hour 1 or 21.  Cheap ($10/seed) +
        # wheat replant fits in worker slack.  N=40 measured: +$1,052 on
        # top of the 2-quad cap.
        if hour == 6 and self._meta_line_opp and day >= 18 and day <= 25:
            wseeds = int(seeds.get("WHEAT", 0) or 0)
            n_empty = len(board.get("empty_set", set()))
            if wseeds < 4 and n_empty >= 4 and money >= 200 \
                    and len(orders) < 10:
                n = min(4, n_empty - wseeds)
                orders.append(["BUY_SEED", "WHEAT", n])

        # ---- SEASON SCHEDULER: sell one turn early when the opponent's crop
        #      matures today or tomorrow (read from their public planted_days)
        if p.get("frontrun_enabled", True) and self._opp is not None \
                and not terminal and hour == p.get("sell_hour", 2):
            dump_days, dump_soon = self._opp_dump_days(day)
            for item in SELL_ORDER:
                if len(orders) >= 10:
                    break
                q = int(shed.get(item, 0) or 0)
                if item == "WHEAT":
                    q = max(0, q - reserve)
                if item == "FERTILIZER":
                    q = max(0, q - self._fert_reserve(day))
                # trigger if their crop dumps today/tomorrow OR their shed is
                # about to hit the market (harvested yield sitting on tiles)
                trigger = (item in dump_soon) or \
                    (self._opp["pending"].get(item, 0) >= p.get("frontrun_pending", 3))
                # Dedupe: don't add if we've already queued this item
                already = any(o[0] == "SELL" and o[1] == item for o in orders)
                if q > 0 and trigger and not already:
                    orders.insert(0, ["SELL", item, q])

        # ---- market manipulation: if the opponent is flooding a product,
        #      dump our surplus of it to accelerate the crash they depend on
        if p.get("dump_enabled", True) and self._opp is not None and not terminal \
                and hour == p.get("sell_hour", 2):
            opp_crops = self._opp["crops"]
            for item, threshold in [("MELON", 8), ("STRAWBERRY", 8),
                                    ("CARROT", 8), ("TOMATO", 6)]:
                if opp_crops.get(item, 0) >= threshold and len(orders) < 10:
                    q = int(shed.get(item, 0) or 0)
                    already = any(o[0] == "SELL" and o[1] == item for o in orders)
                    if q > 0 and prices.get(item, 1) > 2 and not already:
                        orders.insert(0, ["SELL", item, q])



        # ---- selling (daily + terminal) ----
        # The MAIN sell hour is placed right AFTER a town-consumption tick so
        # market inventory (and thus price) is at its post-tick minimum/peak.
        # Optionally a SECONDARY sell hour fires earlier in the day, for
        # perishable inventory when the shed is filling faster than one dump
        # can drain (e.g. milk-heavy days).
        sell_h = p.get("sell_hour", 21)
        sell_h2 = p.get("sell_hour_secondary", -1)
        is_secondary = (sell_h2 >= 0 and hour == sell_h2)
        # HOLD-UNTIL: strawberry price rises monotonically ($212 D11 -> $334 D29
        # in typical seeds) because town shops eat strawberries faster than we
        # produce.  Holding the (small) strawberry stock until ~day 22 nets +$1k
        # on average, 59/60 seeds win.  We can NOT hold milk/egg (shed cap 100
        # overflows) or wool (price DROPS $206 -> $124).
        hold_until = int(p.get("hold_straw_until", 22))
        if terminal or hour == sell_h or is_secondary:
            for item in SELL_ORDER:
                if len(orders) >= 10:
                    break
                q = int(shed.get(item, 0) or 0)
                if item == "WHEAT":
                    if day >= 29:
                        q = int(shed.get("WHEAT", 0) or 0)
                    else:
                        # hold wheat for the herd's feed; sell only a BIG
                        # surplus (never sell ourselves into a feed shortage)
                        q = max(0, q - reserve * 2)
                if item == "FERTILIZER" and not terminal:
                    q = max(0, q - self._fert_reserve(day))
                # PRODUCT HOLDS: don't sell before the per-product hold day.
                # STRAWBERRY: price rises MONOTONICALLY over the game (~$210
                # -> ~$334 in solo).  Hold until day 22, dump then.  +$957/60s.
                # MELON: price rises slightly early game (peaks around day 15
                # for the first ~10 units in the shed), then plateaus.  Small
                # (avg 6-10 stock at that point) so no shed-cap risk.  Hold
                # until day 15.  +$181/60 seeds (60/60 wins -- perfectly
                # consistent even though the delta is tiny).
                if item == "STRAWBERRY" and not terminal and day < hold_until:
                    q = 0
                melon_hold = int(p.get("hold_melon_until", 15))
                if item == "MELON" and not terminal and day < melon_hold:
                    q = 0
                if is_secondary and not terminal:
                    # Secondary burst: only dump items whose shed load is
                    # already big enough to matter, else save them for the
                    # main hour-21 dump (bigger volume = better price via the
                    # town-tick timing).  Threshold ~2 days of animal output.
                    sec_min = {"MILK": 6, "WOOL": 6, "EGG": 6,
                               "FERTILIZER": 6, "MELON": 2,
                               "STRAWBERRY": 4, "CARROT": 4, "TOMATO": 4,
                               "WHEAT": 20}
                    if q < sec_min.get(item, 4):
                        continue
                # skip if already listed (momentum/frontrun already queued it
                # at the head of the orders list -- duplicate SELLs waste
                # order slots)
                if any(o[0] == "SELL" and o[1] == item for o in orders):
                    continue
                if q > 0:
                    orders.append(["SELL", item, q])
            # SESSION 43: opportunistic max-slot sells
            orders = self._apply_max_slot_sells(orders, day, hour, shed)
            return orders[:10]

        # SESSION 43: apply the predictive-adaptation layers
        # Land aggression + animal top-up at H1, opportunistic sells always
        farm_ref = getattr(self, "_farm_ref", None)
        if farm_ref is not None:
            orders = self._apply_land_aggression(orders, day, hour, money, farm_ref)
        board_ref = getattr(self, "_board_ref", None)
        if board_ref is not None:
            orders = self._apply_animal_topup(orders, day, hour, money, board_ref)
        orders = self._apply_max_slot_sells(orders, day, hour, shed)
        return orders[:10]

    # ------------------------------------------------------ herd economics
    def _effective_target(self, day, kind):
        p = self.params
        prices = self._last_prices
        # never invest in a product whose price has already crashed
        if kind == "cow" and prices.get("MILK", 160) < p.get("milk_floor", 50):
            return 0
        if kind == "sheep" and prices.get("WOOL", 200) < p.get("wool_floor", 60):
            return 0

        # specialist pivots: produce what the opponent does NOT make
        if self._sheep_pivot and kind == "cow":
            return min(2, int(p.get("target_cow", 2) or 0))  # keep a couple
        if self._cow_pivot and kind == "sheep":
            return min(2, int(p.get("target_sheep", 2) or 0))  # keep a couple

        early = int(p.get("target_" + kind, 0) or 0)
        final = int(p.get("final_" + kind, early) or early)
        # pivot overrides on the final target
        if self._sheep_pivot and kind == "sheep":
            final = 9
        if self._cow_pivot and kind == "cow":
            final = 12
        # TAPE-LIKE opponent override: cap cows at 6 (they'll ramp to 9+
        # too; combined 15+ cows crashes milk).  We compensate with crops.
        if self._tape_like_opp and kind == "cow":
            final = min(final, 6)
        if self._goose_pivot and kind == "goose":
            final = max(final, 3)

        start = int(p.get(kind + "_ramp_start", 0) or 0)
        end = int(p.get(kind + "_ramp_end", 0) or 0)
        if kind == "cow" and self._milk_town:
            # a milk town is exactly where cows pay off -- ramp them fast
            # (the slow ramp is for towns where crops need the early cash).
            end = min(end, 9)
        if end <= start:
            base = final
        else:
            frac = min(1.0, max(0.0, (day - start) / (end - start)))
            base = int(round(early + (final - early) * frac))

        if kind in ("cow", "sheep"):
            base = max(0, base + self._animal_bonus)

        # ---- TOWN-DRIVEN HERD SIZING: the town's shop mix decides which
        #      animal product holds value (seed 1 has 4 milk shops -> milk
        #      $330; seed 6 has yarn stores -> wool $243; seed 7 has bakeries
        #      -> eggs, and cows glut milk to $150).  We build the herd the
        #      town is buying, rebalanced WITHIN the proven 14-animal cap
        #      (feed for >14 animals eats the profit), and a crop/egg town
        #      runs a SMALLER herd so the cash goes into the field instead
        #      (the user's rule: smaller herd on non-milk towns is fine). ----
        if kind == "cow":
            if self._wool_town:
                base = min(base, 4)          # wool town: milk will glut
            elif self._egg_town:
                base = min(base, 4)          # egg town: milk is weak
            elif self._crop_town:
                base = min(base, 6)          # crop town: modest fert herd
            elif self._milk_town:
                base = min(base + 2, 12)     # milk town: cows up to 12
        elif kind == "sheep":
            if self._wool_town:
                base = min(base + 6, 10)     # wool town: sheep up to 10
            elif self._milk_town or self._egg_town or self._crop_town:
                base = min(base, 2)          # other towns: keep few sheep
        elif kind == "goose":
            # geese only when eggs clearly dominate the town (bakeries), and
            # only by shrinking the cow/sheep share, not adding on top.
            if self._egg_town:
                base = 6
            elif (self._town or defaultdict(int)).get("EGG", 0) >= 12:
                base = 4
        return base

    # ------------------------------------------------------------ execution
    def _execute(self, idx, pos, inv, board, shed, seeds, day, hour, claims):
        plan = self._timelines.get(idx) or []
        ptr = self._ptrs.get(idx, 0)
        while ptr < len(plan) and self._job_stale(plan[ptr], board):
            ptr += 1
        self._ptrs[idx] = ptr
        if ptr >= len(plan):
            return ["PASS"]
        job = plan[ptr]
        t = (job.x, job.y)
        if job.op == "PASS":
            self._ptrs[idx] = ptr + 1
            return ["PASS"]
        if job.op == "PICKUP":
            if pos == t:
                self._ptrs[idx] = ptr + 1
                item, n = job.arg
                return ["PICKUP", item, n]
            return move_toward(pos, t)
        if pos == t:
            self._ptrs[idx] = ptr + 1
            if job.arg is None:
                return [job.op]
            return [job.op, job.arg]
        return move_toward(pos, t)

    @staticmethod
    def _job_stale(job, board):
        if job.op == "WATER":
            d = board["grid"].get((job.x, job.y))
            return not (d and d.get("crop") and not d.get("watered_today"))
        if job.op == "FEED":
            d = board["grid"].get((job.x, job.y))
            return not (d and d.get("animal") and not d.get("fed_today"))
        if job.op == "COLLECT_FERTILIZER":
            d = board["grid"].get((job.x, job.y))
            return not (d and d.get("animal") and d.get("fertilizer_available"))
        if job.op == "HARVEST":
            d = board["grid"].get((job.x, job.y))
            return not d or d.get("yield_units", 0) <= 0
        if job.op == "PLANT":
            return board["grid"].get((job.x, job.y)) is not None
        if job.op == "DIG":
            return (job.x, job.y) not in board.get("weedset", set())
        if job.op == "CARE":
            d = board["grid"].get((job.x, job.y))
            return not (d and d.get("animal") and not d.get("cared_today"))
        if job.op == "FERTILIZE":
            d = board["grid"].get((job.x, job.y))
            return not (d and d.get("crop") == "STRAWBERRY")
        if job.op == "PLACE":
            d = board["grid"].get((job.x, job.y))
            struct = ANIMALS.get(job.arg, {}).get("struct")
            return not (d and d.get("type") == struct and not d.get("has_animal"))
        if job.op.startswith("BUILD"):
            return board["grid"].get((job.x, job.y)) is not None
        return False

    def _needs_water(self, pl, day):
        """True if this plant must be watered TODAY (already-unwatered-today
        plants only).  Encodes the real rule: plants die after TWO missed
        days, so alternate-day watering is enough to keep anything alive, and
        one-time crops only gain yield from water inside their bonus window.
        """
        if pl["consec_unwatered"] >= 1:
            return True                      # survival: one miss away
        cd = CROPS.get(pl["crop"])
        if not cd:
            return True
        age = day - pl["planted_day"]
        if cd["ongoing"]:
            # strawberry/tomato produce on a fixed schedule regardless of
            # watering; water only on production days so a fertilized tick
            # can double.  Otherwise let it sit (survival handled above).
            first_tick = cd["first"] - 1
            return age >= first_tick and (age - first_tick) % cd["interval"] == 0
        # one-time crop: water during the bonus window while it still gains
        # yield (stop early once it has capped)
        ws = (cd["max_day"] + 1) // 2
        return ws <= age <= cd["max_day"] and pl["yield_units"] < cd["max_yield"]

    @staticmethod
    def _harvestable_plant(pl, day):
        crop = pl["crop"]
        cd = CROPS.get(crop)
        if not cd or pl["yield_units"] <= 0:
            return False
        age = day - pl["planted_day"]
        if cd["ongoing"]:
            return age >= cd["first"]
        # one-time crop: harvest once it is fully grown (a melon watered
        # through its bonus window caps at 6 units around age 10-11, two days
        # before max_day=12), or at max_day as the fallback.
        will_bonus = 1 if (not pl["watered_today"]
                           and (cd["max_day"] + 1) // 2 <= age <= cd["max_day"]) else 0
        return age >= cd["first"] and (
            pl["yield_units"] + will_bonus >= cd["max_yield"]
            or age >= cd["max_day"])

    def _fert_reserve(self, day):
        """How much fertilizer to hold back from the sell block.  On a crop or
        egg town the field IS the economy, so before the first strawberries
        tick (~day 9) we sell the whole fertilizer stream as early seed money.
        On a milk/wool town the herd pays the bills, so we keep a reserve for
        the strawberries we do plant.  (Fertilizer = 1/day per animal, so this
        is the early cash engine the tape uses.)"""
        early = int(self.params.get("fert_early_day", 8))
        if day < early and (self._crop_town or self._egg_town):
            return 0
        return int(self.params.get("fert_reserve", 2))

    def _land_ready(self, day, avail_seeds):
        """Is expanding RIGHT NOW worth it, or would the new quadrant just sit
        empty?  On a crop town we only expand while the long-cycle windows are
        still open (a quadrant that can only grow wheat isn't worth $2k-4k +
        hands) AND while we actually hold seeds to start filling it the same
        day.  An animal town always expands -- the herd fills the land with
        pastures and feed wheat, no seeds required."""
        if not self._crop_town:
            return True
        if day > self.params.get("land_crop_last_day", 15):
            return False
        return avail_seeds >= self.params.get("land_min_seeds", 4)

    def _land_density_ok(self, board, unlocked):
        """The expansion gate: is the land we already own FULL?

        On an ANIMAL town (milk/wool/eggs) the herd is the economy, so 'full'
        means the tiles are a living crop OR a pasture/coop (the herd's own
        land is producing).  On a CROP town 'full' means every plantable tile
        (empty + weed + plant) is a living plant — weeds count as unfilled
        because they still need digging.  Either way a quadrant is only bought
        once the unlocked land is >= land_density used, so the current land
        stays full and pays for the next one (the user's rule: quads 3/4 only
        unlock when the earlier quads are full)."""
        target = self.params.get("land_density", 0.9)
        if self._milk_town or self._wool_town or self._egg_town:
            used = len(board["plants"]) + len(board["structures"])
            capacity = 25 * len(unlocked)
            if capacity <= 0:
                return False
            return used / capacity >= target
        # crop town: 'full' = every plantable tile is a living plant.  A
        # quadrant that is in `unlocked` but not yet in the board snapshot
        # (just bought this turn) counts as 25 empty tiles, so buying one
        # quadrant blocks the next until the first is actually planted.
        plants = len(board["plants"])
        plantable = plants + len(board["empty"]) + len(board["weeds"])
        for q in unlocked:
            if q not in board.get("unlocked_quads", set()):
                plantable += 25
        if plantable == 0:
            return False
        return plants / plantable >= target


# ============================================================================
# SECTION 6 — ENTRY POINT
# ============================================================================

_params = None
_agents = {}

def set_params(params):
    global _params, _agents
    _params = params
    _agents = {}


# DO NOT ADD ANY def / class / lambda / callable BELOW HERE.
# Kaggle picks the LAST callable in this file as the entrypoint (see
# kaggle_environments/agent.py:get_last_callable).  `agent` MUST be last.
def agent(obs, configuration=None):
    global _params, _agents
    if _params is None:
        _params = dict(DEFAULT_PARAMS)
    seat = int(obs.get("player", 0) or 0)
    if seat not in _agents:
        _agents[seat] = Agent(_params, seat)
    return _agents[seat].act(obs, configuration)


if __name__ == "__main__":
    from kaggle_environments import make as _make
    _env = _make("kaggriculture", configuration={"episodeSteps": 720, "seed": 1})
    _result = _env.run([agent, agent])
    print(f"self-mirror seed 1: ${_result[-1][0]['observation']['farms'][0]['money']:,.0f} vs ${_result[-1][0]['observation']['farms'][1]['money']:,.0f}")
